scoreboard players operation #cur vrmav.id = @s vrmav.id
execute as @e[type=item_display,tag=vrmav.orphan] if score @s vrmav.id = #cur vrmav.id run tag @s remove vrmav.orphan
