scoreboard players operation #cur vrmav.id = @s vrmav.id
execute as @e[type=item_display,tag=vrmav.part] if score @s vrmav.id = #cur vrmav.id run kill @s
execute if entity @s[tag=vrmav.on] run effect clear @s minecraft:invisibility
tag @s remove vrmav.on
