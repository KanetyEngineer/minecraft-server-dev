tag @e[type=item_display,tag=vrmav.part] add vrmav.orphan
execute as @a[tag=vrmav.on] run function vrmav:cleanup_owner
kill @e[type=item_display,tag=vrmav.orphan]
schedule function vrmav:cleanup 20t
