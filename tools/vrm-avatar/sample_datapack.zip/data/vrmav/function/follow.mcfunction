scoreboard players operation #cur vrmav.id = @s vrmav.id
execute rotated ~ 0 positioned ^-0.0000 ^1.3863 ^-0.0247 rotated as @s as @e[type=item_display,tag=vrmav.head] if score @s vrmav.id = #cur vrmav.id run tp @s ~ ~ ~ ~ ~
execute rotated ~ 0 as @e[type=item_display,tag=vrmav.limb] if score @s vrmav.id = #cur vrmav.id run function vrmav:place
scoreboard players operation @s vrmav.walk += @s vrmav.sprint
scoreboard players set @s[scores={vrmav.walk=0}] vrmav.phase -1
scoreboard players operation @s[scores={vrmav.walk=1..}] vrmav.dist += @s vrmav.walk
execute if score @s vrmav.walk matches 1.. run scoreboard players operation @s vrmav.phase = @s vrmav.dist
execute if score @s vrmav.walk matches 1.. run scoreboard players operation @s vrmav.phase /= #20 vrmav.id
execute if score @s vrmav.walk matches 1.. run scoreboard players operation @s vrmav.phase %= #8 vrmav.id
scoreboard players set @s vrmav.walk 0
scoreboard players set @s vrmav.sprint 0
execute unless score @s vrmav.phase = @s vrmav.last run function vrmav:pose
