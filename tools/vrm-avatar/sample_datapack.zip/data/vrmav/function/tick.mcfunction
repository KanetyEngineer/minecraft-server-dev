execute as @a[tag=vrmav.on] unless function vrmav:has_parts run function vrmav:redress
execute as @a[tag=vrmav.on] at @s run function vrmav:follow
