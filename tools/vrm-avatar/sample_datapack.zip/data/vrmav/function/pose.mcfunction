scoreboard players operation @s vrmav.last = @s vrmav.phase
execute if score @s vrmav.phase matches -1 run function vrmav:pose/idle
execute if score @s vrmav.phase matches 0 run function vrmav:pose/0
execute if score @s vrmav.phase matches 1 run function vrmav:pose/1
execute if score @s vrmav.phase matches 2 run function vrmav:pose/2
execute if score @s vrmav.phase matches 3 run function vrmav:pose/3
execute if score @s vrmav.phase matches 4 run function vrmav:pose/4
execute if score @s vrmav.phase matches 5 run function vrmav:pose/5
execute if score @s vrmav.phase matches 6 run function vrmav:pose/6
execute if score @s vrmav.phase matches 7 run function vrmav:pose/7
