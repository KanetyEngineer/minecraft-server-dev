execute unless score @s vrmav.id matches 1.. run scoreboard players add #next vrmav.id 1
execute unless score @s vrmav.id matches 1.. run scoreboard players operation @s vrmav.id = #next vrmav.id
function vrmav:unequip
scoreboard players operation #cur vrmav.id = @s vrmav.id
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_head"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.head","vrmav.new"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_body"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.body","vrmav.new","vrmav.limb"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_arm_l"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.arm_l","vrmav.new","vrmav.limb"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_arm_r"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.arm_r","vrmav.new","vrmav.limb"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_leg_l"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.leg_l","vrmav.new","vrmav.limb"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"vrmav:sample_leg_r"}},item_display:"none",teleport_duration:1,interpolation_duration:3,view_range:1.5f,Tags:["vrmav.part","vrmav.leg_r","vrmav.new","vrmav.limb"],transformation:{left_rotation:[0.00000f,1.00000f,0.00000f,0.00000f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}}
scoreboard players operation @e[type=item_display,tag=vrmav.new] vrmav.id = @s vrmav.id
tag @e[type=item_display,tag=vrmav.new] remove vrmav.new
effect give @s minecraft:invisibility infinite 0 true
tag @s add vrmav.on
scoreboard players set @s vrmav.last -2
scoreboard players set @s vrmav.phase -1
