execute at @s run function vrmav:equip_sample
