scoreboard players operation #cur vrmav.id = @s vrmav.id
execute as @e[type=item_display,tag=vrmav.head] if score @s vrmav.id = #cur vrmav.id run return 1
return fail
