tp @s[tag=vrmav.body] ^-0.0000 ^0.9081 ^0.0036 ~ 0
tp @s[tag=vrmav.arm_l] ^0.1086 ^1.2742 ^-0.0255 ~ 0
tp @s[tag=vrmav.arm_r] ^-0.1086 ^1.2742 ^-0.0255 ~ 0
tp @s[tag=vrmav.leg_l] ^0.0772 ^0.8683 ^-0.0001 ~ 0
tp @s[tag=vrmav.leg_r] ^-0.0772 ^0.8683 ^-0.0001 ~ 0
