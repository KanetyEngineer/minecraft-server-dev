scoreboard objectives add vrmav.id dummy
scoreboard objectives add vrmav.walk minecraft.custom:minecraft.walk_one_cm
scoreboard objectives add vrmav.sprint minecraft.custom:minecraft.sprint_one_cm
scoreboard objectives add vrmav.dist dummy
scoreboard objectives add vrmav.phase dummy
scoreboard objectives add vrmav.last dummy
scoreboard players add #next vrmav.id 0
scoreboard players set #20 vrmav.id 20
scoreboard players set #8 vrmav.id 8
schedule function vrmav:cleanup 20t
