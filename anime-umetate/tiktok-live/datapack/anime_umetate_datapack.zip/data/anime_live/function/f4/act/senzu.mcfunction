$tellraw @a[scores={um.fld=4}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"仙豆（穴を埋めて1段足す）","color":"gold","bold":true}]
$title @a[scores={um.fld=4}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 仙豆（穴を埋めて1段足す）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
execute unless score #state um.f4 matches 1 positioned 1802.5 121 2.5 run return run function umetate:fx/firework
tag @a remove al.target
execute positioned 1802.5 124 2.5 run function anime_live:avatar/pop
execute positioned 1802.5 121 2.5 run function anime_live:f4/do/senzu
