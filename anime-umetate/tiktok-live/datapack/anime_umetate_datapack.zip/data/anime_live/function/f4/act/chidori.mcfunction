$tellraw @a[scores={um.fld=4}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"千鳥（周りを1段崩す）","color":"gold","bold":true}]
$title @a[scores={um.fld=4}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 千鳥（周りを1段崩す）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank4 1
tag @a remove al.target
tag @r[scores={um.fld=4},gamemode=adventure] add al.target
execute at @a[tag=al.target] run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 1802.5 121 2.5 run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 1802.5 121 2.5 run return run function anime_live:f4/do/chidori
execute as @a[tag=al.target] at @s run function anime_live:f4/do/chidori
