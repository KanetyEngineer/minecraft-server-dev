title @a[scores={um.fld=4}] times 5 40 15
title @a[scores={um.fld=4}] title {"text": "かめはめ波", "color": "aqua", "bold": true}
function umetate:f4/fx/caster_spot
execute positioned as @e[type=marker,tag=um.spot,limit=1] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f4", "um.m.kamehameha", "um.new"]}
kill @e[type=marker,tag=um.spot]
function umetate:fx/new_avatar
