title @a[scores={um.fld=4}] times 5 40 15
title @a[scores={um.fld=4}] title {"text": "虚式「茈」", "color": "light_purple", "bold": true}
summon minecraft:marker 1802.5 128 2.5 {Tags:["um.fx", "um.f4", "um.m.murasaki", "um.new"]}
function umetate:fx/new_avatar
