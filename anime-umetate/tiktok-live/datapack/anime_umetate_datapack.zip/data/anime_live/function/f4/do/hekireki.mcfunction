title @a[scores={um.fld=4}] times 5 40 15
title @a[scores={um.fld=4}] title {"text": "雷の呼吸 壱ノ型", "color": "yellow", "bold": true}
title @a[scores={um.fld=4}] subtitle {"text": "霹靂一閃", "color": "gold"}
function umetate:f4/fx/caster_spot
execute positioned as @e[type=marker,tag=um.spot,limit=1] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f4", "um.m.hekireki", "um.new"]}
kill @e[type=marker,tag=um.spot]
function umetate:fx/new_avatar
