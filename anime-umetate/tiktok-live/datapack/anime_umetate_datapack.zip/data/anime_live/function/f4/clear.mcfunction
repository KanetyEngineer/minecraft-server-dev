kill @e[tag=um.mob,tag=um.f4]
kill @e[type=marker,tag=um.fx,tag=um.f4]
execute positioned 1802.5 120 2.5 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=4}] run function umetate:player/unfreeze
