$tellraw @a[scores={um.fld=6}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"みんなの応援（穴を埋めて3段足す）","color":"gold","bold":true}]
$title @a[scores={um.fld=6}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → みんなの応援（穴を埋めて3段足す）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
execute unless score #state um.f6 matches 1 positioned 3002.0 121 2.0 run return run function umetate:fx/firework
tag @a remove al.target
execute positioned 3002.0 124 2.0 run function anime_live:avatar/pop
execute positioned 3002.0 121 2.0 run function anime_live:f6/do/ouen
