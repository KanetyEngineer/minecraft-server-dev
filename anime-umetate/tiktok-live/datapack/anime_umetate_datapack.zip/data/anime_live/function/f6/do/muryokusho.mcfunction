title @a[scores={um.fld=6}] times 5 40 15
title @a[scores={um.fld=6}] title {"text": "領域展開", "color": "white", "bold": true}
title @a[scores={um.fld=6}] subtitle {"text": "無量空処", "color": "aqua"}
summon minecraft:marker 3002.0 121 2.0 {Tags:["um.fx","um.f6","um.m.muryokusho"]}
function umetate:fx/new_avatar
