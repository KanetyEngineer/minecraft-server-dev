kill @e[tag=um.mob,tag=um.f6]
kill @e[type=marker,tag=um.fx,tag=um.f6]
execute positioned 3002.0 120 2.0 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=6}] run function umetate:player/unfreeze
