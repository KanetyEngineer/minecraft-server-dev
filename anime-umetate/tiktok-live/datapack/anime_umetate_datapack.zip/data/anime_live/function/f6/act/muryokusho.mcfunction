$tellraw @a[scores={um.fld=6}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"領域展開「無量空処」（8秒動けない＋4段）","color":"gold","bold":true}]
$title @a[scores={um.fld=6}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 領域展開「無量空処」（8秒動けない＋4段）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank6 1
tag @a remove al.target
execute positioned 3002.0 124 2.0 run function anime_live:avatar/pop
execute positioned 3002.0 121 2.0 run function anime_live:f6/do/muryokusho
