$tellraw @a[scores={um.fld=6}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"螺旋丸（足元3×3を4段掘る）","color":"gold","bold":true}]
$title @a[scores={um.fld=6}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 螺旋丸（足元3×3を4段掘る）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank6 1
tag @a remove al.target
tag @r[scores={um.fld=6},gamemode=adventure] add al.target
execute at @a[tag=al.target] run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 3002.0 121 2.0 run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 3002.0 121 2.0 run return run function anime_live:f6/do/rasengan
execute as @a[tag=al.target] at @s run function anime_live:f6/do/rasengan
