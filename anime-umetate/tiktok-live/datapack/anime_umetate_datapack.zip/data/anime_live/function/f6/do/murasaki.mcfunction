title @a[scores={um.fld=6}] times 5 40 15
title @a[scores={um.fld=6}] title {"text": "虚式「茈」", "color": "light_purple", "bold": true}
summon minecraft:marker 3002.0 128 2.0 {Tags:["um.fx", "um.f6", "um.m.murasaki", "um.new"]}
function umetate:fx/new_avatar
