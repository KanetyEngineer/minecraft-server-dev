title @a[scores={um.fld=6}] times 5 40 15
title @a[scores={um.fld=6}] title {"text": "術式反転「赫」", "color": "red", "bold": true}
particle minecraft:dust{color:[1.0,0.1,0.1],scale:3.0} ~ ~1 ~ 0.5 0.5 0.5 0 60 force
particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 1.2
playsound minecraft:entity.warden.sonic_boom master @a ~ ~ ~ 0.6 1.6
effect give @s minecraft:levitation 1 24 true
scoreboard players set #depth um.tmp 2
scoreboard players set #r um.tmp 1
function umetate:f6/carve/col
