title @a[scores={um.fld=1}] times 5 40 15
title @a[scores={um.fld=1}] title {"text": "気円斬！", "color": "yellow", "bold": true}
summon minecraft:marker 2.5 128 2.5 {Tags:["um.fx","um.f1","um.m.kienzan"]}
function umetate:fx/new_avatar
