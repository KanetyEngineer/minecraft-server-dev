kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute positioned 2.5 120 2.5 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=1}] run function umetate:player/unfreeze
