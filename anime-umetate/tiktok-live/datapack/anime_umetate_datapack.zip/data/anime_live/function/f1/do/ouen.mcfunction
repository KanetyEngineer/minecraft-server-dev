title @a[scores={um.fld=1}] times 5 40 15
title @a[scores={um.fld=1}] title {"text": "みんなの応援！", "color": "green", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "3段ぶん埋まった！", "color": "green"}
scoreboard players set #add um.tmp 3
function umetate:f1/support
