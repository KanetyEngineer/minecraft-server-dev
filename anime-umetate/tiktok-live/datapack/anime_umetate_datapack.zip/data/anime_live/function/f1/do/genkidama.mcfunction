title @a[scores={um.fld=1}] times 5 40 15
title @a[scores={um.fld=1}] title {"text": "元気玉", "color": "aqua", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "みんな、オラに元気をわけてくれ！", "color": "yellow"}
summon minecraft:marker 2.5 150 2.5 {Tags:["um.fx","um.f1","um.m.genkidama"]}
function umetate:fx/new_avatar
