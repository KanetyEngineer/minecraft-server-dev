title @a[scores={um.fld=1}] times 5 40 15
title @a[scores={um.fld=1}] title {"text": "仙豆！", "color": "green", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "埋め立てを手伝ってくれた！", "color": "green"}
scoreboard players set #add um.tmp 1
function umetate:f1/support
