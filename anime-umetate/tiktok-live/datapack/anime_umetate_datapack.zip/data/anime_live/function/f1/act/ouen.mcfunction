$tellraw @a[scores={um.fld=1}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"みんなの応援（穴を埋めて3段足す）","color":"gold","bold":true}]
$title @a[scores={um.fld=1}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → みんなの応援（穴を埋めて3段足す）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
execute unless score #state um.f1 matches 1 positioned 2.5 121 2.5 run return run function umetate:fx/firework
tag @a remove al.target
execute positioned 2.5 124 2.5 run function anime_live:avatar/pop
execute positioned 2.5 121 2.5 run function anime_live:f1/do/ouen
