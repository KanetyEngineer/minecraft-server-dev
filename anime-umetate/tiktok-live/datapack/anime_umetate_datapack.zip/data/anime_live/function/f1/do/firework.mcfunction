function umetate:fx/firework
