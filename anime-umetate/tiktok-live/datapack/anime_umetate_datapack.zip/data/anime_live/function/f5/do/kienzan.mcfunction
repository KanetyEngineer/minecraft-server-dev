title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "気円斬！", "color": "yellow", "bold": true}
summon minecraft:marker 2402.0 128 2.0 {Tags:["um.fx","um.f5","um.m.kienzan"]}
function umetate:fx/new_avatar
