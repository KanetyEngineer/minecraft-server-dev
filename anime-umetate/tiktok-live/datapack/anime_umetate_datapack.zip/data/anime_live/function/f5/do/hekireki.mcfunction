title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "雷の呼吸 壱ノ型「霹靂一閃」", "color": "yellow", "bold": true}
execute positioned 2393 121 -1 facing 2412 121 2 run scoreboard players set #steps um.tmp 40
execute positioned 2393 121 -1 facing 2412 121 2 run function umetate:fx/beam/bolt
execute positioned 2412 121 2 facing 2393 121 5 run scoreboard players set #steps um.tmp 40
execute positioned 2412 121 2 facing 2393 121 5 run function umetate:fx/beam/bolt
particle minecraft:flash{color:[1.0,0.95,0.4,1.0]} 2402.0 118 2.0 0 0 0 0 1 force
playsound minecraft:item.trident.thunder master @a 2402.0 115 2.0 1.2 1.3
playsound minecraft:entity.player.attack.sweep master @a 2402.0 115 2.0 1 0.7
scoreboard players set #depth um.tmp 2
function umetate:f5/carve/all
