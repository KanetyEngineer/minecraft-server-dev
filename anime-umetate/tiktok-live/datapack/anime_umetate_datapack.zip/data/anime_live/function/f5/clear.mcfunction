kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute positioned 2402.0 120 2.0 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=5}] run function umetate:player/unfreeze
