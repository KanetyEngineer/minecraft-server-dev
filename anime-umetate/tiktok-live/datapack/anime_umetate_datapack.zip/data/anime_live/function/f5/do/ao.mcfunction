title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "術式順転「蒼」", "color": "blue", "bold": true}
execute if entity @s[x=2400,y=107,z=0,dx=3.99,dy=14,dz=3.99] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f5", "um.m.ao", "um.new"]}
execute unless entity @s[x=2400,y=107,z=0,dx=3.99,dy=14,dz=3.99] run summon minecraft:marker 2402.0 ~ 2.0 {Tags:["um.fx", "um.f5", "um.m.ao", "um.new"]}
tag @e[tag=um.new] remove um.new
