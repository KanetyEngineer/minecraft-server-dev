title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "天照", "color": "dark_purple", "bold": true}
summon minecraft:marker 2402.0 121 2.0 {Tags:["um.fx","um.f5","um.m.amaterasu"]}
function umetate:fx/new_avatar
