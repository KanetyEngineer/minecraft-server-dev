title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "元気玉", "color": "aqua", "bold": true}
title @a[scores={um.fld=5}] subtitle {"text": "みんな、オラに元気をわけてくれ！", "color": "yellow"}
summon minecraft:marker 2402.0 150 2.0 {Tags:["um.fx","um.f5","um.m.genkidama"]}
function umetate:fx/new_avatar
