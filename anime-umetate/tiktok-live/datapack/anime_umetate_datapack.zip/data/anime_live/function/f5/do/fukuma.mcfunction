title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "領域展開", "color": "dark_red", "bold": true}
title @a[scores={um.fld=5}] subtitle {"text": "伏魔御廚子", "color": "red"}
summon minecraft:marker 2402.0 121 2.0 {Tags:["um.fx","um.f5","um.m.fukuma"]}
function umetate:fx/new_avatar
