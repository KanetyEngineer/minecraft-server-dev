kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute positioned 602.5 120 2.5 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=2}] run function umetate:player/unfreeze
