$tellraw @a[scores={um.fld=2}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"ゴムゴムのピストル（吹っ飛ばし＋足元2個）","color":"gold","bold":true}]
$title @a[scores={um.fld=2}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → ゴムゴムのピストル（吹っ飛ばし＋足元2個）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank2 1
tag @a remove al.target
tag @r[scores={um.fld=2},gamemode=adventure] add al.target
execute at @a[tag=al.target] run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 602.5 121 2.5 run function anime_live:avatar/pop
execute unless entity @a[tag=al.target] positioned 602.5 121 2.5 run return run function anime_live:f2/do/gomu_pistol
execute as @a[tag=al.target] at @s run function anime_live:f2/do/gomu_pistol
