$tellraw @a[scores={um.fld=2}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"領域展開「無量空処」（8秒動けない＋4段）","color":"gold","bold":true}]
$title @a[scores={um.fld=2}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 領域展開「無量空処」（8秒動けない＋4段）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank2 1
tag @a remove al.target
execute positioned 602.5 124 2.5 run function anime_live:avatar/pop
execute positioned 602.5 121 2.5 run function anime_live:f2/do/muryokusho
