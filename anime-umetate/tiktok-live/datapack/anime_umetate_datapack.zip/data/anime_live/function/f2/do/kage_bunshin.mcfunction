title @a[scores={um.fld=2}] times 5 40 15
title @a[scores={um.fld=2}] title {"text": "影分身の術！", "color": "gold", "bold": true}
execute store result score #n um.tmp if entity @e[tag=um.clone,tag=um.f2]
execute if score #n um.tmp matches 12.. run return run function umetate:fx/firework
particle minecraft:poof ~ ~1 ~ 1.2 1 1.2 0.05 80 force
particle minecraft:cloud ~ ~1 ~ 1 1 1 0.02 40 force
playsound minecraft:entity.illusioner.mirror_move master @a ~ ~ ~ 1 1
playsound minecraft:entity.puffer_fish.blow_up master @a ~ ~ ~ 1 0.6
summon minecraft:husk ~1 ~0.5 ~0 {Tags:["um.mob","um.clone","um.f2","al.new"],PersistenceRequired:1b,Silent:1b,attributes:[{id:"minecraft:attack_damage",base:0d},{id:"minecraft:movement_speed",base:0.33d},{id:"minecraft:knockback_resistance",base:1d}],equipment:{chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":16744448}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":16744448}}},drop_chances:{chest:0.0f,legs:0.0f}}
summon minecraft:husk ~-1 ~0.5 ~0 {Tags:["um.mob","um.clone","um.f2","al.new"],PersistenceRequired:1b,Silent:1b,attributes:[{id:"minecraft:attack_damage",base:0d},{id:"minecraft:movement_speed",base:0.33d},{id:"minecraft:knockback_resistance",base:1d}],equipment:{chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":16744448}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":16744448}}},drop_chances:{chest:0.0f,legs:0.0f}}
summon minecraft:husk ~0 ~0.5 ~1 {Tags:["um.mob","um.clone","um.f2","al.new"],PersistenceRequired:1b,Silent:1b,attributes:[{id:"minecraft:attack_damage",base:0d},{id:"minecraft:movement_speed",base:0.33d},{id:"minecraft:knockback_resistance",base:1d}],equipment:{chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":16744448}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":16744448}}},drop_chances:{chest:0.0f,legs:0.0f}}
summon minecraft:husk ~0 ~0.5 ~-1 {Tags:["um.mob","um.clone","um.f2","al.new"],PersistenceRequired:1b,Silent:1b,attributes:[{id:"minecraft:attack_damage",base:0d},{id:"minecraft:movement_speed",base:0.33d},{id:"minecraft:knockback_resistance",base:1d}],equipment:{chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":16744448}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":16744448}}},drop_chances:{chest:0.0f,legs:0.0f}}

execute as @e[tag=al.new] run function anime_live:mob/decorate
