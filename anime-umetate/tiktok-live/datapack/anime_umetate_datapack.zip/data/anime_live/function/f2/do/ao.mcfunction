title @a[scores={um.fld=2}] times 5 40 15
title @a[scores={um.fld=2}] title {"text": "術式順転「蒼」", "color": "blue", "bold": true}
execute if entity @s[x=600,y=99,z=0,dx=4.99,dy=22,dz=4.99] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f2", "um.m.ao", "um.new"]}
execute unless entity @s[x=600,y=99,z=0,dx=4.99,dy=22,dz=4.99] run summon minecraft:marker 602.5 ~ 2.5 {Tags:["um.fx", "um.f2", "um.m.ao", "um.new"]}
tag @e[tag=um.new] remove um.new
