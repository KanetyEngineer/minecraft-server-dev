title @a[scores={um.fld=2}] times 5 40 15
title @a[scores={um.fld=2}] title {"text": "気円斬！", "color": "yellow", "bold": true}
summon minecraft:marker 602.5 128 2.5 {Tags:["um.fx","um.f2","um.m.kienzan"]}
function umetate:fx/new_avatar
