title @a[scores={um.fld=2}] times 5 40 15
title @a[scores={um.fld=2}] title {"text": "雷の呼吸 壱ノ型「霹靂一閃」", "color": "yellow", "bold": true}
execute positioned 593 121 -1 facing 612 121 2 run scoreboard players set #steps um.tmp 40
execute positioned 593 121 -1 facing 612 121 2 run function umetate:fx/beam/bolt
execute positioned 612 121 2 facing 593 121 5 run scoreboard players set #steps um.tmp 40
execute positioned 612 121 2 facing 593 121 5 run function umetate:fx/beam/bolt
particle minecraft:flash{color:[1.0,0.95,0.4,1.0]} 602.5 118 2.5 0 0 0 0 1 force
playsound minecraft:item.trident.thunder master @a 602.5 115 2.5 1.2 1.3
playsound minecraft:entity.player.attack.sweep master @a 602.5 115 2.5 1 0.7
scoreboard players set #depth um.tmp 2
function umetate:f2/carve/all
