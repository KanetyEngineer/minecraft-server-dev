title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "千鳥！", "color": "aqua", "bold": true}
particle minecraft:electric_spark ~ ~1 ~ 0.8 0.8 0.8 0.4 120 force
particle minecraft:flash{color:[0.5,0.8,1.0,1.0]} ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:dust{color:[0.55,0.8,1.0],scale:1.5} ~ ~1 ~ 0.6 0.6 0.6 0 40 force
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 0.6 2
playsound minecraft:block.note_block.chime master @a ~ ~ ~ 1 2
playsound minecraft:entity.parrot.ambient master @a ~ ~ ~ 1 2
scoreboard players set #depth um.tmp 1
scoreboard players set #r um.tmp 1
function umetate:f3/carve/col
