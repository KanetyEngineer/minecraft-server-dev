title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "仙豆！", "color": "green", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "埋め立てを手伝ってくれた！", "color": "green"}
scoreboard players set #add um.tmp 1
function umetate:f3/support
