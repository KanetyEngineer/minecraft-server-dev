title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "ゴムゴムの…ピストル！", "color": "red", "bold": true}
execute positioned ~-9 ~1 ~ facing entity @s eyes run scoreboard players set #steps um.tmp 18
execute positioned ~-9 ~1 ~ facing entity @s eyes run function umetate:fx/beam/gomu
playsound minecraft:entity.breeze.wind_burst master @a ~ ~ ~ 1 0.8
playsound minecraft:entity.player.attack.knockback master @a ~ ~ ~ 1 0.6
particle minecraft:explosion ~ ~1 ~ 0.3 0.3 0.3 0 2 force
effect give @s minecraft:levitation 1 12 true
scoreboard players set #depth um.tmp 2
scoreboard players set #r um.tmp 0
function umetate:f3/carve/col
