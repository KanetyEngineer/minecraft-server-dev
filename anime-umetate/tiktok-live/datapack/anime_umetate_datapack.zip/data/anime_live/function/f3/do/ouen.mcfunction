title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "みんなの応援！", "color": "green", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "3段ぶん埋まった！", "color": "green"}
scoreboard players set #add um.tmp 3
function umetate:f3/support
