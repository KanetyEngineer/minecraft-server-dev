title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "螺旋丸！", "color": "aqua", "bold": true}
execute if entity @s[x=1200,y=99,z=0,dx=4.99,dy=22,dz=4.99] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f3", "um.m.rasengan", "um.new"]}
execute unless entity @s[x=1200,y=99,z=0,dx=4.99,dy=22,dz=4.99] run summon minecraft:marker 1202.5 ~ 2.5 {Tags:["um.fx", "um.f3", "um.m.rasengan", "um.new"]}
tag @e[tag=um.new] remove um.new
