title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "領域展開", "color": "dark_red", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "伏魔御廚子", "color": "red"}
summon minecraft:marker 1202.5 121 2.5 {Tags:["um.fx","um.f3","um.m.fukuma"]}
function umetate:fx/new_avatar
