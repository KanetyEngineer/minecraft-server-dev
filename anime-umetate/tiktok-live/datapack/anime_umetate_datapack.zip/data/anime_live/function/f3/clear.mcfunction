kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute positioned 1202.5 120 2.5 run kill @e[tag=al.av,distance=..40]
execute as @a[scores={um.fld=3}] run function umetate:player/unfreeze
