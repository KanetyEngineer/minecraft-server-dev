title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "天照", "color": "dark_purple", "bold": true}
summon minecraft:marker 1202.5 121 2.5 {Tags:["um.fx","um.f3","um.m.amaterasu"]}
function umetate:fx/new_avatar
