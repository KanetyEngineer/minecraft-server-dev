title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "領域展開", "color": "white", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "無量空処", "color": "aqua"}
summon minecraft:marker 1202.5 121 2.5 {Tags:["um.fx","um.f3","um.m.muryokusho"]}
function umetate:fx/new_avatar
