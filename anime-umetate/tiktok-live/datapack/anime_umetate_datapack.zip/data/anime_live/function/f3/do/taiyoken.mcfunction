title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "太陽拳！", "color": "yellow", "bold": true}
particle minecraft:flash{color:[1.0,1.0,0.9,1.0]} ~ ~1.6 ~ 0 0 0 0 1 force
particle minecraft:end_rod ~ ~1.6 ~ 0.6 0.6 0.6 0.25 60 force
playsound minecraft:entity.firework_rocket.blast master @a ~ ~ ~ 1 2
playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 1 2
effect give @s minecraft:blindness 3 0 true
