$tellraw @a[scores={um.fld=3}] [{"text":"[LIVE] ","color":"light_purple","bold":true},{"text":"$(name)","color":"yellow"},{"text":" さんの $(gift)！ → ","color":"white"},{"text":"元気玉（上12段を消し飛ばす）","color":"gold","bold":true}]
$title @a[scores={um.fld=3}] actionbar [{"text":"$(name)","color":"yellow"},{"text":" → 元気玉（上12段を消し飛ばす）","color":"gold"}]
$data modify storage anime_live:cur label set value {text:"$(name)",color:"yellow",bold:true}
$data modify storage anime_live:cur mobname set value {text:"$(name)の影分身",color:"gold",bold:true}
$scoreboard players add $(rname) um.rank3 1
tag @a remove al.target
execute positioned 1202.5 124 2.5 run function anime_live:avatar/pop
execute positioned 1202.5 121 2.5 run function anime_live:f3/do/genkidama
