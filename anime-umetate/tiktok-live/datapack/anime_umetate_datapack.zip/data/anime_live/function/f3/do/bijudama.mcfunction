title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "尾獣玉", "color": "dark_purple", "bold": true}
function umetate:f3/fx/caster_spot
execute positioned as @e[type=marker,tag=um.spot,limit=1] run summon minecraft:marker ~ ~ ~ {Tags:["um.fx", "um.f3", "um.m.bijudama", "um.new"]}
kill @e[type=marker,tag=um.spot]
function umetate:fx/new_avatar
