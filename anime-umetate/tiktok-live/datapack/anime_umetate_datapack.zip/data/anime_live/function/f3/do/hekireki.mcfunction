title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "雷の呼吸 壱ノ型「霹靂一閃」", "color": "yellow", "bold": true}
execute positioned 1193 121 -1 facing 1212 121 2 run scoreboard players set #steps um.tmp 40
execute positioned 1193 121 -1 facing 1212 121 2 run function umetate:fx/beam/bolt
execute positioned 1212 121 2 facing 1193 121 5 run scoreboard players set #steps um.tmp 40
execute positioned 1212 121 2 facing 1193 121 5 run function umetate:fx/beam/bolt
particle minecraft:flash{color:[1.0,0.95,0.4,1.0]} 1202.5 118 2.5 0 0 0 0 1 force
playsound minecraft:item.trident.thunder master @a 1202.5 115 2.5 1.2 1.3
playsound minecraft:entity.player.attack.sweep master @a 1202.5 115 2.5 1 0.7
scoreboard players set #depth um.tmp 2
function umetate:f3/carve/all
