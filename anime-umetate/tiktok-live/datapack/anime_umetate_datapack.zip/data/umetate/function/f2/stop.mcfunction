scoreboard players set #state um.f2 4
kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute as @a[scores={um.fld=2}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=2}] {"text": "[埋め立て] フィールド2を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
