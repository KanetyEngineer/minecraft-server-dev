execute store result score #r um.tmp run random value 1..4
execute if score #r um.tmp matches 1 run summon minecraft:marker 594.5 126 -5.5 {Tags:["um.spot"]}
execute if score #r um.tmp matches 2 run summon minecraft:marker 611.5 126 -5.5 {Tags:["um.spot"]}
execute if score #r um.tmp matches 3 run summon minecraft:marker 594.5 126 11.5 {Tags:["um.spot"]}
execute if score #r um.tmp matches 4 run summon minecraft:marker 611.5 126 11.5 {Tags:["um.spot"]}
