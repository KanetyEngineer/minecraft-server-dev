execute unless blocks 600 119 0 604 119 4 600 50 0 all store result score #c um.tmp run clone 600 119 0 604 119 4 600 60 0 masked
execute unless blocks 600 119 0 604 119 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 119 0 604 119 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 119
execute unless blocks 600 118 0 604 118 4 600 50 0 all store result score #c um.tmp run clone 600 118 0 604 118 4 600 60 0 masked
execute unless blocks 600 118 0 604 118 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 118 0 604 118 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 118
execute unless blocks 600 117 0 604 117 4 600 50 0 all store result score #c um.tmp run clone 600 117 0 604 117 4 600 60 0 masked
execute unless blocks 600 117 0 604 117 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 117 0 604 117 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 117
execute unless blocks 600 116 0 604 116 4 600 50 0 all store result score #c um.tmp run clone 600 116 0 604 116 4 600 60 0 masked
execute unless blocks 600 116 0 604 116 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 116 0 604 116 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 116
execute unless blocks 600 115 0 604 115 4 600 50 0 all store result score #c um.tmp run clone 600 115 0 604 115 4 600 60 0 masked
execute unless blocks 600 115 0 604 115 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 115 0 604 115 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 115
execute unless blocks 600 114 0 604 114 4 600 50 0 all store result score #c um.tmp run clone 600 114 0 604 114 4 600 60 0 masked
execute unless blocks 600 114 0 604 114 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 114 0 604 114 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 114
execute unless blocks 600 113 0 604 113 4 600 50 0 all store result score #c um.tmp run clone 600 113 0 604 113 4 600 60 0 masked
execute unless blocks 600 113 0 604 113 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 113 0 604 113 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 113
execute unless blocks 600 112 0 604 112 4 600 50 0 all store result score #c um.tmp run clone 600 112 0 604 112 4 600 60 0 masked
execute unless blocks 600 112 0 604 112 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 112 0 604 112 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 112
execute unless blocks 600 111 0 604 111 4 600 50 0 all store result score #c um.tmp run clone 600 111 0 604 111 4 600 60 0 masked
execute unless blocks 600 111 0 604 111 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 111 0 604 111 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 111
execute unless blocks 600 110 0 604 110 4 600 50 0 all store result score #c um.tmp run clone 600 110 0 604 110 4 600 60 0 masked
execute unless blocks 600 110 0 604 110 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 110 0 604 110 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 110
execute unless blocks 600 109 0 604 109 4 600 50 0 all store result score #c um.tmp run clone 600 109 0 604 109 4 600 60 0 masked
execute unless blocks 600 109 0 604 109 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 109 0 604 109 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 109
execute unless blocks 600 108 0 604 108 4 600 50 0 all store result score #c um.tmp run clone 600 108 0 604 108 4 600 60 0 masked
execute unless blocks 600 108 0 604 108 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 108 0 604 108 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 108
execute unless blocks 600 107 0 604 107 4 600 50 0 all store result score #c um.tmp run clone 600 107 0 604 107 4 600 60 0 masked
execute unless blocks 600 107 0 604 107 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 107 0 604 107 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 107
execute unless blocks 600 106 0 604 106 4 600 50 0 all store result score #c um.tmp run clone 600 106 0 604 106 4 600 60 0 masked
execute unless blocks 600 106 0 604 106 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 106 0 604 106 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 106
execute unless blocks 600 105 0 604 105 4 600 50 0 all store result score #c um.tmp run clone 600 105 0 604 105 4 600 60 0 masked
execute unless blocks 600 105 0 604 105 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 105 0 604 105 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 105
execute unless blocks 600 104 0 604 104 4 600 50 0 all store result score #c um.tmp run clone 600 104 0 604 104 4 600 60 0 masked
execute unless blocks 600 104 0 604 104 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 104 0 604 104 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 104
execute unless blocks 600 103 0 604 103 4 600 50 0 all store result score #c um.tmp run clone 600 103 0 604 103 4 600 60 0 masked
execute unless blocks 600 103 0 604 103 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 103 0 604 103 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 103
execute unless blocks 600 102 0 604 102 4 600 50 0 all store result score #c um.tmp run clone 600 102 0 604 102 4 600 60 0 masked
execute unless blocks 600 102 0 604 102 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 102 0 604 102 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 102
execute unless blocks 600 101 0 604 101 4 600 50 0 all store result score #c um.tmp run clone 600 101 0 604 101 4 600 60 0 masked
execute unless blocks 600 101 0 604 101 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 101 0 604 101 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 101
execute unless blocks 600 100 0 604 100 4 600 50 0 all store result score #c um.tmp run clone 600 100 0 604 100 4 600 60 0 masked
execute unless blocks 600 100 0 604 100 4 600 50 0 all run fill 600 60 0 604 60 4 minecraft:air
execute unless blocks 600 100 0 604 100 4 600 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 100
scoreboard players set #surf um.tmp 99
execute unless blocks 600 119 0 604 119 4 600 50 0 all run return run scoreboard players set #surf um.tmp 119
execute unless blocks 600 118 0 604 118 4 600 50 0 all run return run scoreboard players set #surf um.tmp 118
execute unless blocks 600 117 0 604 117 4 600 50 0 all run return run scoreboard players set #surf um.tmp 117
execute unless blocks 600 116 0 604 116 4 600 50 0 all run return run scoreboard players set #surf um.tmp 116
execute unless blocks 600 115 0 604 115 4 600 50 0 all run return run scoreboard players set #surf um.tmp 115
execute unless blocks 600 114 0 604 114 4 600 50 0 all run return run scoreboard players set #surf um.tmp 114
execute unless blocks 600 113 0 604 113 4 600 50 0 all run return run scoreboard players set #surf um.tmp 113
execute unless blocks 600 112 0 604 112 4 600 50 0 all run return run scoreboard players set #surf um.tmp 112
execute unless blocks 600 111 0 604 111 4 600 50 0 all run return run scoreboard players set #surf um.tmp 111
execute unless blocks 600 110 0 604 110 4 600 50 0 all run return run scoreboard players set #surf um.tmp 110
execute unless blocks 600 109 0 604 109 4 600 50 0 all run return run scoreboard players set #surf um.tmp 109
execute unless blocks 600 108 0 604 108 4 600 50 0 all run return run scoreboard players set #surf um.tmp 108
execute unless blocks 600 107 0 604 107 4 600 50 0 all run return run scoreboard players set #surf um.tmp 107
execute unless blocks 600 106 0 604 106 4 600 50 0 all run return run scoreboard players set #surf um.tmp 106
execute unless blocks 600 105 0 604 105 4 600 50 0 all run return run scoreboard players set #surf um.tmp 105
execute unless blocks 600 104 0 604 104 4 600 50 0 all run return run scoreboard players set #surf um.tmp 104
execute unless blocks 600 103 0 604 103 4 600 50 0 all run return run scoreboard players set #surf um.tmp 103
execute unless blocks 600 102 0 604 102 4 600 50 0 all run return run scoreboard players set #surf um.tmp 102
execute unless blocks 600 101 0 604 101 4 600 50 0 all run return run scoreboard players set #surf um.tmp 101
execute unless blocks 600 100 0 604 100 4 600 50 0 all run return run scoreboard players set #surf um.tmp 100
