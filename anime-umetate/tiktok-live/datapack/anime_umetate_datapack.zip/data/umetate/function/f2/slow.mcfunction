fill 600 120 0 604 140 4 minecraft:air replace #umetate:fillable
function umetate:f2/count
execute as @a[scores={um.fld=2},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f2 matches 1 if score #filled um.f2 >= #total um.f2 run function umetate:f2/win
execute if score #state um.f2 matches 0 if entity @a[scores={um.fld=2},gamemode=adventure] run function umetate:f2/start
execute if entity @a[scores={um.fld=2}] run scoreboard players set #empty um.f2 0
execute unless entity @a[scores={um.fld=2}] run scoreboard players add #empty um.f2 1
execute if score #empty um.f2 matches 60 run function umetate:f2/idle
function umetate:f2/status
