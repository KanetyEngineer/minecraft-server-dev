scoreboard players set #vs um.f2 0
scoreboard players set #state um.f2 2
scoreboard players set #cd um.f2 300
kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute as @a[scores={um.fld=2}] run function umetate:player/unfreeze
title @a[scores={um.fld=2}] times 10 80 20
title @a[scores={um.fld=2}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=2}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 602.5 115 2.5 2 0.8
