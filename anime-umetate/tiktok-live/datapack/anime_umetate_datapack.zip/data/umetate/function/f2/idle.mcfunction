execute if score #vs um.f2 matches 1.. run function umetate:f2/vs_forfeit
scoreboard players set #state um.f2 0
scoreboard players set #ticks um.f2 0
kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute positioned 602.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 600 100 0 604 140 4 minecraft:air
