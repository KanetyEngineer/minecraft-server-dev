scoreboard players add @a[scores={um.fld=2},gamemode=adventure] um.vswin 1
tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{selector:"@a[scores={um.fld=2},gamemode=adventure]"},{"text": " の勝ち！（フィールド2・", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f2"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f2"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "）", "color": "gold", "bold": true}]
execute as @a[scores={um.fld=2},gamemode=adventure] run function umetate:lb/vslog
execute if score #vs um.f2 matches 1 run function umetate:f1/vs_lose
execute if score #vs um.f2 matches 3 run function umetate:f3/vs_lose
execute if score #vs um.f2 matches 4 run function umetate:f4/vs_lose
scoreboard players set #vs um.f2 0
title @a[scores={um.fld=2}] subtitle {"text": "対戦に勝った！", "color": "gold", "bold": true}
