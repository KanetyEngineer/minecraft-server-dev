scoreboard objectives add um.f2 dummy
scoreboard objectives add um.rank2 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド2", "color": "green", "bold": true}]
scoreboard objectives setdisplay sidebar.team.green um.rank2
scoreboard players set #total um.f2 500
execute unless score #state um.f2 matches 0.. run scoreboard players set #state um.f2 0
execute unless score #vs um.f2 matches 0.. run scoreboard players set #vs um.f2 0
execute unless score #reserved um.f2 matches 0.. run scoreboard players set #reserved um.f2 0
team add um.f2 {"text": "フィールド2", "color": "green"}
team modify um.f2 color green
team modify um.f2 prefix {"text": "[2] ", "color": "green"}
team modify um.f2 collisionRule never
team modify um.f2 friendlyFire false
bossbar add umetate:f2 {"text": "フィールド2", "color": "green"}
bossbar set umetate:f2 max 500
bossbar set umetate:f2 color green
bossbar set umetate:f2 style notched_10
forceload add 584 -16 631 31
execute unless score #built um.f2 matches 2 run schedule function umetate:f2/build 40t
