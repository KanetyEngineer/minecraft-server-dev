tag @s add um.leaving
execute if score #vs um.f2 matches 1.. unless entity @a[scores={um.fld=2},tag=!um.leaving] run function umetate:f2/vs_forfeit
tag @s remove um.leaving
team leave @s
