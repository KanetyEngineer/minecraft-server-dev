scoreboard players set #state um.f2 2
scoreboard players set #cd um.f2 300
kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute as @a[scores={um.fld=2}] run function umetate:player/unfreeze
title @a[scores={um.fld=2}] times 10 80 20
title @a[scores={um.fld=2}] title {"text": "埋め立て完了！", "color": "gold", "bold": true}
title @a[scores={um.fld=2}] subtitle [{"text": "タイム ", "color": "white"},{score:{name:"#min",objective:"um.f2"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f2"},color:"yellow"},{"text": "秒", "color": "white"}]
execute if score #best um.f2 matches 1.. if score #ticks um.f2 < #best um.f2 run tellraw @a[scores={um.fld=2}] {"text": "[埋め立て] フィールド2の新記録！", "color": "gold", "bold": true}
execute unless score #best um.f2 matches 1.. run scoreboard players operation #best um.f2 = #ticks um.f2
execute if score #ticks um.f2 < #best um.f2 run scoreboard players operation #best um.f2 = #ticks um.f2
execute if score #best1 um.st matches 1.. if score #ticks um.f2 < #best1 um.st run tellraw @a [{"text": "[埋め立て] 標準の最速記録更新！ ", "color": "gold", "bold": true},{selector:"@a[scores={um.fld=2},gamemode=adventure]"},{"text": " ", "color": "white"},{score:{name:"#min",objective:"um.f2"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f2"},color:"yellow"},{"text": "秒", "color": "white"}]
execute unless score #best1 um.st matches 1.. run scoreboard players operation #best1 um.st = #ticks um.f2
execute if score #ticks um.f2 < #best1 um.st run scoreboard players operation #best1 um.st = #ticks um.f2
tellraw @a[scores={um.fld=2}] [{"text": "[埋め立て] フィールド2 クリア！ ", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f2"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f2"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "。15秒後に次のラウンドが始まります（待機所へは /trigger leave）。", "color": "white"}]

execute store result storage umetate:time m int 1 run scoreboard players get #min um.f2
execute store result storage umetate:time s int 1 run scoreboard players get #s um.f2
execute store result storage umetate:time t int 1 run scoreboard players get #ticks um.f2
data modify storage umetate:time pad set value ""
execute if score #s um.f2 matches ..9 run data modify storage umetate:time pad set value "0"
data modify storage umetate:time f set value 2

execute as @a[scores={um.fld=2},gamemode=adventure] run function umetate:lb/record1
execute if score #vs um.f2 matches 1.. run function umetate:f2/vs_win
playsound minecraft:ui.toast.challenge_complete master @a 602.5 115 2.5 2 1
playsound minecraft:entity.player.levelup master @a 602.5 115 2.5 2 1
