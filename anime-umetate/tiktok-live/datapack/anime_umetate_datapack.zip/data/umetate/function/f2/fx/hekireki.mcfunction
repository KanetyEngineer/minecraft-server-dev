execute if score @s um.t matches 1 run title @a[scores={um.fld=2}] actionbar {"text": "雷の呼吸…", "color": "yellow", "bold": true}
execute if score @s um.t matches 12 run title @a[scores={um.fld=2}] actionbar {"text": "雷の呼吸 壱ノ型…", "color": "yellow", "bold": true}
execute if score @s um.t matches 25 run title @a[scores={um.fld=2}] actionbar {"text": "霹靂一閃ーーッ！！", "color": "gold", "bold": true}
execute if score @s um.t matches 1 run playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 0.5 1.6
execute if score @s um.t matches 1 run effect give @a[scores={um.fld=2}] minecraft:darkness 2 0 true
execute if score @s um.t matches 8 run playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 1 2
execute if score @s um.t matches 16 run playsound minecraft:item.trident.riptide_1 master @a ~ ~ ~ 1 2
execute if score @s um.t matches 1..24 run particle minecraft:electric_spark ~ ~ ~ 0.5 0.9 0.5 0.4 12 force
execute if score @s um.t matches 1..24 run particle minecraft:dust{color:[1.0,0.9,0.2],scale:1.4} ~ ~ ~ 0.4 0.4 0.4 0 4 force
execute if score @s um.t matches 12..24 run particle minecraft:dust{color:[1.0,1.0,0.7],scale:2.0} ~ ~ ~ 0.7 0.7 0.7 0 4 force
execute if score @s um.t matches 18..24 run particle minecraft:end_rod ~ ~ ~ 0.4 0.6 0.4 0.08 3 force
execute if score @s um.t matches 24 as @a[scores={um.fld=2}] run effect give @s minecraft:fire_resistance 12 0 true
execute if score @s um.t matches 24 run function umetate:f2/surface
execute if score @s um.t matches 24 run scoreboard players add #surf um.tmp 1
execute if score @s um.t matches 24 store result storage umetate:bolt y int 1 run scoreboard players get #surf um.tmp
execute if score @s um.t matches 24..80 run fill 598 100 -2 606 124 6 minecraft:air replace #minecraft:fire
execute if score @s um.t matches 25 run scoreboard players set #steps um.tmp 50
execute if score @s um.t matches 25 facing 602.5 116 2.5 run function umetate:fx/beam/bolt
execute if score @s um.t matches 25 run particle minecraft:flash{color:[1.0,0.95,0.4,1.0]} 602.5 118 2.5 0 0 0 0 1 force
execute if score @s um.t matches 25 run playsound minecraft:item.trident.thunder master @a 602.5 115 2.5 2 1.2
execute if score @s um.t matches 25 run playsound minecraft:entity.player.attack.sweep master @a 602.5 115 2.5 1.5 0.6
execute if score @s um.t matches 25 run function umetate:f2/fx/bolt/c with storage umetate:bolt
execute if score @s um.t matches 27 run scoreboard players set #depth um.tmp 2
execute if score @s um.t matches 27 run function umetate:f2/carve/all
execute if score @s um.t matches 27 run playsound minecraft:entity.generic.explode master @a 602.5 112 2.5 1.5 1.4
execute if score @s um.t matches 28 run function umetate:f2/surface
execute if score @s um.t matches 28 run scoreboard players add #surf um.tmp 1
execute if score @s um.t matches 28 store result storage umetate:bolt y int 1 run scoreboard players get #surf um.tmp
execute if score @s um.t matches 29 run function umetate:f2/fx/bolt/a with storage umetate:bolt
execute if score @s um.t matches 31 run function umetate:f2/fx/bolt/b with storage umetate:bolt
execute if score @s um.t matches 33 run function umetate:f2/fx/bolt/d with storage umetate:bolt
execute if score @s um.t matches 35 run function umetate:f2/fx/bolt/e with storage umetate:bolt
execute if score @s um.t matches 26..60 run particle minecraft:electric_spark 602.5 117 2.5 1.6 3 1.6 0.6 10 force
execute if score @s um.t matches 26..40 run particle minecraft:end_rod 602.5 116 2.5 1.6 3 1.6 0.1 4 force
execute if score @s um.t matches 81 run kill @e[type=item,x=598,y=100,z=-2,dx=8,dy=24,dz=8]
execute if score @s um.t matches 82.. run kill @s
