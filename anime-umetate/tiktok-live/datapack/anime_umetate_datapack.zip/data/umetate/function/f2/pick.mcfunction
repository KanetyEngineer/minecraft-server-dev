execute if score @s um.fld matches 2 run return run tellraw @s {"text": "すでにフィールド2にいます", "color": "gray"}
execute if score #vs um.f2 matches 1.. run return run tellraw @s {"text": "フィールド2は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f2/enter
