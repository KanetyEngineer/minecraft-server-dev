$summon minecraft:lightning_bolt 602.5 $(y) 2.5
$particle minecraft:electric_spark 602.5 $(y).5 2.5 0.6 0.6 0.6 0.8 80 force
$particle minecraft:flash{color:[1.0,0.95,0.5,1.0]} 602.5 $(y).5 2.5 0 0 0 0 1 force
$particle minecraft:explosion 602.5 $(y).5 2.5 0.5 0.3 0.5 0 3 force
