function umetate:f2/surface
execute if score #surf um.tmp matches ..99 run return 0
scoreboard players operation #lo um.tmp = #surf um.tmp
scoreboard players operation #lo um.tmp -= #depth um.tmp
scoreboard players add #lo um.tmp 1
execute if score #lo um.tmp matches ..99 run scoreboard players set #lo um.tmp 100
execute store result storage umetate:arg lo int 1 run scoreboard players get #lo um.tmp
execute store result storage umetate:arg r int 1 run scoreboard players get #r um.tmp
function umetate:f2/carve/col_m with storage umetate:arg
