execute if entity @a[scores={um.fld=2}] run return 0
execute if score #vs um.f2 matches 1.. run return 0
execute if score #reserved um.f2 matches 1 run return 0
return 1
