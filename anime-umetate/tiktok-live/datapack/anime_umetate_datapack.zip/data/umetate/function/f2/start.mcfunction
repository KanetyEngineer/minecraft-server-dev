scoreboard players set #state um.f2 3
scoreboard players set #cd um.f2 70
scoreboard players set #ticks um.f2 0
scoreboard players set #empty um.f2 0
kill @e[tag=um.mob,tag=um.f2]
kill @e[type=marker,tag=um.fx,tag=um.f2]
execute positioned 602.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 600 100 0 604 140 4 minecraft:air
tp @a[scores={um.fld=2},gamemode=adventure] 602.5 100 2.5
execute as @a[scores={um.fld=2}] run function umetate:player/unfreeze
title @a[scores={um.fld=2}] times 5 40 15
title @a[scores={um.fld=2}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=2}] subtitle {"text": "フィールド2：穴を500ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f2 matches 1.. run title @a[scores={um.fld=2}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 602.5 110 2.5 2 0.8
