execute store result score #filled um.f2 run clone 600 100 0 604 119 4 600 60 0 masked
fill 600 60 0 604 79 4 minecraft:air
scoreboard players operation #pct um.f2 = #filled um.f2
scoreboard players operation #pct um.f2 *= #100 um.st
scoreboard players operation #pct um.f2 /= #total um.f2
execute store result bossbar umetate:f2 value run scoreboard players get #filled um.f2
scoreboard players operation #sec um.f2 = #ticks um.f2
scoreboard players operation #sec um.f2 /= #20 um.st
scoreboard players operation #min um.f2 = #sec um.f2
scoreboard players operation #min um.f2 /= #60 um.st
scoreboard players operation #s um.f2 = #sec um.f2
scoreboard players operation #s um.f2 %= #60 um.st
bossbar set umetate:f2 name [{"text": "フィールド2 ", "color": "green", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f2"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f2"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f2"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f2 players @a[scores={um.fld=2}]
