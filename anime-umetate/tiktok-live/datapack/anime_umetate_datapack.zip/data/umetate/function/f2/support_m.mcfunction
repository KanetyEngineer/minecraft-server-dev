$fill 600 100 0 604 $(top) 4 minecraft:lime_concrete replace minecraft:air
$execute as @a[x=600,y=99,z=0,dx=4.99,dy=22,dz=4.99] at @s if entity @s[y=0,dy=$(top)] run tp @s ~ $(top1) ~
$particle minecraft:happy_villager 602.5 $(top) 2.5 2 0.5 2 0 60 force
$particle minecraft:totem_of_undying 602.5 $(top) 2.5 2 1 2 0.3 60 force
playsound minecraft:entity.player.levelup master @a 602.5 115 2.5 1 1.4
playsound minecraft:item.totem.use master @a 602.5 115 2.5 0.6 1.6
