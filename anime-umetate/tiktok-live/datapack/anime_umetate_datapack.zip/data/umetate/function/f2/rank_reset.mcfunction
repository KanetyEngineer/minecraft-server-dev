scoreboard players reset * um.rank2
