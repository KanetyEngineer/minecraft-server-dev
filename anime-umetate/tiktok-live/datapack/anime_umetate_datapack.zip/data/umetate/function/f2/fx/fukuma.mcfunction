execute if score @s um.t matches 1 run playsound minecraft:entity.elder_guardian.curse master @a 602.5 118 2.5 1.5 0.5
execute if score @s um.t matches 1 run playsound minecraft:block.end_portal.spawn master @a 602.5 118 2.5 1 0.6
execute if score @s um.t matches 1 run effect give @a[scores={um.fld=2}] minecraft:darkness 4 0 true
execute if score @s um.t matches 1..60 run particle minecraft:dust{color:[0.6,0.0,0.0],scale:3.0} 602.5 122 2.5 9 4 9 0 25 force
execute if score @s um.t matches 1..60 run particle minecraft:sweep_attack 602.5 116 2.5 3 4 3 0 4 force
execute if score @s um.t matches 1..60 run particle minecraft:crit 602.5 116 2.5 3 4 3 0.4 10 force
execute if score @s um.t matches 8..56 run scoreboard players operation #m um.tmp = @s um.t
execute if score @s um.t matches 8..56 run scoreboard players operation #m um.tmp %= #4 um.st
execute if score @s um.t matches 8..56 if score #m um.tmp matches 0 run function umetate:f2/fx/slash
execute if score @s um.t matches 64.. run kill @s
