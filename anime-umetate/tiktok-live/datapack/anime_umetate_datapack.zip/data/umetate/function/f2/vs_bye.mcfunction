scoreboard players set #vs um.f2 0
scoreboard players add @a[scores={um.fld=2},gamemode=adventure] um.vswin 1
title @a[scores={um.fld=2}] title {"text": "不戦勝！", "color": "gold", "bold": true}
title @a[scores={um.fld=2}] subtitle {"text": "このまま続けて記録をねらおう", "color": "white"}
