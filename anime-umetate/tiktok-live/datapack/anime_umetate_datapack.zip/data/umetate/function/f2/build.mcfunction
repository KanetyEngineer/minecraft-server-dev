execute unless loaded 590 120 -10 run return run schedule function umetate:f2/build 20t
execute unless loaded 614 120 14 run return run schedule function umetate:f2/build 20t
fill 590 98 -10 614 120 14 minecraft:air
fill 590 121 -10 614 145 14 minecraft:air
fill 599 98 -1 605 98 5 minecraft:sea_lantern
fill 599 99 -1 605 119 5 minecraft:glass
fill 600 99 0 604 99 4 minecraft:bedrock
fill 600 100 0 604 119 4 minecraft:air
fill 599 104 -1 605 104 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 599 109 -1 605 109 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 599 114 -1 605 114 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 591 120 -9 613 120 13 minecraft:polished_blackstone_bricks
fill 599 120 -1 605 120 5 minecraft:gold_block
fill 600 120 0 604 120 4 minecraft:air
fill 591 120 -9 613 120 -9 minecraft:crying_obsidian
fill 591 120 13 613 120 13 minecraft:crying_obsidian
fill 591 120 -9 591 120 13 minecraft:crying_obsidian
fill 613 120 -9 613 120 13 minecraft:crying_obsidian
fill 590 121 -10 614 145 -10 minecraft:barrier
fill 590 121 14 614 145 14 minecraft:barrier
fill 590 121 -10 590 145 14 minecraft:barrier
fill 614 121 -10 614 145 14 minecraft:barrier
fill 592 121 -8 592 127 -8 minecraft:quartz_pillar
setblock 592 128 -8 minecraft:sea_lantern
fill 612 121 -8 612 127 -8 minecraft:quartz_pillar
setblock 612 128 -8 minecraft:sea_lantern
fill 592 121 12 592 127 12 minecraft:quartz_pillar
setblock 592 128 12 minecraft:sea_lantern
fill 612 121 12 612 127 12 minecraft:quartz_pillar
setblock 612 128 12 minecraft:sea_lantern
setblock 594 121 -6 minecraft:chiseled_quartz_block
setblock 594 122 -6 minecraft:soul_lantern
setblock 611 121 -6 minecraft:chiseled_quartz_block
setblock 611 122 -6 minecraft:soul_lantern
setblock 594 121 11 minecraft:chiseled_quartz_block
setblock 594 122 11 minecraft:soul_lantern
setblock 611 121 11 minecraft:chiseled_quartz_block
setblock 611 122 11 minecraft:soul_lantern
setblock 593 121 -9 minecraft:lantern
setblock 593 121 13 minecraft:lantern
setblock 591 121 -7 minecraft:lantern
setblock 613 121 -7 minecraft:lantern
setblock 597 121 -9 minecraft:lantern
setblock 597 121 13 minecraft:lantern
setblock 591 121 -3 minecraft:lantern
setblock 613 121 -3 minecraft:lantern
setblock 601 121 -9 minecraft:lantern
setblock 601 121 13 minecraft:lantern
setblock 591 121 1 minecraft:lantern
setblock 613 121 1 minecraft:lantern
setblock 605 121 -9 minecraft:lantern
setblock 605 121 13 minecraft:lantern
setblock 591 121 5 minecraft:lantern
setblock 613 121 5 minecraft:lantern
setblock 609 121 -9 minecraft:lantern
setblock 609 121 13 minecraft:lantern
setblock 591 121 9 minecraft:lantern
setblock 613 121 9 minecraft:lantern
fill 591 119 -9 613 119 -9 minecraft:lime_wool
execute positioned 602.5 128 2.5 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 602.5 133 2.5 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド2（標準 5×5×20）", "color": "green", "bold": true}]}
summon minecraft:text_display 602.5 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（500ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f2 2
tellraw @a[scores={um.fld=2}] {"text": "[埋め立て] フィールド2の会場を作りました", "color": "gray"}
