tp @s ~ ~ ~ ~24 ~
particle minecraft:dust{color:[0.6,0.85,1.0],scale:2.0} ~ ~1.2 ~ 0.25 0.25 0.25 0 8 force
particle minecraft:dust{color:[0.9,0.97,1.0],scale:1.2} ^0.6 ^1.2 ^ 0 0 0 0 1 force
particle minecraft:dust{color:[0.9,0.97,1.0],scale:1.2} ^-0.6 ^1.2 ^ 0 0 0 0 1 force
particle minecraft:dust{color:[0.3,0.6,1.0],scale:1.2} ^ ^1.2 ^0.6 0 0 0 0 1 force
particle minecraft:dust{color:[0.3,0.6,1.0],scale:1.2} ^ ^1.2 ^-0.6 0 0 0 0 1 force
execute if score @s um.t matches 1 run playsound minecraft:item.trident.riptide_1 master @a ~ ~ ~ 1 1.4
execute if score @s um.t matches 10 run playsound minecraft:item.trident.riptide_2 master @a ~ ~ ~ 1 1.6
execute if score @s um.t matches 20 run particle minecraft:explosion ~ ~ ~ 1 0.5 1 0 6 force
execute if score @s um.t matches 20 run particle minecraft:cloud ~ ~ ~ 1 1 1 0.2 60 force
execute if score @s um.t matches 20 run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 1.3
execute if score @s um.t matches 20 run scoreboard players set #depth um.tmp 4
execute if score @s um.t matches 20 run scoreboard players set #r um.tmp 1
execute if score @s um.t matches 20 run function umetate:f2/carve/col
execute if score @s um.t matches 22.. run kill @s
