tag @s add um.leaving
execute if score #vs um.f4 matches 1.. unless entity @a[scores={um.fld=4},tag=!um.leaving] run function umetate:f4/vs_forfeit
tag @s remove um.leaving
team leave @s
