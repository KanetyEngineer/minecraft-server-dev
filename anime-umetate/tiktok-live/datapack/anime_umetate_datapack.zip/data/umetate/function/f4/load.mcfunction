scoreboard objectives add um.f4 dummy
scoreboard objectives add um.rank4 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド4", "color": "light_purple", "bold": true}]
scoreboard objectives setdisplay sidebar.team.light_purple um.rank4
scoreboard players set #total um.f4 500
execute unless score #state um.f4 matches 0.. run scoreboard players set #state um.f4 0
execute unless score #vs um.f4 matches 0.. run scoreboard players set #vs um.f4 0
execute unless score #reserved um.f4 matches 0.. run scoreboard players set #reserved um.f4 0
team add um.f4 {"text": "フィールド4", "color": "light_purple"}
team modify um.f4 color light_purple
team modify um.f4 prefix {"text": "[4] ", "color": "light_purple"}
team modify um.f4 collisionRule never
team modify um.f4 friendlyFire false
bossbar add umetate:f4 {"text": "フィールド4", "color": "light_purple"}
bossbar set umetate:f4 max 500
bossbar set umetate:f4 color green
bossbar set umetate:f4 style notched_10
forceload add 1784 -16 1831 31
execute unless score #built um.f4 matches 2 run schedule function umetate:f4/build 40t
