execute store result score #filled um.f4 run clone 1800 100 0 1804 119 4 1800 60 0 masked
fill 1800 60 0 1804 79 4 minecraft:air
scoreboard players operation #pct um.f4 = #filled um.f4
scoreboard players operation #pct um.f4 *= #100 um.st
scoreboard players operation #pct um.f4 /= #total um.f4
execute store result bossbar umetate:f4 value run scoreboard players get #filled um.f4
scoreboard players operation #sec um.f4 = #ticks um.f4
scoreboard players operation #sec um.f4 /= #20 um.st
scoreboard players operation #min um.f4 = #sec um.f4
scoreboard players operation #min um.f4 /= #60 um.st
scoreboard players operation #s um.f4 = #sec um.f4
scoreboard players operation #s um.f4 %= #60 um.st
bossbar set umetate:f4 name [{"text": "フィールド4 ", "color": "light_purple", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f4"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f4"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f4"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f4 players @a[scores={um.fld=4}]
