execute if score @s um.fld matches 4 run return run tellraw @s {"text": "すでにフィールド4にいます", "color": "gray"}
execute if score #vs um.f4 matches 1.. run return run tellraw @s {"text": "フィールド4は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f4/enter
