execute if score #vs um.f4 matches 1.. run function umetate:f4/vs_forfeit
scoreboard players set #state um.f4 0
scoreboard players set #ticks um.f4 0
kill @e[tag=um.mob,tag=um.f4]
kill @e[type=marker,tag=um.fx,tag=um.f4]
execute positioned 1802.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 1800 100 0 1804 140 4 minecraft:air
