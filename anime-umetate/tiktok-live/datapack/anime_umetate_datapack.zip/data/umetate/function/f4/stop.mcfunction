scoreboard players set #state um.f4 4
kill @e[tag=um.mob,tag=um.f4]
kill @e[type=marker,tag=um.fx,tag=um.f4]
execute as @a[scores={um.fld=4}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=4}] {"text": "[埋め立て] フィールド4を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
