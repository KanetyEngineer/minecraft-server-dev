$fill 1800 $(lo) 0 1804 119 4 minecraft:air replace #umetate:fillable
$particle minecraft:block{block_state:"minecraft:lime_concrete"} 1802.5 $(lo) 2.5 2 1.5 2 0 160 force
$particle minecraft:explosion 1802.5 $(lo) 2.5 2 1 2 0 6 force
$playsound minecraft:block.stone.break master @a 1802.5 $(lo) 2.5 1.5 0.7
