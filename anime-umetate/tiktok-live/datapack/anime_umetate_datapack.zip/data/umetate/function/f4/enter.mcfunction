scoreboard players set @s um.fld 4
tag @s remove um.vq1
tag @s remove um.vq2
tag @s remove um.vqw
team join um.f4 @s
clear @s
function umetate:player/unfreeze
scoreboard players set #empty um.f4 0
execute if score #state um.f4 matches 1 run tp @s 1802.5 120 2.5
execute if score #state um.f4 matches 3 run tp @s 1802.5 100 2.5
execute unless score #state um.f4 matches 1 unless score #state um.f4 matches 3 run tp @s 1802.5 121 -5.5 0 10
function umetate:player/refill
bossbar set umetate:f4 players @a[scores={um.fld=4}]
tellraw @s [{"text": "[埋め立て] フィールド4（標準 5×5×20）", "color": "light_purple", "bold": true},{"text": " 穴（500ブロック）を下から埋めきったらクリア！ ブロックは自動で補充されます。", "color": "white"}]
tellraw @s [{"text": "待機所へ戻る: ", "color": "gray"},{"text": "[待機所へ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "/trigger leave"}, "hover_event": {"action": "show_text", "value": "フィールドを選び直す"}},{"text": "  ロビーへ: /trigger lobby", "color": "gray"}]
