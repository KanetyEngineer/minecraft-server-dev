fill 1800 120 0 1804 140 4 minecraft:air replace #umetate:fillable
function umetate:f4/count
execute as @a[scores={um.fld=4},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f4 matches 1 if score #filled um.f4 >= #total um.f4 run function umetate:f4/win
execute if score #state um.f4 matches 0 if entity @a[scores={um.fld=4},gamemode=adventure] run function umetate:f4/start
execute if entity @a[scores={um.fld=4}] run scoreboard players set #empty um.f4 0
execute unless entity @a[scores={um.fld=4}] run scoreboard players add #empty um.f4 1
execute if score #empty um.f4 matches 60 run function umetate:f4/idle
function umetate:f4/status
