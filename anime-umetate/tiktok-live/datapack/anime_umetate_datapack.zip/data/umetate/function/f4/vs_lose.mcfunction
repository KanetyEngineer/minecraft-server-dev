scoreboard players set #vs um.f4 0
scoreboard players set #state um.f4 2
scoreboard players set #cd um.f4 300
kill @e[tag=um.mob,tag=um.f4]
kill @e[type=marker,tag=um.fx,tag=um.f4]
execute as @a[scores={um.fld=4}] run function umetate:player/unfreeze
title @a[scores={um.fld=4}] times 10 80 20
title @a[scores={um.fld=4}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=4}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 1802.5 115 2.5 2 0.8
