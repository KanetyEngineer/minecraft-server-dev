execute if entity @a[scores={um.fld=4}] run return 0
execute if score #vs um.f4 matches 1.. run return 0
execute if score #reserved um.f4 matches 1 run return 0
return 1
