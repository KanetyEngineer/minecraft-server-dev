execute unless loaded 1790 120 -10 run return run schedule function umetate:f4/build 20t
execute unless loaded 1814 120 14 run return run schedule function umetate:f4/build 20t
fill 1790 98 -10 1814 120 14 minecraft:air
fill 1790 121 -10 1814 145 14 minecraft:air
fill 1799 98 -1 1805 98 5 minecraft:sea_lantern
fill 1799 99 -1 1805 119 5 minecraft:glass
fill 1800 99 0 1804 99 4 minecraft:bedrock
fill 1800 100 0 1804 119 4 minecraft:air
fill 1799 104 -1 1805 104 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1799 109 -1 1805 109 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1799 114 -1 1805 114 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1791 120 -9 1813 120 13 minecraft:polished_blackstone_bricks
fill 1799 120 -1 1805 120 5 minecraft:gold_block
fill 1800 120 0 1804 120 4 minecraft:air
fill 1791 120 -9 1813 120 -9 minecraft:crying_obsidian
fill 1791 120 13 1813 120 13 minecraft:crying_obsidian
fill 1791 120 -9 1791 120 13 minecraft:crying_obsidian
fill 1813 120 -9 1813 120 13 minecraft:crying_obsidian
fill 1790 121 -10 1814 145 -10 minecraft:barrier
fill 1790 121 14 1814 145 14 minecraft:barrier
fill 1790 121 -10 1790 145 14 minecraft:barrier
fill 1814 121 -10 1814 145 14 minecraft:barrier
fill 1792 121 -8 1792 127 -8 minecraft:quartz_pillar
setblock 1792 128 -8 minecraft:sea_lantern
fill 1812 121 -8 1812 127 -8 minecraft:quartz_pillar
setblock 1812 128 -8 minecraft:sea_lantern
fill 1792 121 12 1792 127 12 minecraft:quartz_pillar
setblock 1792 128 12 minecraft:sea_lantern
fill 1812 121 12 1812 127 12 minecraft:quartz_pillar
setblock 1812 128 12 minecraft:sea_lantern
setblock 1794 121 -6 minecraft:chiseled_quartz_block
setblock 1794 122 -6 minecraft:soul_lantern
setblock 1811 121 -6 minecraft:chiseled_quartz_block
setblock 1811 122 -6 minecraft:soul_lantern
setblock 1794 121 11 minecraft:chiseled_quartz_block
setblock 1794 122 11 minecraft:soul_lantern
setblock 1811 121 11 minecraft:chiseled_quartz_block
setblock 1811 122 11 minecraft:soul_lantern
setblock 1793 121 -9 minecraft:lantern
setblock 1793 121 13 minecraft:lantern
setblock 1791 121 -7 minecraft:lantern
setblock 1813 121 -7 minecraft:lantern
setblock 1797 121 -9 minecraft:lantern
setblock 1797 121 13 minecraft:lantern
setblock 1791 121 -3 minecraft:lantern
setblock 1813 121 -3 minecraft:lantern
setblock 1801 121 -9 minecraft:lantern
setblock 1801 121 13 minecraft:lantern
setblock 1791 121 1 minecraft:lantern
setblock 1813 121 1 minecraft:lantern
setblock 1805 121 -9 minecraft:lantern
setblock 1805 121 13 minecraft:lantern
setblock 1791 121 5 minecraft:lantern
setblock 1813 121 5 minecraft:lantern
setblock 1809 121 -9 minecraft:lantern
setblock 1809 121 13 minecraft:lantern
setblock 1791 121 9 minecraft:lantern
setblock 1813 121 9 minecraft:lantern
fill 1791 119 -9 1813 119 -9 minecraft:magenta_wool
execute positioned 1802.5 128 2.5 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 1802.5 133 2.5 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド4（標準 5×5×20）", "color": "light_purple", "bold": true}]}
summon minecraft:text_display 1802.5 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（500ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f4 2
tellraw @a[scores={um.fld=4}] {"text": "[埋め立て] フィールド4の会場を作りました", "color": "gray"}
