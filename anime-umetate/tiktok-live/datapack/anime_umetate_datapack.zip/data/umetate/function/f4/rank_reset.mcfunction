scoreboard players reset * um.rank4
