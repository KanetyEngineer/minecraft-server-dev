tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{"text": "フィールド4のプレイヤーが抜けたので、相手の不戦勝です", "color": "white"}]
execute if score #vs um.f4 matches 1 run function umetate:f1/vs_bye
execute if score #vs um.f4 matches 2 run function umetate:f2/vs_bye
execute if score #vs um.f4 matches 3 run function umetate:f3/vs_bye
scoreboard players set #vs um.f4 0
