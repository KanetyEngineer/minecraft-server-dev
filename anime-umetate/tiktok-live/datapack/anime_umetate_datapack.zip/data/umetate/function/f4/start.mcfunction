scoreboard players set #state um.f4 3
scoreboard players set #cd um.f4 70
scoreboard players set #ticks um.f4 0
scoreboard players set #empty um.f4 0
kill @e[tag=um.mob,tag=um.f4]
kill @e[type=marker,tag=um.fx,tag=um.f4]
execute positioned 1802.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 1800 100 0 1804 140 4 minecraft:air
tp @a[scores={um.fld=4},gamemode=adventure] 1802.5 100 2.5
execute as @a[scores={um.fld=4}] run function umetate:player/unfreeze
title @a[scores={um.fld=4}] times 5 40 15
title @a[scores={um.fld=4}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=4}] subtitle {"text": "フィールド4：穴を500ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f4 matches 1.. run title @a[scores={um.fld=4}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 1802.5 110 2.5 2 0.8
