execute as @a[tag=!um.seen] run function umetate:player/join
execute as @a[scores={um.leave=1..}] run function umetate:player/join
scoreboard players enable @a menu
scoreboard players enable @a field
scoreboard players enable @a leave
scoreboard players enable @a versus
scoreboard players enable @a records
execute as @a[scores={menu=1..}] run function umetate:menu/t_menu
execute as @a[scores={field=1..}] run function umetate:menu/t_field
execute as @a[scores={leave=1..}] run function umetate:menu/t_leave
execute as @a[scores={versus=1..}] run function umetate:menu/t_versus
execute as @a[scores={records=1..}] run function umetate:menu/t_records
execute as @a[scores={um.fld=0},gamemode=adventure] unless entity @s[x=-24,y=100,z=-613,dx=48,dy=60,dz=28] run tp @s 0.5 121 -607.5 0 5
execute as @a[scores={um.frz=1..}] run function umetate:player/freeze_tick
scoreboard players add @e[type=marker,tag=um.fx] um.t 1
function umetate:f1/tick
function umetate:f2/tick
function umetate:f3/tick
function umetate:f4/tick
function umetate:f5/tick
function umetate:f6/tick
scoreboard players add #clock um.st 1
execute if score #clock um.st matches 10.. run function umetate:slow
