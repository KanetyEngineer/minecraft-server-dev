execute store result score #filled um.f3 run clone 1200 100 0 1204 119 4 1200 60 0 masked
fill 1200 60 0 1204 79 4 minecraft:air
scoreboard players operation #pct um.f3 = #filled um.f3
scoreboard players operation #pct um.f3 *= #100 um.st
scoreboard players operation #pct um.f3 /= #total um.f3
execute store result bossbar umetate:f3 value run scoreboard players get #filled um.f3
scoreboard players operation #sec um.f3 = #ticks um.f3
scoreboard players operation #sec um.f3 /= #20 um.st
scoreboard players operation #min um.f3 = #sec um.f3
scoreboard players operation #min um.f3 /= #60 um.st
scoreboard players operation #s um.f3 = #sec um.f3
scoreboard players operation #s um.f3 %= #60 um.st
bossbar set umetate:f3 name [{"text": "フィールド3 ", "color": "yellow", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f3"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f3"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f3"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f3 players @a[scores={um.fld=3}]
