execute if entity @a[scores={um.fld=3}] run return 0
execute if score #vs um.f3 matches 1.. run return 0
execute if score #reserved um.f3 matches 1 run return 0
return 1
