tp @s ~ ~ ~ ~20 ~
execute if score @s um.t matches 1 run function umetate:f3/surface
execute if score @s um.t matches 1 store result storage umetate:arg y int 1 run scoreboard players get #surf um.tmp
execute if score @s um.t matches 1 run function umetate:fx/to_surface with storage umetate:arg
particle minecraft:dust{color:[1.0,0.95,0.3],scale:1.5} ^ ^ ^3.5 0 0 0 0 1 force
particle minecraft:dust{color:[1.0,0.95,0.3],scale:1.5} ^ ^ ^-3.5 0 0 0 0 1 force
particle minecraft:dust{color:[1.0,1.0,0.7],scale:1.0} ^3.5 ^ ^ 0 0 0 0 1 force
particle minecraft:dust{color:[1.0,1.0,0.7],scale:1.0} ^-3.5 ^ ^ 0 0 0 0 1 force
particle minecraft:end_rod ^ ^ ^3 0 0 0 0 1 force
execute if score @s um.t matches 1 run playsound minecraft:item.trident.riptide_3 master @a ~ ~ ~ 1 1.8
execute if score @s um.t matches 12 run playsound minecraft:entity.player.attack.sweep master @a ~ ~ ~ 1.2 0.6
execute if score @s um.t matches 12 run particle minecraft:sweep_attack 1202.5 ~ 2.5 2 0.2 2 0 20 force
execute if score @s um.t matches 12 run scoreboard players set #depth um.tmp 2
execute if score @s um.t matches 12 run function umetate:f3/carve/all
execute if score @s um.t matches 18.. run kill @s
