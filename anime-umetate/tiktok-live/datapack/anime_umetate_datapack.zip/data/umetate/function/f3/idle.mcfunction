execute if score #vs um.f3 matches 1.. run function umetate:f3/vs_forfeit
scoreboard players set #state um.f3 0
scoreboard players set #ticks um.f3 0
kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute positioned 1202.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 1200 100 0 1204 140 4 minecraft:air
