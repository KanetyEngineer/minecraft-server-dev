execute if score @s um.t matches 1 run playsound minecraft:block.end_portal.spawn master @a 1202.5 118 2.5 1.5 1.2
execute if score @s um.t matches 1 run playsound minecraft:entity.elder_guardian.curse master @a 1202.5 118 2.5 1.5 1.4
execute if score @s um.t matches 1 as @a[scores={um.fld=3},gamemode=adventure] run function umetate:player/freeze
execute if score @s um.t matches 1..160 run particle minecraft:end_rod 1202.5 124 2.5 10 6 10 0.02 30 force
execute if score @s um.t matches 1..160 run particle minecraft:dust{color:[0.02,0.02,0.08],scale:4.0} 1202.5 124 2.5 10 6 10 0 20 force
execute if score @s um.t matches 1..160 as @a[scores={um.fld=3},gamemode=adventure] at @s run particle minecraft:enchant ~ ~1.5 ~ 0.6 0.6 0.6 1 15 force
execute if score @s um.t matches 20 run scoreboard players set #depth um.tmp 4
execute if score @s um.t matches 20 run function umetate:f3/carve/all
execute if score @s um.t matches 20 run playsound minecraft:entity.warden.sonic_boom master @a 1202.5 112 2.5 1 1.6
execute if score @s um.t matches 162.. run kill @s
