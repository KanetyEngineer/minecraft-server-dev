scoreboard players set #state um.f3 2
scoreboard players set #cd um.f3 300
kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute as @a[scores={um.fld=3}] run function umetate:player/unfreeze
title @a[scores={um.fld=3}] times 10 80 20
title @a[scores={um.fld=3}] title {"text": "埋め立て完了！", "color": "gold", "bold": true}
title @a[scores={um.fld=3}] subtitle [{"text": "タイム ", "color": "white"},{score:{name:"#min",objective:"um.f3"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f3"},color:"yellow"},{"text": "秒", "color": "white"}]
execute if score #best um.f3 matches 1.. if score #ticks um.f3 < #best um.f3 run tellraw @a[scores={um.fld=3}] {"text": "[埋め立て] フィールド3の新記録！", "color": "gold", "bold": true}
execute unless score #best um.f3 matches 1.. run scoreboard players operation #best um.f3 = #ticks um.f3
execute if score #ticks um.f3 < #best um.f3 run scoreboard players operation #best um.f3 = #ticks um.f3
execute if score #best1 um.st matches 1.. if score #ticks um.f3 < #best1 um.st run tellraw @a [{"text": "[埋め立て] 標準の最速記録更新！ ", "color": "gold", "bold": true},{selector:"@a[scores={um.fld=3},gamemode=adventure]"},{"text": " ", "color": "white"},{score:{name:"#min",objective:"um.f3"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f3"},color:"yellow"},{"text": "秒", "color": "white"}]
execute unless score #best1 um.st matches 1.. run scoreboard players operation #best1 um.st = #ticks um.f3
execute if score #ticks um.f3 < #best1 um.st run scoreboard players operation #best1 um.st = #ticks um.f3
tellraw @a[scores={um.fld=3}] [{"text": "[埋め立て] フィールド3 クリア！ ", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f3"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f3"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "。15秒後に次のラウンドが始まります（待機所へは /trigger leave）。", "color": "white"}]

execute store result storage umetate:time m int 1 run scoreboard players get #min um.f3
execute store result storage umetate:time s int 1 run scoreboard players get #s um.f3
execute store result storage umetate:time t int 1 run scoreboard players get #ticks um.f3
data modify storage umetate:time pad set value ""
execute if score #s um.f3 matches ..9 run data modify storage umetate:time pad set value "0"
data modify storage umetate:time f set value 3

execute as @a[scores={um.fld=3},gamemode=adventure] run function umetate:lb/record1
execute if score #vs um.f3 matches 1.. run function umetate:f3/vs_win
playsound minecraft:ui.toast.challenge_complete master @a 1202.5 115 2.5 2 1
playsound minecraft:entity.player.levelup master @a 1202.5 115 2.5 2 1
