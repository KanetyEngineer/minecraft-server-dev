scoreboard players set #vs um.f3 0
scoreboard players set #state um.f3 2
scoreboard players set #cd um.f3 300
kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute as @a[scores={um.fld=3}] run function umetate:player/unfreeze
title @a[scores={um.fld=3}] times 10 80 20
title @a[scores={um.fld=3}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 1202.5 115 2.5 2 0.8
