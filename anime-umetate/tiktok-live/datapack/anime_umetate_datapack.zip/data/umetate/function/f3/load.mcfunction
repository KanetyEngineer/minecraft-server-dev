scoreboard objectives add um.f3 dummy
scoreboard objectives add um.rank3 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド3", "color": "yellow", "bold": true}]
scoreboard objectives setdisplay sidebar.team.yellow um.rank3
scoreboard players set #total um.f3 500
execute unless score #state um.f3 matches 0.. run scoreboard players set #state um.f3 0
execute unless score #vs um.f3 matches 0.. run scoreboard players set #vs um.f3 0
execute unless score #reserved um.f3 matches 0.. run scoreboard players set #reserved um.f3 0
team add um.f3 {"text": "フィールド3", "color": "yellow"}
team modify um.f3 color yellow
team modify um.f3 prefix {"text": "[3] ", "color": "yellow"}
team modify um.f3 collisionRule never
team modify um.f3 friendlyFire false
bossbar add umetate:f3 {"text": "フィールド3", "color": "yellow"}
bossbar set umetate:f3 max 500
bossbar set umetate:f3 color green
bossbar set umetate:f3 style notched_10
forceload add 1184 -16 1231 31
execute unless score #built um.f3 matches 2 run schedule function umetate:f3/build 40t
