execute store result storage umetate:arg x int 1 run random value 1200..1204
execute store result storage umetate:arg z int 1 run random value 0..4
execute store result score #depth um.tmp run random value 3..8
function umetate:f3/surface
execute if score #surf um.tmp matches ..99 run return 0
scoreboard players operation #lo um.tmp = #surf um.tmp
scoreboard players operation #lo um.tmp -= #depth um.tmp
execute if score #lo um.tmp matches ..99 run scoreboard players set #lo um.tmp 100
execute store result storage umetate:arg lo int 1 run scoreboard players get #lo um.tmp
function umetate:f3/fx/slash_m with storage umetate:arg
