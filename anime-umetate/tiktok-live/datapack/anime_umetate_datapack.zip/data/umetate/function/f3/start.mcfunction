scoreboard players set #state um.f3 3
scoreboard players set #cd um.f3 70
scoreboard players set #ticks um.f3 0
scoreboard players set #empty um.f3 0
kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute positioned 1202.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 1200 100 0 1204 140 4 minecraft:air
tp @a[scores={um.fld=3},gamemode=adventure] 1202.5 100 2.5
execute as @a[scores={um.fld=3}] run function umetate:player/unfreeze
title @a[scores={um.fld=3}] times 5 40 15
title @a[scores={um.fld=3}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=3}] subtitle {"text": "フィールド3：穴を500ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f3 matches 1.. run title @a[scores={um.fld=3}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 1202.5 110 2.5 2 0.8
