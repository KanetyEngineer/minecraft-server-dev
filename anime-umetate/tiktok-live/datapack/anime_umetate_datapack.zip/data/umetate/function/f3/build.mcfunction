execute unless loaded 1190 120 -10 run return run schedule function umetate:f3/build 20t
execute unless loaded 1214 120 14 run return run schedule function umetate:f3/build 20t
fill 1190 98 -10 1214 120 14 minecraft:air
fill 1190 121 -10 1214 145 14 minecraft:air
fill 1199 98 -1 1205 98 5 minecraft:sea_lantern
fill 1199 99 -1 1205 119 5 minecraft:glass
fill 1200 99 0 1204 99 4 minecraft:bedrock
fill 1200 100 0 1204 119 4 minecraft:air
fill 1199 104 -1 1205 104 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1199 109 -1 1205 109 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1199 114 -1 1205 114 5 minecraft:yellow_stained_glass replace minecraft:glass
fill 1191 120 -9 1213 120 13 minecraft:polished_blackstone_bricks
fill 1199 120 -1 1205 120 5 minecraft:gold_block
fill 1200 120 0 1204 120 4 minecraft:air
fill 1191 120 -9 1213 120 -9 minecraft:crying_obsidian
fill 1191 120 13 1213 120 13 minecraft:crying_obsidian
fill 1191 120 -9 1191 120 13 minecraft:crying_obsidian
fill 1213 120 -9 1213 120 13 minecraft:crying_obsidian
fill 1190 121 -10 1214 145 -10 minecraft:barrier
fill 1190 121 14 1214 145 14 minecraft:barrier
fill 1190 121 -10 1190 145 14 minecraft:barrier
fill 1214 121 -10 1214 145 14 minecraft:barrier
fill 1192 121 -8 1192 127 -8 minecraft:quartz_pillar
setblock 1192 128 -8 minecraft:sea_lantern
fill 1212 121 -8 1212 127 -8 minecraft:quartz_pillar
setblock 1212 128 -8 minecraft:sea_lantern
fill 1192 121 12 1192 127 12 minecraft:quartz_pillar
setblock 1192 128 12 minecraft:sea_lantern
fill 1212 121 12 1212 127 12 minecraft:quartz_pillar
setblock 1212 128 12 minecraft:sea_lantern
setblock 1194 121 -6 minecraft:chiseled_quartz_block
setblock 1194 122 -6 minecraft:soul_lantern
setblock 1211 121 -6 minecraft:chiseled_quartz_block
setblock 1211 122 -6 minecraft:soul_lantern
setblock 1194 121 11 minecraft:chiseled_quartz_block
setblock 1194 122 11 minecraft:soul_lantern
setblock 1211 121 11 minecraft:chiseled_quartz_block
setblock 1211 122 11 minecraft:soul_lantern
setblock 1193 121 -9 minecraft:lantern
setblock 1193 121 13 minecraft:lantern
setblock 1191 121 -7 minecraft:lantern
setblock 1213 121 -7 minecraft:lantern
setblock 1197 121 -9 minecraft:lantern
setblock 1197 121 13 minecraft:lantern
setblock 1191 121 -3 minecraft:lantern
setblock 1213 121 -3 minecraft:lantern
setblock 1201 121 -9 minecraft:lantern
setblock 1201 121 13 minecraft:lantern
setblock 1191 121 1 minecraft:lantern
setblock 1213 121 1 minecraft:lantern
setblock 1205 121 -9 minecraft:lantern
setblock 1205 121 13 minecraft:lantern
setblock 1191 121 5 minecraft:lantern
setblock 1213 121 5 minecraft:lantern
setblock 1209 121 -9 minecraft:lantern
setblock 1209 121 13 minecraft:lantern
setblock 1191 121 9 minecraft:lantern
setblock 1213 121 9 minecraft:lantern
fill 1191 119 -9 1213 119 -9 minecraft:yellow_wool
execute positioned 1202.5 128 2.5 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 1202.5 133 2.5 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド3（標準 5×5×20）", "color": "yellow", "bold": true}]}
summon minecraft:text_display 1202.5 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（500ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f3 2
tellraw @a[scores={um.fld=3}] {"text": "[埋め立て] フィールド3の会場を作りました", "color": "gray"}
