execute unless blocks 1200 119 0 1204 119 4 1200 50 0 all store result score #c um.tmp run clone 1200 119 0 1204 119 4 1200 60 0 masked
execute unless blocks 1200 119 0 1204 119 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 119 0 1204 119 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 119
execute unless blocks 1200 118 0 1204 118 4 1200 50 0 all store result score #c um.tmp run clone 1200 118 0 1204 118 4 1200 60 0 masked
execute unless blocks 1200 118 0 1204 118 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 118 0 1204 118 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 118
execute unless blocks 1200 117 0 1204 117 4 1200 50 0 all store result score #c um.tmp run clone 1200 117 0 1204 117 4 1200 60 0 masked
execute unless blocks 1200 117 0 1204 117 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 117 0 1204 117 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 117
execute unless blocks 1200 116 0 1204 116 4 1200 50 0 all store result score #c um.tmp run clone 1200 116 0 1204 116 4 1200 60 0 masked
execute unless blocks 1200 116 0 1204 116 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 116 0 1204 116 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 116
execute unless blocks 1200 115 0 1204 115 4 1200 50 0 all store result score #c um.tmp run clone 1200 115 0 1204 115 4 1200 60 0 masked
execute unless blocks 1200 115 0 1204 115 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 115 0 1204 115 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 115
execute unless blocks 1200 114 0 1204 114 4 1200 50 0 all store result score #c um.tmp run clone 1200 114 0 1204 114 4 1200 60 0 masked
execute unless blocks 1200 114 0 1204 114 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 114 0 1204 114 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 114
execute unless blocks 1200 113 0 1204 113 4 1200 50 0 all store result score #c um.tmp run clone 1200 113 0 1204 113 4 1200 60 0 masked
execute unless blocks 1200 113 0 1204 113 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 113 0 1204 113 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 113
execute unless blocks 1200 112 0 1204 112 4 1200 50 0 all store result score #c um.tmp run clone 1200 112 0 1204 112 4 1200 60 0 masked
execute unless blocks 1200 112 0 1204 112 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 112 0 1204 112 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 112
execute unless blocks 1200 111 0 1204 111 4 1200 50 0 all store result score #c um.tmp run clone 1200 111 0 1204 111 4 1200 60 0 masked
execute unless blocks 1200 111 0 1204 111 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 111 0 1204 111 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 111
execute unless blocks 1200 110 0 1204 110 4 1200 50 0 all store result score #c um.tmp run clone 1200 110 0 1204 110 4 1200 60 0 masked
execute unless blocks 1200 110 0 1204 110 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 110 0 1204 110 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 110
execute unless blocks 1200 109 0 1204 109 4 1200 50 0 all store result score #c um.tmp run clone 1200 109 0 1204 109 4 1200 60 0 masked
execute unless blocks 1200 109 0 1204 109 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 109 0 1204 109 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 109
execute unless blocks 1200 108 0 1204 108 4 1200 50 0 all store result score #c um.tmp run clone 1200 108 0 1204 108 4 1200 60 0 masked
execute unless blocks 1200 108 0 1204 108 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 108 0 1204 108 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 108
execute unless blocks 1200 107 0 1204 107 4 1200 50 0 all store result score #c um.tmp run clone 1200 107 0 1204 107 4 1200 60 0 masked
execute unless blocks 1200 107 0 1204 107 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 107 0 1204 107 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 107
execute unless blocks 1200 106 0 1204 106 4 1200 50 0 all store result score #c um.tmp run clone 1200 106 0 1204 106 4 1200 60 0 masked
execute unless blocks 1200 106 0 1204 106 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 106 0 1204 106 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 106
execute unless blocks 1200 105 0 1204 105 4 1200 50 0 all store result score #c um.tmp run clone 1200 105 0 1204 105 4 1200 60 0 masked
execute unless blocks 1200 105 0 1204 105 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 105 0 1204 105 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 105
execute unless blocks 1200 104 0 1204 104 4 1200 50 0 all store result score #c um.tmp run clone 1200 104 0 1204 104 4 1200 60 0 masked
execute unless blocks 1200 104 0 1204 104 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 104 0 1204 104 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 104
execute unless blocks 1200 103 0 1204 103 4 1200 50 0 all store result score #c um.tmp run clone 1200 103 0 1204 103 4 1200 60 0 masked
execute unless blocks 1200 103 0 1204 103 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 103 0 1204 103 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 103
execute unless blocks 1200 102 0 1204 102 4 1200 50 0 all store result score #c um.tmp run clone 1200 102 0 1204 102 4 1200 60 0 masked
execute unless blocks 1200 102 0 1204 102 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 102 0 1204 102 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 102
execute unless blocks 1200 101 0 1204 101 4 1200 50 0 all store result score #c um.tmp run clone 1200 101 0 1204 101 4 1200 60 0 masked
execute unless blocks 1200 101 0 1204 101 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 101 0 1204 101 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 101
execute unless blocks 1200 100 0 1204 100 4 1200 50 0 all store result score #c um.tmp run clone 1200 100 0 1204 100 4 1200 60 0 masked
execute unless blocks 1200 100 0 1204 100 4 1200 50 0 all run fill 1200 60 0 1204 60 4 minecraft:air
execute unless blocks 1200 100 0 1204 100 4 1200 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 100
scoreboard players set #surf um.tmp 99
execute unless blocks 1200 119 0 1204 119 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 119
execute unless blocks 1200 118 0 1204 118 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 118
execute unless blocks 1200 117 0 1204 117 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 117
execute unless blocks 1200 116 0 1204 116 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 116
execute unless blocks 1200 115 0 1204 115 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 115
execute unless blocks 1200 114 0 1204 114 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 114
execute unless blocks 1200 113 0 1204 113 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 113
execute unless blocks 1200 112 0 1204 112 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 112
execute unless blocks 1200 111 0 1204 111 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 111
execute unless blocks 1200 110 0 1204 110 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 110
execute unless blocks 1200 109 0 1204 109 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 109
execute unless blocks 1200 108 0 1204 108 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 108
execute unless blocks 1200 107 0 1204 107 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 107
execute unless blocks 1200 106 0 1204 106 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 106
execute unless blocks 1200 105 0 1204 105 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 105
execute unless blocks 1200 104 0 1204 104 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 104
execute unless blocks 1200 103 0 1204 103 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 103
execute unless blocks 1200 102 0 1204 102 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 102
execute unless blocks 1200 101 0 1204 101 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 101
execute unless blocks 1200 100 0 1204 100 4 1200 50 0 all run return run scoreboard players set #surf um.tmp 100
