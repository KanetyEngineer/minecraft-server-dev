scoreboard players remove #cd um.f3 1
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 60 run title @a[scores={um.fld=3}] title {"text": "3", "color": "yellow", "bold": true}
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 40 run title @a[scores={um.fld=3}] title {"text": "2", "color": "yellow", "bold": true}
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 20 run title @a[scores={um.fld=3}] title {"text": "1", "color": "yellow", "bold": true}
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 60 run playsound minecraft:block.note_block.pling master @a 1202.5 110 2.5 2 1
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 40 run playsound minecraft:block.note_block.pling master @a 1202.5 110 2.5 2 1
execute if score #state um.f3 matches 3 if score #cd um.f3 matches 20 run playsound minecraft:block.note_block.pling master @a 1202.5 110 2.5 2 1
execute if score #state um.f3 matches 3 if score #cd um.f3 matches ..0 run title @a[scores={um.fld=3}] title {"text": "スタート！", "color": "green", "bold": true}
execute if score #state um.f3 matches 3 if score #cd um.f3 matches ..0 run playsound minecraft:block.note_block.pling master @a 1202.5 110 2.5 2 2
execute if score #state um.f3 matches 3 if score #cd um.f3 matches ..0 run return run scoreboard players set #state um.f3 1
scoreboard players operation #m um.tmp = #cd um.f3
scoreboard players operation #m um.tmp %= #20 um.st
execute if score #state um.f3 matches 2 if score #m um.tmp matches 0 positioned 1202.5 121 2.5 run function umetate:fx/firework
execute if score #state um.f3 matches 2 if score #cd um.f3 matches ..0 run scoreboard players set #state um.f3 0
