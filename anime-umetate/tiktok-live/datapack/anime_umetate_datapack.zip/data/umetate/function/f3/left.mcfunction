tag @s add um.leaving
execute if score #vs um.f3 matches 1.. unless entity @a[scores={um.fld=3},tag=!um.leaving] run function umetate:f3/vs_forfeit
tag @s remove um.leaving
team leave @s
