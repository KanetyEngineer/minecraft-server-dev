scoreboard players set #state um.f3 4
kill @e[tag=um.mob,tag=um.f3]
kill @e[type=marker,tag=um.fx,tag=um.f3]
execute as @a[scores={um.fld=3}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=3}] {"text": "[埋め立て] フィールド3を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
