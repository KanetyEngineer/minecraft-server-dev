fill 1200 120 0 1204 140 4 minecraft:air replace #umetate:fillable
function umetate:f3/count
execute as @a[scores={um.fld=3},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f3 matches 1 if score #filled um.f3 >= #total um.f3 run function umetate:f3/win
execute if score #state um.f3 matches 0 if entity @a[scores={um.fld=3},gamemode=adventure] run function umetate:f3/start
execute if entity @a[scores={um.fld=3}] run scoreboard players set #empty um.f3 0
execute unless entity @a[scores={um.fld=3}] run scoreboard players add #empty um.f3 1
execute if score #empty um.f3 matches 60 run function umetate:f3/idle
function umetate:f3/status
