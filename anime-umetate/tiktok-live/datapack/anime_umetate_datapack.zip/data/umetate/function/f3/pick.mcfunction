execute if score @s um.fld matches 3 run return run tellraw @s {"text": "すでにフィールド3にいます", "color": "gray"}
execute if score #vs um.f3 matches 1.. run return run tellraw @s {"text": "フィールド3は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f3/enter
