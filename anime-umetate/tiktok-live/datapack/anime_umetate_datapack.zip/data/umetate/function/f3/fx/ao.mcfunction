particle minecraft:reverse_portal ~ ~1 ~ 2 2 2 0.6 40 force
particle minecraft:dust{color:[0.15,0.35,1.0],scale:2.5} ~ ~1 ~ 0.3 0.3 0.3 0 10 force
execute as @e[tag=um.mob,tag=um.f3,distance=..12] at @s facing entity @e[type=marker,tag=um.m.ao,tag=um.f3,limit=1,sort=nearest] feet run tp @s ^ ^ ^0.5
execute if score @s um.t matches 1 run playsound minecraft:block.portal.trigger master @a ~ ~ ~ 0.8 1.6
execute if score @s um.t matches 1 run playsound minecraft:entity.warden.sonic_charge master @a ~ ~ ~ 0.8 1.4
execute if score @s um.t matches 25 run particle minecraft:explosion ~ ~ ~ 1 2 1 0 8 force
execute if score @s um.t matches 25 run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 0.7
execute if score @s um.t matches 25 run scoreboard players set #depth um.tmp 6
execute if score @s um.t matches 25 run scoreboard players set #r um.tmp 1
execute if score @s um.t matches 25 run function umetate:f3/carve/col
execute if score @s um.t matches 28.. run kill @s
