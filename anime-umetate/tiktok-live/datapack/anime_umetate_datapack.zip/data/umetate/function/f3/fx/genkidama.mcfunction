execute if score @s um.t matches 1 run playsound minecraft:block.beacon.activate master @a ~ ~ ~ 3 0.6
execute if score @s um.t matches 1..40 run particle minecraft:end_rod ~ ~ ~ 12 6 12 0.05 20 force
execute if score @s um.t matches 1..80 run particle minecraft:dust{color:[0.75,0.95,1.0],scale:4.0} ~ ~ ~ 2.5 2.5 2.5 0 30 force
execute if score @s um.t matches 1..80 run particle minecraft:dust{color:[1.0,1.0,1.0],scale:3.0} ~ ~ ~ 1.5 1.5 1.5 0 15 force
execute if score @s um.t matches 20 run playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 3 0.5
execute if score @s um.t matches 40 run playsound minecraft:block.conduit.activate master @a ~ ~ ~ 3 0.6
execute if score @s um.t matches 41..80 run tp @s ~ ~-0.6 ~
execute if score @s um.t matches 82 run particle minecraft:explosion_emitter 1202.5 112 2.5 2 5 2 0 8 force
execute if score @s um.t matches 82 run particle minecraft:flash{color:[0.8,0.95,1.0,1.0]} 1202.5 112 2.5 0 0 0 0 1 force
execute if score @s um.t matches 82 run playsound minecraft:entity.generic.explode master @a 1202.5 112 2.5 3 0.4
execute if score @s um.t matches 82 run playsound minecraft:entity.warden.sonic_boom master @a 1202.5 112 2.5 3 0.5
execute if score @s um.t matches 82 run scoreboard players set #depth um.tmp 12
execute if score @s um.t matches 82 run function umetate:f3/carve/all
execute if score @s um.t matches 82 positioned 1202.5 121 2.5 run function umetate:fx/firework
execute if score @s um.t matches 84.. run kill @s
