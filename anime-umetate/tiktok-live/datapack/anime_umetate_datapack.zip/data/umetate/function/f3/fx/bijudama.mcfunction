tp @s ~ ~ ~ ~30 ~
execute if score @s um.t matches 1 run playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 2 0.6
execute if score @s um.t matches 1..30 run particle minecraft:dust{color:[0.1,0.0,0.15],scale:3.5} ^2 ^ ^ 0.1 0.1 0.1 0 2 force
execute if score @s um.t matches 1..30 run particle minecraft:dust{color:[0.5,0.1,0.7],scale:2.5} ^-2 ^ ^ 0.1 0.1 0.1 0 2 force
execute if score @s um.t matches 1..30 run particle minecraft:reverse_portal ~ ~ ~ 2 2 2 0.4 20 force
execute if score @s um.t matches 10..30 run particle minecraft:dust{color:[0.08,0.0,0.12],scale:4.0} ~ ~ ~ 0.6 0.6 0.6 0 10 force
execute if score @s um.t matches 10 run playsound minecraft:block.respawn_anchor.charge master @a ~ ~ ~ 2 0.5
execute if score @s um.t matches 20 run playsound minecraft:block.respawn_anchor.charge master @a ~ ~ ~ 2 0.7
execute if score @s um.t matches 31 run playsound minecraft:entity.warden.sonic_boom master @a ~ ~ ~ 2 0.5
execute if score @s um.t matches 31..40 run scoreboard players set #steps um.tmp 52
execute if score @s um.t matches 31..40 run execute facing 1202.5 106 2.5 run function umetate:fx/beam/biju
execute if score @s um.t matches 34 run particle minecraft:explosion_emitter 1202.5 114 2.5 2 2 2 0 4 force
execute if score @s um.t matches 34 run playsound minecraft:entity.generic.explode master @a 1202.5 112 2.5 3 0.5
execute if score @s um.t matches 34 run playsound minecraft:entity.dragon_fireball.explode master @a 1202.5 112 2.5 2 0.6
execute if score @s um.t matches 34 run effect give @a[x=1200,y=99,z=0,dx=4.99,dy=22,dz=4.99] minecraft:levitation 1 10 true
execute if score @s um.t matches 34 run scoreboard players set #depth um.tmp 6
execute if score @s um.t matches 34 run function umetate:f3/carve/all
execute if score @s um.t matches 42.. run kill @s
