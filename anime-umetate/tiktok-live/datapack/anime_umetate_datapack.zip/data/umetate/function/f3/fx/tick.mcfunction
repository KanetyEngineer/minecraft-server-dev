execute if entity @s[tag=um.m.rasengan] run return run function umetate:f3/fx/rasengan
execute if entity @s[tag=um.m.kienzan] run return run function umetate:f3/fx/kienzan
execute if entity @s[tag=um.m.ao] run return run function umetate:f3/fx/ao
execute if entity @s[tag=um.m.amaterasu] run return run function umetate:f3/fx/amaterasu
execute if entity @s[tag=um.m.kamehameha] run return run function umetate:f3/fx/kamehameha
execute if entity @s[tag=um.m.bijudama] run return run function umetate:f3/fx/bijudama
execute if entity @s[tag=um.m.murasaki] run return run function umetate:f3/fx/murasaki
execute if entity @s[tag=um.m.fukuma] run return run function umetate:f3/fx/fukuma
execute if entity @s[tag=um.m.muryokusho] run return run function umetate:f3/fx/muryokusho
execute if entity @s[tag=um.m.genkidama] run return run function umetate:f3/fx/genkidama
kill @s
