scoreboard players add @a[scores={um.fld=3},gamemode=adventure] um.vswin 1
tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{selector:"@a[scores={um.fld=3},gamemode=adventure]"},{"text": " の勝ち！（フィールド3・", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f3"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f3"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "）", "color": "gold", "bold": true}]
execute as @a[scores={um.fld=3},gamemode=adventure] run function umetate:lb/vslog
execute if score #vs um.f3 matches 1 run function umetate:f1/vs_lose
execute if score #vs um.f3 matches 2 run function umetate:f2/vs_lose
execute if score #vs um.f3 matches 4 run function umetate:f4/vs_lose
scoreboard players set #vs um.f3 0
title @a[scores={um.fld=3}] subtitle {"text": "対戦に勝った！", "color": "gold", "bold": true}
