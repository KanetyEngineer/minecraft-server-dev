execute as @a[scores={um.fld=3},gamemode=adventure] unless entity @s[x=1190,y=94,z=-10,dx=24,dy=70,dz=24] run tp @s 1202.5 121 -5.5 0 10
execute as @e[type=marker,tag=um.fx,tag=um.f3] at @s run function umetate:f3/fx/tick
execute if score #state um.f3 matches 1 if entity @a[scores={um.fld=3},gamemode=adventure] run scoreboard players add #ticks um.f3 1
execute if score #state um.f3 matches 2..3 run function umetate:f3/countdown
