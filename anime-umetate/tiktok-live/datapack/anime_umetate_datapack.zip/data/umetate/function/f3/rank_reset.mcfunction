scoreboard players reset * um.rank3
