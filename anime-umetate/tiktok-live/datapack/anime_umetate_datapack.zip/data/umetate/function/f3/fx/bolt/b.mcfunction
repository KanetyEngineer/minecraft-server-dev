$summon minecraft:lightning_bolt 1204.5 $(y) 4.5
$particle minecraft:electric_spark 1204.5 $(y).5 4.5 0.6 0.6 0.6 0.8 80 force
$particle minecraft:flash{color:[1.0,0.95,0.5,1.0]} 1204.5 $(y).5 4.5 0 0 0 0 1 force
$particle minecraft:explosion 1204.5 $(y).5 4.5 0.5 0.3 0.5 0 3 force
