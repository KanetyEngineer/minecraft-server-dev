execute unless blocks 3000 119 0 3003 119 3 3000 50 0 all store result score #c um.tmp run clone 3000 119 0 3003 119 3 3000 60 0 masked
execute unless blocks 3000 119 0 3003 119 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 119 0 3003 119 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 119
execute unless blocks 3000 118 0 3003 118 3 3000 50 0 all store result score #c um.tmp run clone 3000 118 0 3003 118 3 3000 60 0 masked
execute unless blocks 3000 118 0 3003 118 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 118 0 3003 118 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 118
execute unless blocks 3000 117 0 3003 117 3 3000 50 0 all store result score #c um.tmp run clone 3000 117 0 3003 117 3 3000 60 0 masked
execute unless blocks 3000 117 0 3003 117 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 117 0 3003 117 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 117
execute unless blocks 3000 116 0 3003 116 3 3000 50 0 all store result score #c um.tmp run clone 3000 116 0 3003 116 3 3000 60 0 masked
execute unless blocks 3000 116 0 3003 116 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 116 0 3003 116 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 116
execute unless blocks 3000 115 0 3003 115 3 3000 50 0 all store result score #c um.tmp run clone 3000 115 0 3003 115 3 3000 60 0 masked
execute unless blocks 3000 115 0 3003 115 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 115 0 3003 115 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 115
execute unless blocks 3000 114 0 3003 114 3 3000 50 0 all store result score #c um.tmp run clone 3000 114 0 3003 114 3 3000 60 0 masked
execute unless blocks 3000 114 0 3003 114 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 114 0 3003 114 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 114
execute unless blocks 3000 113 0 3003 113 3 3000 50 0 all store result score #c um.tmp run clone 3000 113 0 3003 113 3 3000 60 0 masked
execute unless blocks 3000 113 0 3003 113 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 113 0 3003 113 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 113
execute unless blocks 3000 112 0 3003 112 3 3000 50 0 all store result score #c um.tmp run clone 3000 112 0 3003 112 3 3000 60 0 masked
execute unless blocks 3000 112 0 3003 112 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 112 0 3003 112 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 112
execute unless blocks 3000 111 0 3003 111 3 3000 50 0 all store result score #c um.tmp run clone 3000 111 0 3003 111 3 3000 60 0 masked
execute unless blocks 3000 111 0 3003 111 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 111 0 3003 111 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 111
execute unless blocks 3000 110 0 3003 110 3 3000 50 0 all store result score #c um.tmp run clone 3000 110 0 3003 110 3 3000 60 0 masked
execute unless blocks 3000 110 0 3003 110 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 110 0 3003 110 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 110
execute unless blocks 3000 109 0 3003 109 3 3000 50 0 all store result score #c um.tmp run clone 3000 109 0 3003 109 3 3000 60 0 masked
execute unless blocks 3000 109 0 3003 109 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 109 0 3003 109 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 109
execute unless blocks 3000 108 0 3003 108 3 3000 50 0 all store result score #c um.tmp run clone 3000 108 0 3003 108 3 3000 60 0 masked
execute unless blocks 3000 108 0 3003 108 3 3000 50 0 all run fill 3000 60 0 3003 60 3 minecraft:air
execute unless blocks 3000 108 0 3003 108 3 3000 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 108
scoreboard players set #surf um.tmp 107
execute unless blocks 3000 119 0 3003 119 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 119
execute unless blocks 3000 118 0 3003 118 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 118
execute unless blocks 3000 117 0 3003 117 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 117
execute unless blocks 3000 116 0 3003 116 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 116
execute unless blocks 3000 115 0 3003 115 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 115
execute unless blocks 3000 114 0 3003 114 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 114
execute unless blocks 3000 113 0 3003 113 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 113
execute unless blocks 3000 112 0 3003 112 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 112
execute unless blocks 3000 111 0 3003 111 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 111
execute unless blocks 3000 110 0 3003 110 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 110
execute unless blocks 3000 109 0 3003 109 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 109
execute unless blocks 3000 108 0 3003 108 3 3000 50 0 all run return run scoreboard players set #surf um.tmp 108
