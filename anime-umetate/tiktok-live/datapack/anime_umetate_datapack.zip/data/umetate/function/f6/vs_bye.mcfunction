scoreboard players set #vs um.f6 0
scoreboard players add @a[scores={um.fld=6},gamemode=adventure] um.vswin 1
title @a[scores={um.fld=6}] title {"text": "不戦勝！", "color": "gold", "bold": true}
title @a[scores={um.fld=6}] subtitle {"text": "このまま続けて記録をねらおう", "color": "white"}
