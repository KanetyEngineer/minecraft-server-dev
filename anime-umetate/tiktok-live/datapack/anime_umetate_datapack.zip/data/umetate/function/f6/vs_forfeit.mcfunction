tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{"text": "フィールド6のプレイヤーが抜けたので、相手の不戦勝です", "color": "white"}]
execute if score #vs um.f6 matches 5 run function umetate:f5/vs_bye
scoreboard players set #vs um.f6 0
