execute store result storage umetate:arg x int 1 run random value 3000..3003
execute store result storage umetate:arg z int 1 run random value 0..3
execute store result score #depth um.tmp run random value 3..8
function umetate:f6/surface
execute if score #surf um.tmp matches ..107 run return 0
scoreboard players operation #lo um.tmp = #surf um.tmp
scoreboard players operation #lo um.tmp -= #depth um.tmp
execute if score #lo um.tmp matches ..107 run scoreboard players set #lo um.tmp 108
execute store result storage umetate:arg lo int 1 run scoreboard players get #lo um.tmp
function umetate:f6/fx/slash_m with storage umetate:arg
