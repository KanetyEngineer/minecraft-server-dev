scoreboard players add @a[scores={um.fld=6},gamemode=adventure] um.vswin 1
tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{selector:"@a[scores={um.fld=6},gamemode=adventure]"},{"text": " の勝ち！（フィールド6・", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f6"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f6"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "）", "color": "gold", "bold": true}]
execute as @a[scores={um.fld=6},gamemode=adventure] run function umetate:lb/vslog
execute if score #vs um.f6 matches 5 run function umetate:f5/vs_lose
scoreboard players set #vs um.f6 0
title @a[scores={um.fld=6}] subtitle {"text": "対戦に勝った！", "color": "gold", "bold": true}
