scoreboard players set #state um.f6 3
scoreboard players set #cd um.f6 70
scoreboard players set #ticks um.f6 0
scoreboard players set #empty um.f6 0
kill @e[tag=um.mob,tag=um.f6]
kill @e[type=marker,tag=um.fx,tag=um.f6]
execute positioned 3002.0 120 2.0 run kill @e[tag=al.av,distance=..40]
fill 3000 108 0 3003 140 3 minecraft:air
tp @a[scores={um.fld=6},gamemode=adventure] 3002.5 108 2.5
execute as @a[scores={um.fld=6}] run function umetate:player/unfreeze
title @a[scores={um.fld=6}] times 5 40 15
title @a[scores={um.fld=6}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=6}] subtitle {"text": "フィールド6：穴を192ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f6 matches 1.. run title @a[scores={um.fld=6}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 3002.0 110 2.0 2 0.8
