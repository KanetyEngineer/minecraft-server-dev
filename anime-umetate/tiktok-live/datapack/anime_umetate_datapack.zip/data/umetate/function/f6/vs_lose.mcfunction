scoreboard players set #vs um.f6 0
scoreboard players set #state um.f6 2
scoreboard players set #cd um.f6 300
kill @e[tag=um.mob,tag=um.f6]
kill @e[type=marker,tag=um.fx,tag=um.f6]
execute as @a[scores={um.fld=6}] run function umetate:player/unfreeze
title @a[scores={um.fld=6}] times 10 80 20
title @a[scores={um.fld=6}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=6}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 3002.0 115 2.0 2 0.8
