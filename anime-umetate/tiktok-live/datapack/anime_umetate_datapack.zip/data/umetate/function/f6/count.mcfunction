execute store result score #filled um.f6 run clone 3000 108 0 3003 119 3 3000 60 0 masked
fill 3000 60 0 3003 71 3 minecraft:air
scoreboard players operation #pct um.f6 = #filled um.f6
scoreboard players operation #pct um.f6 *= #100 um.st
scoreboard players operation #pct um.f6 /= #total um.f6
execute store result bossbar umetate:f6 value run scoreboard players get #filled um.f6
scoreboard players operation #sec um.f6 = #ticks um.f6
scoreboard players operation #sec um.f6 /= #20 um.st
scoreboard players operation #min um.f6 = #sec um.f6
scoreboard players operation #min um.f6 /= #60 um.st
scoreboard players operation #s um.f6 = #sec um.f6
scoreboard players operation #s um.f6 %= #60 um.st
bossbar set umetate:f6 name [{"text": "フィールド6 ", "color": "red", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f6"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f6"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f6"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f6 players @a[scores={um.fld=6}]
