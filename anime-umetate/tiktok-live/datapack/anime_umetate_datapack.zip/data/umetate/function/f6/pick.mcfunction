execute if score @s um.fld matches 6 run return run tellraw @s {"text": "すでにフィールド6にいます", "color": "gray"}
execute if score #vs um.f6 matches 1.. run return run tellraw @s {"text": "フィールド6は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f6/enter
