fill 3000 120 0 3003 140 3 minecraft:air replace #umetate:fillable
function umetate:f6/count
execute as @a[scores={um.fld=6},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f6 matches 1 if score #filled um.f6 >= #total um.f6 run function umetate:f6/win
execute if score #state um.f6 matches 0 if entity @a[scores={um.fld=6},gamemode=adventure] run function umetate:f6/start
execute if entity @a[scores={um.fld=6}] run scoreboard players set #empty um.f6 0
execute unless entity @a[scores={um.fld=6}] run scoreboard players add #empty um.f6 1
execute if score #empty um.f6 matches 60 run function umetate:f6/idle
function umetate:f6/status
