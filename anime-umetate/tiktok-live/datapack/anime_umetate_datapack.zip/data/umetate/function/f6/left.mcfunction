tag @s add um.leaving
execute if score #vs um.f6 matches 1.. unless entity @a[scores={um.fld=6},tag=!um.leaving] run function umetate:f6/vs_forfeit
tag @s remove um.leaving
team leave @s
