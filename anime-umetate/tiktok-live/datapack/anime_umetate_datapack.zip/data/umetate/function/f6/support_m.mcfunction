$fill 3000 108 0 3003 $(top) 3 minecraft:lime_concrete replace minecraft:air
$execute as @a[x=3000,y=107,z=0,dx=3.99,dy=14,dz=3.99] at @s if entity @s[y=0,dy=$(top)] run tp @s ~ $(top1) ~
$particle minecraft:happy_villager 3002.0 $(top) 2.0 2 0.5 2 0 60 force
$particle minecraft:totem_of_undying 3002.0 $(top) 2.0 2 1 2 0.3 60 force
playsound minecraft:entity.player.levelup master @a 3002.0 115 2.0 1 1.4
playsound minecraft:item.totem.use master @a 3002.0 115 2.0 0.6 1.6
