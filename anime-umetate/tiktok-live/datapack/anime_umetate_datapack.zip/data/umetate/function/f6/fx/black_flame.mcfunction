$particle minecraft:dust{color:[0.05,0.0,0.06],scale:3.0} 3002.0 $(y).8 2.0 2 0.5 2 0 25 force
$particle minecraft:soul_fire_flame 3002.0 $(y).8 2.0 2 0.4 2 0.02 6 force
$particle minecraft:large_smoke 3002.0 $(y).8 2.0 2 0.4 2 0.02 6 force
