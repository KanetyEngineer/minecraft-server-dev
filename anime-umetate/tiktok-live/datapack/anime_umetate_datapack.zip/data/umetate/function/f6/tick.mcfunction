execute as @a[scores={um.fld=6},gamemode=adventure] unless entity @s[x=2990,y=94,z=-10,dx=24,dy=70,dz=24] run tp @s 3002.0 121 -5.5 0 10
execute as @e[type=marker,tag=um.fx,tag=um.f6] at @s run function umetate:f6/fx/tick
execute if score #state um.f6 matches 1 if entity @a[scores={um.fld=6},gamemode=adventure] run scoreboard players add #ticks um.f6 1
execute if score #state um.f6 matches 2..3 run function umetate:f6/countdown
