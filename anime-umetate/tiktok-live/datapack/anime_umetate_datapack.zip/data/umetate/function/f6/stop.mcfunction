scoreboard players set #state um.f6 4
kill @e[tag=um.mob,tag=um.f6]
kill @e[type=marker,tag=um.fx,tag=um.f6]
execute as @a[scores={um.fld=6}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=6}] {"text": "[埋め立て] フィールド6を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
