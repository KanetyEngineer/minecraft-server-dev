execute unless loaded 2990 120 -10 run return run schedule function umetate:f6/build 20t
execute unless loaded 3014 120 14 run return run schedule function umetate:f6/build 20t
fill 2990 98 -10 3014 120 14 minecraft:air
fill 2990 121 -10 3014 145 14 minecraft:air
fill 2999 106 -1 3004 106 4 minecraft:sea_lantern
fill 2999 107 -1 3004 119 4 minecraft:glass
fill 3000 107 0 3003 107 3 minecraft:bedrock
fill 3000 108 0 3003 119 3 minecraft:air
fill 2999 110 -1 3004 110 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2999 113 -1 3004 113 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2999 116 -1 3004 116 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2991 120 -9 3013 120 13 minecraft:polished_blackstone_bricks
fill 2999 120 -1 3004 120 4 minecraft:gold_block
fill 3000 120 0 3003 120 3 minecraft:air
fill 2991 120 -9 3013 120 -9 minecraft:crying_obsidian
fill 2991 120 13 3013 120 13 minecraft:crying_obsidian
fill 2991 120 -9 2991 120 13 minecraft:crying_obsidian
fill 3013 120 -9 3013 120 13 minecraft:crying_obsidian
fill 2990 121 -10 3014 145 -10 minecraft:barrier
fill 2990 121 14 3014 145 14 minecraft:barrier
fill 2990 121 -10 2990 145 14 minecraft:barrier
fill 3014 121 -10 3014 145 14 minecraft:barrier
fill 2992 121 -8 2992 127 -8 minecraft:quartz_pillar
setblock 2992 128 -8 minecraft:sea_lantern
fill 3012 121 -8 3012 127 -8 minecraft:quartz_pillar
setblock 3012 128 -8 minecraft:sea_lantern
fill 2992 121 12 2992 127 12 minecraft:quartz_pillar
setblock 2992 128 12 minecraft:sea_lantern
fill 3012 121 12 3012 127 12 minecraft:quartz_pillar
setblock 3012 128 12 minecraft:sea_lantern
setblock 2994 121 -6 minecraft:chiseled_quartz_block
setblock 2994 122 -6 minecraft:soul_lantern
setblock 3011 121 -6 minecraft:chiseled_quartz_block
setblock 3011 122 -6 minecraft:soul_lantern
setblock 2994 121 11 minecraft:chiseled_quartz_block
setblock 2994 122 11 minecraft:soul_lantern
setblock 3011 121 11 minecraft:chiseled_quartz_block
setblock 3011 122 11 minecraft:soul_lantern
setblock 2993 121 -9 minecraft:lantern
setblock 2993 121 13 minecraft:lantern
setblock 2991 121 -7 minecraft:lantern
setblock 3013 121 -7 minecraft:lantern
setblock 2997 121 -9 minecraft:lantern
setblock 2997 121 13 minecraft:lantern
setblock 2991 121 -3 minecraft:lantern
setblock 3013 121 -3 minecraft:lantern
setblock 3001 121 -9 minecraft:lantern
setblock 3001 121 13 minecraft:lantern
setblock 2991 121 1 minecraft:lantern
setblock 3013 121 1 minecraft:lantern
setblock 3005 121 -9 minecraft:lantern
setblock 3005 121 13 minecraft:lantern
setblock 2991 121 5 minecraft:lantern
setblock 3013 121 5 minecraft:lantern
setblock 3009 121 -9 minecraft:lantern
setblock 3009 121 13 minecraft:lantern
setblock 2991 121 9 minecraft:lantern
setblock 3013 121 9 minecraft:lantern
fill 2991 119 -9 3013 119 -9 minecraft:red_wool
execute positioned 3002.0 128 2.0 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 3002.0 133 2.0 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド6（ミニ 4×4×12）", "color": "red", "bold": true}]}
summon minecraft:text_display 3002.0 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（192ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f6 2
tellraw @a[scores={um.fld=6}] {"text": "[埋め立て] フィールド6の会場を作りました", "color": "gray"}
