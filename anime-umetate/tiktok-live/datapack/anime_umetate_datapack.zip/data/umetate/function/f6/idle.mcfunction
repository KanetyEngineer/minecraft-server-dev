execute if score #vs um.f6 matches 1.. run function umetate:f6/vs_forfeit
scoreboard players set #state um.f6 0
scoreboard players set #ticks um.f6 0
kill @e[tag=um.mob,tag=um.f6]
kill @e[type=marker,tag=um.fx,tag=um.f6]
execute positioned 3002.0 120 2.0 run kill @e[tag=al.av,distance=..40]
fill 3000 108 0 3003 140 3 minecraft:air
