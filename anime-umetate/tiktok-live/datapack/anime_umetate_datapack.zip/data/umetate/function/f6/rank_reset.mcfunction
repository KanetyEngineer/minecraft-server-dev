scoreboard players reset * um.rank6
