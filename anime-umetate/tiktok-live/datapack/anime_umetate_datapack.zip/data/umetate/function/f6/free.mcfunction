execute if entity @a[scores={um.fld=6}] run return 0
execute if score #vs um.f6 matches 1.. run return 0
execute if score #reserved um.f6 matches 1 run return 0
return 1
