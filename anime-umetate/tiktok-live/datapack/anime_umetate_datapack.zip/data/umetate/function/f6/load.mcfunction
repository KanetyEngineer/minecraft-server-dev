scoreboard objectives add um.f6 dummy
scoreboard objectives add um.rank6 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド6", "color": "red", "bold": true}]
scoreboard objectives setdisplay sidebar.team.red um.rank6
scoreboard players set #total um.f6 192
execute unless score #state um.f6 matches 0.. run scoreboard players set #state um.f6 0
execute unless score #vs um.f6 matches 0.. run scoreboard players set #vs um.f6 0
execute unless score #reserved um.f6 matches 0.. run scoreboard players set #reserved um.f6 0
team add um.f6 {"text": "フィールド6", "color": "red"}
team modify um.f6 color red
team modify um.f6 prefix {"text": "[6] ", "color": "red"}
team modify um.f6 collisionRule never
team modify um.f6 friendlyFire false
bossbar add umetate:f6 {"text": "フィールド6", "color": "red"}
bossbar set umetate:f6 max 192
bossbar set umetate:f6 color green
bossbar set umetate:f6 style notched_10
forceload add 2984 -16 3031 31
execute unless score #built um.f6 matches 2 run schedule function umetate:f6/build 40t
