execute if score @s um.t matches 1 run playsound minecraft:item.firecharge.use master @a 3002.0 115 2.0 1.5 0.5
execute if score @s um.t matches 1..60 run function umetate:f6/surface
execute if score @s um.t matches 1..60 store result storage umetate:arg y int 1 run scoreboard players get #surf um.tmp
execute if score @s um.t matches 1..60 run function umetate:f6/fx/black_flame with storage umetate:arg
execute if score @s um.t matches 10 run scoreboard players set #depth um.tmp 1
execute if score @s um.t matches 10 run function umetate:f6/carve/all
execute if score @s um.t matches 30 run scoreboard players set #depth um.tmp 1
execute if score @s um.t matches 30 run function umetate:f6/carve/all
execute if score @s um.t matches 10 run playsound minecraft:block.fire.extinguish master @a 3002.0 115 2.0 1 0.5
execute if score @s um.t matches 30 run playsound minecraft:block.fire.extinguish master @a 3002.0 115 2.0 1 0.5
execute if score @s um.t matches 50 run playsound minecraft:block.fire.extinguish master @a 3002.0 115 2.0 1 0.5
execute if score @s um.t matches 62.. run kill @s
