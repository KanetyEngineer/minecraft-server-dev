scoreboard players set #clock um.st 0
effect give @a minecraft:night_vision infinite 0 true
effect give @a minecraft:resistance infinite 4 true
effect give @a minecraft:saturation infinite 0 true
function umetate:f1/slow
function umetate:f2/slow
function umetate:f3/slow
function umetate:f4/slow
function umetate:f5/slow
function umetate:f6/slow
function umetate:hub/slow
