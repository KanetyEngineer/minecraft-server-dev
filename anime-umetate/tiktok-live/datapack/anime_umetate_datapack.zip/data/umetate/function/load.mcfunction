scoreboard objectives add um.st dummy
scoreboard objectives add um.tmp dummy
scoreboard objectives add um.t dummy
scoreboard objectives add um.frz dummy
scoreboard objectives add um.leave minecraft.custom:minecraft.leave_game
scoreboard objectives add um.fld dummy
scoreboard objectives add um.home dummy
scoreboard objectives add um.vswin dummy
scoreboard objectives add menu trigger {"text": "メニュー", "color": "white"}
scoreboard objectives add field trigger {"text": "フィールドを選ぶ", "color": "white"}
scoreboard objectives add leave trigger {"text": "待機所へ戻る", "color": "white"}
scoreboard objectives add versus trigger {"text": "対戦", "color": "white"}
scoreboard objectives add records trigger {"text": "記録", "color": "white"}
scoreboard objectives add um.lb1 dummy [{"text": "最速ランキング ", "color": "gold", "bold": true},{"text": "標準 5×5×20", "color": "yellow", "bold": true}]
scoreboard objectives add um.lb2 dummy [{"text": "最速ランキング ", "color": "gold", "bold": true},{"text": "ミニ 4×4×12", "color": "yellow", "bold": true}]
scoreboard objectives setdisplay sidebar um.lb1
scoreboard players set #100 um.st 100
scoreboard players set #60 um.st 60
scoreboard players set #20 um.st 20
scoreboard players set #4 um.st 4
scoreboard players set #-1 um.st -1
bossbar remove umetate:progress
gamerule fall_damage false
gamerule keep_inventory true
gamerule advance_time false
gamerule advance_weather false
gamerule spawn_mobs false
gamerule spawn_monsters false
gamerule immediate_respawn true
gamerule show_advancement_messages false
gamerule show_death_messages false
gamerule mob_griefing false
gamerule mob_drops false
gamerule block_drops false
gamerule respawn_radius 0
gamerule max_command_sequence_length 1000000
gamerule max_block_modifications 1000000
time set 14000
weather clear
forceload add -32 -616 32 -569
execute unless data storage umetate:lb vslog run data modify storage umetate:lb vslog set value []
execute unless data storage umetate:lb p1 run data modify storage umetate:lb p1 set value []
execute unless data storage umetate:lb p2 run data modify storage umetate:lb p2 set value []
function umetate:f1/load
function umetate:f2/load
function umetate:f3/load
function umetate:f4/load
function umetate:f5/load
function umetate:f6/load
execute unless score #hubbuilt um.st matches 2 run schedule function umetate:hub/build 40t
