scoreboard players set #state um.f1 2
scoreboard players set #cd um.f1 300
kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute as @a[scores={um.fld=1}] run function umetate:player/unfreeze
title @a[scores={um.fld=1}] times 10 80 20
title @a[scores={um.fld=1}] title {"text": "埋め立て完了！", "color": "gold", "bold": true}
title @a[scores={um.fld=1}] subtitle [{"text": "タイム ", "color": "white"},{score:{name:"#min",objective:"um.f1"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f1"},color:"yellow"},{"text": "秒", "color": "white"}]
execute if score #best um.f1 matches 1.. if score #ticks um.f1 < #best um.f1 run tellraw @a[scores={um.fld=1}] {"text": "[埋め立て] フィールド1の新記録！", "color": "gold", "bold": true}
execute unless score #best um.f1 matches 1.. run scoreboard players operation #best um.f1 = #ticks um.f1
execute if score #ticks um.f1 < #best um.f1 run scoreboard players operation #best um.f1 = #ticks um.f1
execute if score #best1 um.st matches 1.. if score #ticks um.f1 < #best1 um.st run tellraw @a [{"text": "[埋め立て] 標準の最速記録更新！ ", "color": "gold", "bold": true},{selector:"@a[scores={um.fld=1},gamemode=adventure]"},{"text": " ", "color": "white"},{score:{name:"#min",objective:"um.f1"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f1"},color:"yellow"},{"text": "秒", "color": "white"}]
execute unless score #best1 um.st matches 1.. run scoreboard players operation #best1 um.st = #ticks um.f1
execute if score #ticks um.f1 < #best1 um.st run scoreboard players operation #best1 um.st = #ticks um.f1
tellraw @a[scores={um.fld=1}] [{"text": "[埋め立て] フィールド1 クリア！ ", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f1"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f1"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "。15秒後に次のラウンドが始まります（待機所へは /trigger leave）。", "color": "white"}]

execute store result storage umetate:time m int 1 run scoreboard players get #min um.f1
execute store result storage umetate:time s int 1 run scoreboard players get #s um.f1
execute store result storage umetate:time t int 1 run scoreboard players get #ticks um.f1
data modify storage umetate:time pad set value ""
execute if score #s um.f1 matches ..9 run data modify storage umetate:time pad set value "0"
data modify storage umetate:time f set value 1

execute as @a[scores={um.fld=1},gamemode=adventure] run function umetate:lb/record1
execute if score #vs um.f1 matches 1.. run function umetate:f1/vs_win
playsound minecraft:ui.toast.challenge_complete master @a 2.5 115 2.5 2 1
playsound minecraft:entity.player.levelup master @a 2.5 115 2.5 2 1
