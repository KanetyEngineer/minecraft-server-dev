$fill 0 $(lo) 0 4 119 4 minecraft:air replace #umetate:fillable
$particle minecraft:block{block_state:"minecraft:lime_concrete"} 2.5 $(lo) 2.5 2 1.5 2 0 160 force
$particle minecraft:explosion 2.5 $(lo) 2.5 2 1 2 0 6 force
$playsound minecraft:block.stone.break master @a 2.5 $(lo) 2.5 1.5 0.7
