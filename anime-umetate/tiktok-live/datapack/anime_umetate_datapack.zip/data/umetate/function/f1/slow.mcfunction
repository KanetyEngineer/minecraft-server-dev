fill 0 120 0 4 140 4 minecraft:air replace #umetate:fillable
function umetate:f1/count
execute as @a[scores={um.fld=1},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f1 matches 1 if score #filled um.f1 >= #total um.f1 run function umetate:f1/win
execute if score #state um.f1 matches 0 if entity @a[scores={um.fld=1},gamemode=adventure] run function umetate:f1/start
execute if entity @a[scores={um.fld=1}] run scoreboard players set #empty um.f1 0
execute unless entity @a[scores={um.fld=1}] run scoreboard players add #empty um.f1 1
execute if score #empty um.f1 matches 60 run function umetate:f1/idle
function umetate:f1/status
