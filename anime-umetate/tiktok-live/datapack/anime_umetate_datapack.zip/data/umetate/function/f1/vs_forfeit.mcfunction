tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{"text": "フィールド1のプレイヤーが抜けたので、相手の不戦勝です", "color": "white"}]
execute if score #vs um.f1 matches 2 run function umetate:f2/vs_bye
execute if score #vs um.f1 matches 3 run function umetate:f3/vs_bye
execute if score #vs um.f1 matches 4 run function umetate:f4/vs_bye
scoreboard players set #vs um.f1 0
