execute if score @s um.t matches 1 run playsound minecraft:entity.illusioner.cast_spell master @a ~ ~ ~ 2 0.6
execute if score @s um.t matches 1..12 run particle minecraft:dust{color:[1.0,0.1,0.1],scale:2.5} ~-4 ~ ~ 0.3 0.3 0.3 0 6 force
execute if score @s um.t matches 1..12 run particle minecraft:dust{color:[0.1,0.3,1.0],scale:2.5} ~4 ~ ~ 0.3 0.3 0.3 0 6 force
execute if score @s um.t matches 13..22 run particle minecraft:dust{color:[1.0,0.1,0.1],scale:2.5} ~-1.5 ~ ~ 0.3 0.3 0.3 0 6 force
execute if score @s um.t matches 13..22 run particle minecraft:dust{color:[0.1,0.3,1.0],scale:2.5} ~1.5 ~ ~ 0.3 0.3 0.3 0 6 force
execute if score @s um.t matches 13 run playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 2 0.5
execute if score @s um.t matches 23 run playsound minecraft:block.end_portal.spawn master @a ~ ~ ~ 1.5 1.5
execute if score @s um.t matches 23..34 run particle minecraft:dust{color:[0.65,0.15,0.95],scale:4.0} ~ ~ ~ 0.9 0.9 0.9 0 20 force
execute if score @s um.t matches 23..34 run particle minecraft:dust_color_transition{from_color:[1.0,0.1,0.2],to_color:[0.2,0.3,1.0],scale:2} ~ ~ ~ 1 1 1 0 10 force
execute if score @s um.t matches 35 run playsound minecraft:entity.warden.sonic_boom master @a 2.5 112 2.5 2 0.6
execute if score @s um.t matches 35 run playsound minecraft:entity.generic.explode master @a 2.5 112 2.5 2 0.6
execute if score @s um.t matches 35..45 run particle minecraft:dust{color:[0.65,0.15,0.95],scale:4.0} 2.5 113 2.5 1.6 8 1.6 0 60 force
execute if score @s um.t matches 37 run particle minecraft:explosion_emitter 2.5 112 2.5 1 4 1 0 4 force
execute if score @s um.t matches 37 run scoreboard players set #depth um.tmp 8
execute if score @s um.t matches 37 run function umetate:f1/carve/all
execute if score @s um.t matches 47.. run kill @s
