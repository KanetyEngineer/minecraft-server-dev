scoreboard players reset * um.rank1
