execute unless loaded -10 120 -10 run return run schedule function umetate:f1/build 20t
execute unless loaded 14 120 14 run return run schedule function umetate:f1/build 20t
fill -10 98 -10 14 120 14 minecraft:air
fill -10 121 -10 14 145 14 minecraft:air
fill -1 98 -1 5 98 5 minecraft:sea_lantern
fill -1 99 -1 5 119 5 minecraft:glass
fill 0 99 0 4 99 4 minecraft:bedrock
fill 0 100 0 4 119 4 minecraft:air
fill -1 104 -1 5 104 5 minecraft:yellow_stained_glass replace minecraft:glass
fill -1 109 -1 5 109 5 minecraft:yellow_stained_glass replace minecraft:glass
fill -1 114 -1 5 114 5 minecraft:yellow_stained_glass replace minecraft:glass
fill -9 120 -9 13 120 13 minecraft:polished_blackstone_bricks
fill -1 120 -1 5 120 5 minecraft:gold_block
fill 0 120 0 4 120 4 minecraft:air
fill -9 120 -9 13 120 -9 minecraft:crying_obsidian
fill -9 120 13 13 120 13 minecraft:crying_obsidian
fill -9 120 -9 -9 120 13 minecraft:crying_obsidian
fill 13 120 -9 13 120 13 minecraft:crying_obsidian
fill -10 121 -10 14 145 -10 minecraft:barrier
fill -10 121 14 14 145 14 minecraft:barrier
fill -10 121 -10 -10 145 14 minecraft:barrier
fill 14 121 -10 14 145 14 minecraft:barrier
fill -8 121 -8 -8 127 -8 minecraft:quartz_pillar
setblock -8 128 -8 minecraft:sea_lantern
fill 12 121 -8 12 127 -8 minecraft:quartz_pillar
setblock 12 128 -8 minecraft:sea_lantern
fill -8 121 12 -8 127 12 minecraft:quartz_pillar
setblock -8 128 12 minecraft:sea_lantern
fill 12 121 12 12 127 12 minecraft:quartz_pillar
setblock 12 128 12 minecraft:sea_lantern
setblock -6 121 -6 minecraft:chiseled_quartz_block
setblock -6 122 -6 minecraft:soul_lantern
setblock 11 121 -6 minecraft:chiseled_quartz_block
setblock 11 122 -6 minecraft:soul_lantern
setblock -6 121 11 minecraft:chiseled_quartz_block
setblock -6 122 11 minecraft:soul_lantern
setblock 11 121 11 minecraft:chiseled_quartz_block
setblock 11 122 11 minecraft:soul_lantern
setblock -7 121 -9 minecraft:lantern
setblock -7 121 13 minecraft:lantern
setblock -9 121 -7 minecraft:lantern
setblock 13 121 -7 minecraft:lantern
setblock -3 121 -9 minecraft:lantern
setblock -3 121 13 minecraft:lantern
setblock -9 121 -3 minecraft:lantern
setblock 13 121 -3 minecraft:lantern
setblock 1 121 -9 minecraft:lantern
setblock 1 121 13 minecraft:lantern
setblock -9 121 1 minecraft:lantern
setblock 13 121 1 minecraft:lantern
setblock 5 121 -9 minecraft:lantern
setblock 5 121 13 minecraft:lantern
setblock -9 121 5 minecraft:lantern
setblock 13 121 5 minecraft:lantern
setblock 9 121 -9 minecraft:lantern
setblock 9 121 13 minecraft:lantern
setblock -9 121 9 minecraft:lantern
setblock 13 121 9 minecraft:lantern
fill -9 119 -9 13 119 -9 minecraft:light_blue_wool
execute positioned 2.5 128 2.5 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 2.5 133 2.5 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド1（標準 5×5×20）", "color": "aqua", "bold": true}]}
summon minecraft:text_display 2.5 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（500ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f1 2
tellraw @a[scores={um.fld=1}] {"text": "[埋め立て] フィールド1の会場を作りました", "color": "gray"}
