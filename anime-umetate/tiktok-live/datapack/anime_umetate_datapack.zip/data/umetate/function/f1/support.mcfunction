function umetate:f1/surface
scoreboard players operation #top um.tmp = #surf um.tmp
scoreboard players operation #top um.tmp += #add um.tmp
execute if score #top um.tmp matches 120.. run scoreboard players set #top um.tmp 119
execute store result storage umetate:arg top int 1 run scoreboard players get #top um.tmp
scoreboard players add #top um.tmp 1
execute store result storage umetate:arg top1 int 1 run scoreboard players get #top um.tmp
function umetate:f1/support_m with storage umetate:arg
