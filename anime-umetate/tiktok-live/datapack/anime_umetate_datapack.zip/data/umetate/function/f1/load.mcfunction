scoreboard objectives add um.f1 dummy
scoreboard objectives add um.rank1 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド1", "color": "aqua", "bold": true}]
scoreboard objectives setdisplay sidebar.team.aqua um.rank1
scoreboard players set #total um.f1 500
execute unless score #state um.f1 matches 0.. run scoreboard players set #state um.f1 0
execute unless score #vs um.f1 matches 0.. run scoreboard players set #vs um.f1 0
execute unless score #reserved um.f1 matches 0.. run scoreboard players set #reserved um.f1 0
team add um.f1 {"text": "フィールド1", "color": "aqua"}
team modify um.f1 color aqua
team modify um.f1 prefix {"text": "[1] ", "color": "aqua"}
team modify um.f1 collisionRule never
team modify um.f1 friendlyFire false
bossbar add umetate:f1 {"text": "フィールド1", "color": "aqua"}
bossbar set umetate:f1 max 500
bossbar set umetate:f1 color green
bossbar set umetate:f1 style notched_10
forceload add -16 -16 31 31
execute unless score #built um.f1 matches 2 run schedule function umetate:f1/build 40t
