scoreboard players set #vs um.f1 0
scoreboard players set #state um.f1 2
scoreboard players set #cd um.f1 300
kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute as @a[scores={um.fld=1}] run function umetate:player/unfreeze
title @a[scores={um.fld=1}] times 10 80 20
title @a[scores={um.fld=1}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 2.5 115 2.5 2 0.8
