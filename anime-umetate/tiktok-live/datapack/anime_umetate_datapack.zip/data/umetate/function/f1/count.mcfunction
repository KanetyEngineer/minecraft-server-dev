execute store result score #filled um.f1 run clone 0 100 0 4 119 4 0 60 0 masked
fill 0 60 0 4 79 4 minecraft:air
scoreboard players operation #pct um.f1 = #filled um.f1
scoreboard players operation #pct um.f1 *= #100 um.st
scoreboard players operation #pct um.f1 /= #total um.f1
execute store result bossbar umetate:f1 value run scoreboard players get #filled um.f1
scoreboard players operation #sec um.f1 = #ticks um.f1
scoreboard players operation #sec um.f1 /= #20 um.st
scoreboard players operation #min um.f1 = #sec um.f1
scoreboard players operation #min um.f1 /= #60 um.st
scoreboard players operation #s um.f1 = #sec um.f1
scoreboard players operation #s um.f1 %= #60 um.st
bossbar set umetate:f1 name [{"text": "フィールド1 ", "color": "aqua", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f1"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f1"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f1"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f1 players @a[scores={um.fld=1}]
