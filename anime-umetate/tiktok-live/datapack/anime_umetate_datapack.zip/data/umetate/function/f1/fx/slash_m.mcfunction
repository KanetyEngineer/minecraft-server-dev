$fill $(x) $(lo) $(z) $(x) 119 $(z) minecraft:air replace #umetate:fillable
$particle minecraft:sweep_attack $(x).5 119 $(z).5 0.3 3 0.3 0 6 force
$particle minecraft:dust{color:[0.8,0.0,0.0],scale:2.0} $(x).5 119 $(z).5 0.2 4 0.2 0 30 force
$playsound minecraft:entity.player.attack.sweep master @a $(x) 119 $(z) 1.2 0.6
