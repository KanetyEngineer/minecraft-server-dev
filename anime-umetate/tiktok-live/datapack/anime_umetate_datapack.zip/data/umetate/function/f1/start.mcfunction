scoreboard players set #state um.f1 3
scoreboard players set #cd um.f1 70
scoreboard players set #ticks um.f1 0
scoreboard players set #empty um.f1 0
kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute positioned 2.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 0 100 0 4 140 4 minecraft:air
tp @a[scores={um.fld=1},gamemode=adventure] 2.5 100 2.5
execute as @a[scores={um.fld=1}] run function umetate:player/unfreeze
title @a[scores={um.fld=1}] times 5 40 15
title @a[scores={um.fld=1}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "フィールド1：穴を500ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f1 matches 1.. run title @a[scores={um.fld=1}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 2.5 110 2.5 2 0.8
