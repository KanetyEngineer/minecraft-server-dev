scoreboard players set #vs um.f1 0
scoreboard players add @a[scores={um.fld=1},gamemode=adventure] um.vswin 1
title @a[scores={um.fld=1}] title {"text": "不戦勝！", "color": "gold", "bold": true}
title @a[scores={um.fld=1}] subtitle {"text": "このまま続けて記録をねらおう", "color": "white"}
