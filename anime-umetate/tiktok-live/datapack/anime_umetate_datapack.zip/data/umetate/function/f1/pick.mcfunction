execute if score @s um.fld matches 1 run return run tellraw @s {"text": "すでにフィールド1にいます", "color": "gray"}
execute if score #vs um.f1 matches 1.. run return run tellraw @s {"text": "フィールド1は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f1/enter
