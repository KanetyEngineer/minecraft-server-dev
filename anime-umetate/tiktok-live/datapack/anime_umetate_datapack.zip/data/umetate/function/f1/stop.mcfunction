scoreboard players set #state um.f1 4
kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute as @a[scores={um.fld=1}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=1}] {"text": "[埋め立て] フィールド1を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
