execute if score #vs um.f1 matches 1.. run function umetate:f1/vs_forfeit
scoreboard players set #state um.f1 0
scoreboard players set #ticks um.f1 0
kill @e[tag=um.mob,tag=um.f1]
kill @e[type=marker,tag=um.fx,tag=um.f1]
execute positioned 2.5 120 2.5 run kill @e[tag=al.av,distance=..40]
fill 0 100 0 4 140 4 minecraft:air
