$fill ~-$(r) $(lo) ~-$(r) ~$(r) 119 ~$(r) minecraft:air replace #umetate:fillable
$particle minecraft:block{block_state:"minecraft:white_concrete"} ~ $(lo) ~ 1 1.5 1 0 80 force
$playsound minecraft:block.stone.break master @a ~ $(lo) ~ 1.5 0.7
