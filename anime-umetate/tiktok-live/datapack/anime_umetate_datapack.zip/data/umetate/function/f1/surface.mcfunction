execute unless blocks 0 119 0 4 119 4 0 50 0 all store result score #c um.tmp run clone 0 119 0 4 119 4 0 60 0 masked
execute unless blocks 0 119 0 4 119 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 119 0 4 119 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 119
execute unless blocks 0 118 0 4 118 4 0 50 0 all store result score #c um.tmp run clone 0 118 0 4 118 4 0 60 0 masked
execute unless blocks 0 118 0 4 118 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 118 0 4 118 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 118
execute unless blocks 0 117 0 4 117 4 0 50 0 all store result score #c um.tmp run clone 0 117 0 4 117 4 0 60 0 masked
execute unless blocks 0 117 0 4 117 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 117 0 4 117 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 117
execute unless blocks 0 116 0 4 116 4 0 50 0 all store result score #c um.tmp run clone 0 116 0 4 116 4 0 60 0 masked
execute unless blocks 0 116 0 4 116 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 116 0 4 116 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 116
execute unless blocks 0 115 0 4 115 4 0 50 0 all store result score #c um.tmp run clone 0 115 0 4 115 4 0 60 0 masked
execute unless blocks 0 115 0 4 115 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 115 0 4 115 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 115
execute unless blocks 0 114 0 4 114 4 0 50 0 all store result score #c um.tmp run clone 0 114 0 4 114 4 0 60 0 masked
execute unless blocks 0 114 0 4 114 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 114 0 4 114 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 114
execute unless blocks 0 113 0 4 113 4 0 50 0 all store result score #c um.tmp run clone 0 113 0 4 113 4 0 60 0 masked
execute unless blocks 0 113 0 4 113 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 113 0 4 113 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 113
execute unless blocks 0 112 0 4 112 4 0 50 0 all store result score #c um.tmp run clone 0 112 0 4 112 4 0 60 0 masked
execute unless blocks 0 112 0 4 112 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 112 0 4 112 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 112
execute unless blocks 0 111 0 4 111 4 0 50 0 all store result score #c um.tmp run clone 0 111 0 4 111 4 0 60 0 masked
execute unless blocks 0 111 0 4 111 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 111 0 4 111 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 111
execute unless blocks 0 110 0 4 110 4 0 50 0 all store result score #c um.tmp run clone 0 110 0 4 110 4 0 60 0 masked
execute unless blocks 0 110 0 4 110 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 110 0 4 110 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 110
execute unless blocks 0 109 0 4 109 4 0 50 0 all store result score #c um.tmp run clone 0 109 0 4 109 4 0 60 0 masked
execute unless blocks 0 109 0 4 109 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 109 0 4 109 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 109
execute unless blocks 0 108 0 4 108 4 0 50 0 all store result score #c um.tmp run clone 0 108 0 4 108 4 0 60 0 masked
execute unless blocks 0 108 0 4 108 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 108 0 4 108 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 108
execute unless blocks 0 107 0 4 107 4 0 50 0 all store result score #c um.tmp run clone 0 107 0 4 107 4 0 60 0 masked
execute unless blocks 0 107 0 4 107 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 107 0 4 107 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 107
execute unless blocks 0 106 0 4 106 4 0 50 0 all store result score #c um.tmp run clone 0 106 0 4 106 4 0 60 0 masked
execute unless blocks 0 106 0 4 106 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 106 0 4 106 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 106
execute unless blocks 0 105 0 4 105 4 0 50 0 all store result score #c um.tmp run clone 0 105 0 4 105 4 0 60 0 masked
execute unless blocks 0 105 0 4 105 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 105 0 4 105 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 105
execute unless blocks 0 104 0 4 104 4 0 50 0 all store result score #c um.tmp run clone 0 104 0 4 104 4 0 60 0 masked
execute unless blocks 0 104 0 4 104 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 104 0 4 104 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 104
execute unless blocks 0 103 0 4 103 4 0 50 0 all store result score #c um.tmp run clone 0 103 0 4 103 4 0 60 0 masked
execute unless blocks 0 103 0 4 103 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 103 0 4 103 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 103
execute unless blocks 0 102 0 4 102 4 0 50 0 all store result score #c um.tmp run clone 0 102 0 4 102 4 0 60 0 masked
execute unless blocks 0 102 0 4 102 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 102 0 4 102 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 102
execute unless blocks 0 101 0 4 101 4 0 50 0 all store result score #c um.tmp run clone 0 101 0 4 101 4 0 60 0 masked
execute unless blocks 0 101 0 4 101 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 101 0 4 101 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 101
execute unless blocks 0 100 0 4 100 4 0 50 0 all store result score #c um.tmp run clone 0 100 0 4 100 4 0 60 0 masked
execute unless blocks 0 100 0 4 100 4 0 50 0 all run fill 0 60 0 4 60 4 minecraft:air
execute unless blocks 0 100 0 4 100 4 0 50 0 all if score #c um.tmp matches 13.. run return run scoreboard players set #surf um.tmp 100
scoreboard players set #surf um.tmp 99
execute unless blocks 0 119 0 4 119 4 0 50 0 all run return run scoreboard players set #surf um.tmp 119
execute unless blocks 0 118 0 4 118 4 0 50 0 all run return run scoreboard players set #surf um.tmp 118
execute unless blocks 0 117 0 4 117 4 0 50 0 all run return run scoreboard players set #surf um.tmp 117
execute unless blocks 0 116 0 4 116 4 0 50 0 all run return run scoreboard players set #surf um.tmp 116
execute unless blocks 0 115 0 4 115 4 0 50 0 all run return run scoreboard players set #surf um.tmp 115
execute unless blocks 0 114 0 4 114 4 0 50 0 all run return run scoreboard players set #surf um.tmp 114
execute unless blocks 0 113 0 4 113 4 0 50 0 all run return run scoreboard players set #surf um.tmp 113
execute unless blocks 0 112 0 4 112 4 0 50 0 all run return run scoreboard players set #surf um.tmp 112
execute unless blocks 0 111 0 4 111 4 0 50 0 all run return run scoreboard players set #surf um.tmp 111
execute unless blocks 0 110 0 4 110 4 0 50 0 all run return run scoreboard players set #surf um.tmp 110
execute unless blocks 0 109 0 4 109 4 0 50 0 all run return run scoreboard players set #surf um.tmp 109
execute unless blocks 0 108 0 4 108 4 0 50 0 all run return run scoreboard players set #surf um.tmp 108
execute unless blocks 0 107 0 4 107 4 0 50 0 all run return run scoreboard players set #surf um.tmp 107
execute unless blocks 0 106 0 4 106 4 0 50 0 all run return run scoreboard players set #surf um.tmp 106
execute unless blocks 0 105 0 4 105 4 0 50 0 all run return run scoreboard players set #surf um.tmp 105
execute unless blocks 0 104 0 4 104 4 0 50 0 all run return run scoreboard players set #surf um.tmp 104
execute unless blocks 0 103 0 4 103 4 0 50 0 all run return run scoreboard players set #surf um.tmp 103
execute unless blocks 0 102 0 4 102 4 0 50 0 all run return run scoreboard players set #surf um.tmp 102
execute unless blocks 0 101 0 4 101 4 0 50 0 all run return run scoreboard players set #surf um.tmp 101
execute unless blocks 0 100 0 4 100 4 0 50 0 all run return run scoreboard players set #surf um.tmp 100
