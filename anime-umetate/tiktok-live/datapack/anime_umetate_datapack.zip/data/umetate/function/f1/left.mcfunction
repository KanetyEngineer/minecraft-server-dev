tag @s add um.leaving
execute if score #vs um.f1 matches 1.. unless entity @a[scores={um.fld=1},tag=!um.leaving] run function umetate:f1/vs_forfeit
tag @s remove um.leaving
team leave @s
