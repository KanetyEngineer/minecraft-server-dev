execute if entity @a[scores={um.fld=1}] run return 0
execute if score #vs um.f1 matches 1.. run return 0
execute if score #reserved um.f1 matches 1 run return 0
return 1
