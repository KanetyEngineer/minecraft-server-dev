execute store result score #nq um.tmp if entity @a[tag=um.vq1]
execute if score #nq um.tmp matches 2.. run function umetate:vs/try1
execute store result score #nq um.tmp if entity @a[tag=um.vq2]
execute if score #nq um.tmp matches 2.. run function umetate:vs/try2
function umetate:hub/signs
scoreboard players add #hubclock um.st 1
execute if score #hubclock um.st matches 20.. run function umetate:hub/rotate
