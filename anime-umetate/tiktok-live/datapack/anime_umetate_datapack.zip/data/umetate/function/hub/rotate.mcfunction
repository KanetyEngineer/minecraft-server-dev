scoreboard players set #hubclock um.st 0
scoreboard players add #lbshow um.st 1
execute if score #lbshow um.st matches 3.. run scoreboard players set #lbshow um.st 1
execute if score #lbshow um.st matches 1 run scoreboard objectives setdisplay sidebar um.lb1
execute if score #lbshow um.st matches 2 run scoreboard objectives setdisplay sidebar um.lb2
