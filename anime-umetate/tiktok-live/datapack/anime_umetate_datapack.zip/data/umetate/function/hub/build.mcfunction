execute unless loaded -24 120 -613 run return run schedule function umetate:hub/build 20t
execute unless loaded 24 120 -585 run return run schedule function umetate:hub/build 20t
fill -25 108 -614 25 150 -584 minecraft:air
fill -24 120 -613 24 120 -585 minecraft:smooth_quartz
fill -24 120 -613 24 120 -613 minecraft:crying_obsidian
fill -24 120 -585 24 120 -585 minecraft:crying_obsidian
fill -24 120 -613 -24 120 -585 minecraft:crying_obsidian
fill 24 120 -613 24 120 -585 minecraft:crying_obsidian
fill -2 120 -609 2 120 -606 minecraft:gold_block
fill -25 121 -614 25 150 -614 minecraft:barrier
fill -25 121 -584 25 150 -584 minecraft:barrier
fill -25 121 -614 -25 150 -584 minecraft:barrier
fill 25 121 -614 25 150 -584 minecraft:barrier
setblock -22 121 -613 minecraft:lantern
setblock -22 121 -585 minecraft:lantern
setblock -16 121 -613 minecraft:lantern
setblock -16 121 -585 minecraft:lantern
setblock -10 121 -613 minecraft:lantern
setblock -10 121 -585 minecraft:lantern
setblock -4 121 -613 minecraft:lantern
setblock -4 121 -585 minecraft:lantern
setblock 2 121 -613 minecraft:lantern
setblock 2 121 -585 minecraft:lantern
setblock 8 121 -613 minecraft:lantern
setblock 8 121 -585 minecraft:lantern
setblock 14 121 -613 minecraft:lantern
setblock 14 121 -585 minecraft:lantern
setblock 20 121 -613 minecraft:lantern
setblock 20 121 -585 minecraft:lantern
setblock 0 112 -600 minecraft:barrel
kill @e[tag=um.hubdeco]
fill -21 120 -596 -19 120 -594 minecraft:light_blue_wool
setblock -20 121 -595 minecraft:beacon
summon minecraft:interaction -19.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f1"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display -19.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f1"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill -16 120 -596 -14 120 -594 minecraft:lime_wool
setblock -15 121 -595 minecraft:beacon
summon minecraft:interaction -14.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f2"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display -14.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f2"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill -11 120 -596 -9 120 -594 minecraft:yellow_wool
setblock -10 121 -595 minecraft:beacon
summon minecraft:interaction -9.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f3"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display -9.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f3"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill -6 120 -596 -4 120 -594 minecraft:magenta_wool
setblock -5 121 -595 minecraft:beacon
summon minecraft:interaction -4.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f4"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display -4.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f4"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill -1 120 -596 1 120 -594 minecraft:orange_wool
setblock 0 121 -595 minecraft:beacon
summon minecraft:interaction 0.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f5"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display 0.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f5"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill 4 120 -596 6 120 -594 minecraft:red_wool
setblock 5 121 -595 minecraft:beacon
summon minecraft:interaction 5.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.f6"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display 5.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.f6"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill 9 120 -596 11 120 -594 minecraft:red_wool
setblock 10 121 -595 minecraft:lodestone
summon minecraft:interaction 10.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.vs1"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display 10.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.vs1"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill 14 120 -596 16 120 -594 minecraft:red_wool
setblock 15 121 -595 minecraft:lodestone
summon minecraft:interaction 15.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.vs2"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display 15.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.vs2"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
fill 19 120 -596 21 120 -594 minecraft:white_wool
setblock 20 121 -595 minecraft:bookshelf
summon minecraft:interaction 20.5 121 -594.5 {Tags:["um.hubdeco","um.kiosk","um.k.rec"],width:1.8f,height:2.6f,response:1b}
summon minecraft:text_display 20.5 123.9 -594.5 {Tags:["um.hubdeco","um.klbl.rec"],billboard:"center",background:1426063360,line_width:150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},text:{text:"…"}}
summon minecraft:text_display 0.5 131 -588 {Tags:["um.hubdeco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "待機所：遊ぶフィールドを選ぼう", "color": "aqua"}]}
summon minecraft:text_display 0.5 127.6 -588 {Tags:["um.hubdeco"],billboard:"center",background:1426063360,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.2f,1.2f,1.2f]},text:[{"text": "看板を右クリック、またはチャットのメニュー（/trigger menu）で参加", "color": "white"},{text:"\n"},{"text": "対戦：同じ種類の2人がそろうと2つのフィールドで同時スタート。先に100%で勝ち", "color": "red"},{text:"\n"},{"text": "右のサイドバーは最速ランキング。フィールドから戻る: /trigger leave", "color": "gray"}]}
setworldspawn 0 121 -608
scoreboard players set #hubbuilt um.st 2
function umetate:hub/signs
tellraw @a {"text":"[埋め立て] 待機所を作りました","color":"gray"}
