tag @s add um.leaving
execute if score #vs um.f5 matches 1.. unless entity @a[scores={um.fld=5},tag=!um.leaving] run function umetate:f5/vs_forfeit
tag @s remove um.leaving
team leave @s
