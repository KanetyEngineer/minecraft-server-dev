fill 2400 120 0 2403 140 3 minecraft:air replace #umetate:fillable
function umetate:f5/count
execute as @a[scores={um.fld=5},gamemode=adventure] run function umetate:player/refill
execute if score #state um.f5 matches 1 if score #filled um.f5 >= #total um.f5 run function umetate:f5/win
execute if score #state um.f5 matches 0 if entity @a[scores={um.fld=5},gamemode=adventure] run function umetate:f5/start
execute if entity @a[scores={um.fld=5}] run scoreboard players set #empty um.f5 0
execute unless entity @a[scores={um.fld=5}] run scoreboard players add #empty um.f5 1
execute if score #empty um.f5 matches 60 run function umetate:f5/idle
function umetate:f5/status
