execute store result score #filled um.f5 run clone 2400 108 0 2403 119 3 2400 60 0 masked
fill 2400 60 0 2403 71 3 minecraft:air
scoreboard players operation #pct um.f5 = #filled um.f5
scoreboard players operation #pct um.f5 *= #100 um.st
scoreboard players operation #pct um.f5 /= #total um.f5
execute store result bossbar umetate:f5 value run scoreboard players get #filled um.f5
scoreboard players operation #sec um.f5 = #ticks um.f5
scoreboard players operation #sec um.f5 /= #20 um.st
scoreboard players operation #min um.f5 = #sec um.f5
scoreboard players operation #min um.f5 /= #60 um.st
scoreboard players operation #s um.f5 = #sec um.f5
scoreboard players operation #s um.f5 %= #60 um.st
bossbar set umetate:f5 name [{"text": "フィールド5 ", "color": "gold", "bold": true},{"text": "埋め立て ", "color": "white", "bold": true},{score:{name:"#pct",objective:"um.f5"},color:"yellow",bold:true},{"text": "%", "color": "yellow", "bold": true},{"text": "   ⏱ ", "color": "gray"},{score:{name:"#min",objective:"um.f5"},color:"white"},{"text": "分", "color": "gray"},{score:{name:"#s",objective:"um.f5"},color:"white"},{"text": "秒", "color": "gray"}]
bossbar set umetate:f5 players @a[scores={um.fld=5}]
