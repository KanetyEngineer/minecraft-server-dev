scoreboard players set @s um.fld 5
tag @s remove um.vq1
tag @s remove um.vq2
tag @s remove um.vqw
team join um.f5 @s
clear @s
function umetate:player/unfreeze
scoreboard players set #empty um.f5 0
execute if score #state um.f5 matches 1 run tp @s 2402.5 120 2.5
execute if score #state um.f5 matches 3 run tp @s 2402.5 108 2.5
execute unless score #state um.f5 matches 1 unless score #state um.f5 matches 3 run tp @s 2402.0 121 -5.5 0 10
function umetate:player/refill
bossbar set umetate:f5 players @a[scores={um.fld=5}]
tellraw @s [{"text": "[埋め立て] フィールド5（ミニ 4×4×12）", "color": "gold", "bold": true},{"text": " 穴（192ブロック）を下から埋めきったらクリア！ ブロックは自動で補充されます。", "color": "white"}]
tellraw @s [{"text": "待機所へ戻る: ", "color": "gray"},{"text": "[待機所へ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "/trigger leave"}, "hover_event": {"action": "show_text", "value": "フィールドを選び直す"}},{"text": "  ロビーへ: /trigger lobby", "color": "gray"}]
