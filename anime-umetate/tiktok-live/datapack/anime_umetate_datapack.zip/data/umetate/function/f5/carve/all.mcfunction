function umetate:f5/surface
execute if score #surf um.tmp matches ..107 run return 0
scoreboard players operation #lo um.tmp = #surf um.tmp
scoreboard players operation #lo um.tmp -= #depth um.tmp
scoreboard players add #lo um.tmp 1
execute if score #lo um.tmp matches ..107 run scoreboard players set #lo um.tmp 108
execute store result storage umetate:arg lo int 1 run scoreboard players get #lo um.tmp
function umetate:f5/carve/all_m with storage umetate:arg
