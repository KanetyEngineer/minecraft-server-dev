$fill 2400 $(lo) 0 2403 119 3 minecraft:air replace #umetate:fillable
$particle minecraft:block{block_state:"minecraft:lime_concrete"} 2402.0 $(lo) 2.0 2 1.5 2 0 160 force
$particle minecraft:explosion 2402.0 $(lo) 2.0 2 1 2 0 6 force
$playsound minecraft:block.stone.break master @a 2402.0 $(lo) 2.0 1.5 0.7
