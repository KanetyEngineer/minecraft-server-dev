scoreboard players set #state um.f5 3
scoreboard players set #cd um.f5 70
scoreboard players set #ticks um.f5 0
scoreboard players set #empty um.f5 0
kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute positioned 2402.0 120 2.0 run kill @e[tag=al.av,distance=..40]
fill 2400 108 0 2403 140 3 minecraft:air
tp @a[scores={um.fld=5},gamemode=adventure] 2402.5 108 2.5
execute as @a[scores={um.fld=5}] run function umetate:player/unfreeze
title @a[scores={um.fld=5}] times 5 40 15
title @a[scores={um.fld=5}] title {"text": "埋め立て開始", "color": "gold", "bold": true}
title @a[scores={um.fld=5}] subtitle {"text": "フィールド5：穴を192ブロックで埋めきろう！", "color": "yellow"}
execute if score #vs um.f5 matches 1.. run title @a[scores={um.fld=5}] subtitle {"text": "対戦！ 先に100%にしたほうの勝ち", "color": "red"}
playsound minecraft:block.bell.use master @a 2402.0 110 2.0 2 0.8
