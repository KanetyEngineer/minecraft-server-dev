execute if score #vs um.f5 matches 1.. run function umetate:f5/vs_forfeit
scoreboard players set #state um.f5 0
scoreboard players set #ticks um.f5 0
kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute positioned 2402.0 120 2.0 run kill @e[tag=al.av,distance=..40]
fill 2400 108 0 2403 140 3 minecraft:air
