execute store result score #np um.f5 if entity @a[scores={um.fld=5},gamemode=adventure]
data modify storage umetate:arg col set value "green"
data modify storage umetate:arg stxt set value "空き"
execute if score #np um.f5 matches 1.. run data modify storage umetate:arg stxt set value "待機中"
execute if score #state um.f5 matches 3 run data modify storage umetate:arg stxt set value "カウントダウン"
execute if score #state um.f5 matches 1 run data modify storage umetate:arg stxt set value "プレイ中"
execute if score #state um.f5 matches 2 run data modify storage umetate:arg stxt set value "クリア！"
execute if score #state um.f5 matches 4 run data modify storage umetate:arg stxt set value "一時停止"
execute if score #np um.f5 matches 1.. run data modify storage umetate:arg col set value "yellow"
execute if score #state um.f5 matches 2 run data modify storage umetate:arg col set value "gold"
execute if score #state um.f5 matches 4 run data modify storage umetate:arg col set value "gray"
data modify storage umetate:arg vs set value ""
execute if score #vs um.f5 matches 1.. run data modify storage umetate:arg vs set value "・対戦中"
execute if score #reserved um.f5 matches 1 run data modify storage umetate:arg vs set value "・配信者用"
execute if score #vs um.f5 matches 1.. run data modify storage umetate:arg col set value "red"
execute store result storage umetate:arg pct int 1 run scoreboard players get #pct um.f5
execute store result storage umetate:arg np int 1 run scoreboard players get #np um.f5
execute store result storage umetate:arg m int 1 run scoreboard players get #min um.f5
execute store result storage umetate:arg s int 1 run scoreboard players get #s um.f5
data modify storage umetate:arg pad set value ""
execute if score #s um.f5 matches ..9 run data modify storage umetate:arg pad set value "0"
data modify storage umetate:arg best set value "まだなし"
scoreboard players operation #bs um.tmp = #best um.f5
scoreboard players operation #bs um.tmp /= #20 um.st
scoreboard players operation #bm um.tmp = #bs um.tmp
scoreboard players operation #bm um.tmp /= #60 um.st
scoreboard players operation #bs um.tmp %= #60 um.st
execute store result storage umetate:arg bm int 1 run scoreboard players get #bm um.tmp
execute store result storage umetate:arg bs int 1 run scoreboard players get #bs um.tmp
data modify storage umetate:arg bpad set value ""
execute if score #bs um.tmp matches ..9 run data modify storage umetate:arg bpad set value "0"
execute if score #best um.f5 matches 1.. run function umetate:hub/best_m with storage umetate:arg
function umetate:f5/status_m with storage umetate:arg
execute store result storage umetate:report f5.state int 1 run scoreboard players get #state um.f5
execute store result storage umetate:report f5.pct int 1 run scoreboard players get #pct um.f5
execute store result storage umetate:report f5.filled int 1 run scoreboard players get #filled um.f5
execute store result storage umetate:report f5.total int 1 run scoreboard players get #total um.f5
execute store result storage umetate:report f5.ticks int 1 run scoreboard players get #ticks um.f5
execute store result storage umetate:report f5.best int 1 run scoreboard players get #best um.f5
execute store result storage umetate:report f5.np int 1 run scoreboard players get #np um.f5
execute store result storage umetate:report f5.vs int 1 run scoreboard players get #vs um.f5
