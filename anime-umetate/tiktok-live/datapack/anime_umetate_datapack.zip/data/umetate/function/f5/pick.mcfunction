execute if score @s um.fld matches 5 run return run tellraw @s {"text": "すでにフィールド5にいます", "color": "gray"}
execute if score #vs um.f5 matches 1.. run return run tellraw @s {"text": "フィールド5は対戦中なので入れません。ほかのフィールドを選んでください", "color": "red"}
function umetate:player/leave_field
function umetate:f5/enter
