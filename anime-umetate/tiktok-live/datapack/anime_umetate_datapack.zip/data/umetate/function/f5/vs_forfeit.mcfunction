tellraw @a [{"text": "[対戦] ", "color": "red", "bold": true},{"text": "フィールド5のプレイヤーが抜けたので、相手の不戦勝です", "color": "white"}]
execute if score #vs um.f5 matches 6 run function umetate:f6/vs_bye
scoreboard players set #vs um.f5 0
