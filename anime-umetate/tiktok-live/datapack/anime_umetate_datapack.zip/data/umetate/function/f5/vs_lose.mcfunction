scoreboard players set #vs um.f5 0
scoreboard players set #state um.f5 2
scoreboard players set #cd um.f5 300
kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute as @a[scores={um.fld=5}] run function umetate:player/unfreeze
title @a[scores={um.fld=5}] times 10 80 20
title @a[scores={um.fld=5}] title {"text": "負け…", "color": "gray", "bold": true}
title @a[scores={um.fld=5}] subtitle {"text": "相手が先に埋めきった", "color": "white"}
playsound minecraft:entity.villager.no master @a 2402.0 115 2.0 2 0.8
