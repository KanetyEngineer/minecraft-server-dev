scoreboard players set #state um.f5 4
kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute as @a[scores={um.fld=5}] run function umetate:player/unfreeze
tellraw @a[scores={um.fld=5}] {"text": "[埋め立て] フィールド5を一時停止しました（パネルの「新しいラウンド」で再開）", "color": "gray"}
