execute unless loaded 2390 120 -10 run return run schedule function umetate:f5/build 20t
execute unless loaded 2414 120 14 run return run schedule function umetate:f5/build 20t
fill 2390 98 -10 2414 120 14 minecraft:air
fill 2390 121 -10 2414 145 14 minecraft:air
fill 2399 106 -1 2404 106 4 minecraft:sea_lantern
fill 2399 107 -1 2404 119 4 minecraft:glass
fill 2400 107 0 2403 107 3 minecraft:bedrock
fill 2400 108 0 2403 119 3 minecraft:air
fill 2399 110 -1 2404 110 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2399 113 -1 2404 113 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2399 116 -1 2404 116 4 minecraft:yellow_stained_glass replace minecraft:glass
fill 2391 120 -9 2413 120 13 minecraft:polished_blackstone_bricks
fill 2399 120 -1 2404 120 4 minecraft:gold_block
fill 2400 120 0 2403 120 3 minecraft:air
fill 2391 120 -9 2413 120 -9 minecraft:crying_obsidian
fill 2391 120 13 2413 120 13 minecraft:crying_obsidian
fill 2391 120 -9 2391 120 13 minecraft:crying_obsidian
fill 2413 120 -9 2413 120 13 minecraft:crying_obsidian
fill 2390 121 -10 2414 145 -10 minecraft:barrier
fill 2390 121 14 2414 145 14 minecraft:barrier
fill 2390 121 -10 2390 145 14 minecraft:barrier
fill 2414 121 -10 2414 145 14 minecraft:barrier
fill 2392 121 -8 2392 127 -8 minecraft:quartz_pillar
setblock 2392 128 -8 minecraft:sea_lantern
fill 2412 121 -8 2412 127 -8 minecraft:quartz_pillar
setblock 2412 128 -8 minecraft:sea_lantern
fill 2392 121 12 2392 127 12 minecraft:quartz_pillar
setblock 2392 128 12 minecraft:sea_lantern
fill 2412 121 12 2412 127 12 minecraft:quartz_pillar
setblock 2412 128 12 minecraft:sea_lantern
setblock 2394 121 -6 minecraft:chiseled_quartz_block
setblock 2394 122 -6 minecraft:soul_lantern
setblock 2411 121 -6 minecraft:chiseled_quartz_block
setblock 2411 122 -6 minecraft:soul_lantern
setblock 2394 121 11 minecraft:chiseled_quartz_block
setblock 2394 122 11 minecraft:soul_lantern
setblock 2411 121 11 minecraft:chiseled_quartz_block
setblock 2411 122 11 minecraft:soul_lantern
setblock 2393 121 -9 minecraft:lantern
setblock 2393 121 13 minecraft:lantern
setblock 2391 121 -7 minecraft:lantern
setblock 2413 121 -7 minecraft:lantern
setblock 2397 121 -9 minecraft:lantern
setblock 2397 121 13 minecraft:lantern
setblock 2391 121 -3 minecraft:lantern
setblock 2413 121 -3 minecraft:lantern
setblock 2401 121 -9 minecraft:lantern
setblock 2401 121 13 minecraft:lantern
setblock 2391 121 1 minecraft:lantern
setblock 2413 121 1 minecraft:lantern
setblock 2405 121 -9 minecraft:lantern
setblock 2405 121 13 minecraft:lantern
setblock 2391 121 5 minecraft:lantern
setblock 2413 121 5 minecraft:lantern
setblock 2409 121 -9 minecraft:lantern
setblock 2409 121 13 minecraft:lantern
setblock 2391 121 9 minecraft:lantern
setblock 2413 121 9 minecraft:lantern
fill 2391 119 -9 2413 119 -9 minecraft:orange_wool
execute positioned 2402.0 128 2.0 run kill @e[type=text_display,tag=um.deco,distance=..30]
summon minecraft:text_display 2402.0 133 2.0 {Tags:["um.deco"],billboard:"center",background:1073741824,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4f,4f,4f]},text:[{"text": "アニメ技の埋め立て", "color": "gold", "bold": true},{text:"\n"},{"text": "フィールド5（ミニ 4×4×12）", "color": "gold", "bold": true}]}
summon minecraft:text_display 2402.0 122.5 -8.4 {Tags:["um.deco"],billboard:"fixed",Rotation:[0f,0f],background:1426063360,line_width:260,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},text:[{"text": "ルール", "color": "gold", "bold": true},{text:"\n"},{"text": "穴（192ブロック）を下から埋めて100%にしたらクリア。ブロックは自動で補充されます。", "color": "white"},{text:"\n"},{"text": "ギフトでアニメの技が飛んできて、埋めたブロックが崩されます。いいね・シェアは助けてくれます。", "color": "yellow"},{text:"\n"},{"text": "待機所へ戻る: /trigger leave", "color": "gray"}]}
scoreboard players set #built um.f5 2
tellraw @a[scores={um.fld=5}] {"text": "[埋め立て] フィールド5の会場を作りました", "color": "gray"}
