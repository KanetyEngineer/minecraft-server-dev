execute if entity @a[scores={um.fld=5}] run return 0
execute if score #vs um.f5 matches 1.. run return 0
execute if score #reserved um.f5 matches 1 run return 0
return 1
