scoreboard players set #state um.f5 2
scoreboard players set #cd um.f5 300
kill @e[tag=um.mob,tag=um.f5]
kill @e[type=marker,tag=um.fx,tag=um.f5]
execute as @a[scores={um.fld=5}] run function umetate:player/unfreeze
title @a[scores={um.fld=5}] times 10 80 20
title @a[scores={um.fld=5}] title {"text": "埋め立て完了！", "color": "gold", "bold": true}
title @a[scores={um.fld=5}] subtitle [{"text": "タイム ", "color": "white"},{score:{name:"#min",objective:"um.f5"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f5"},color:"yellow"},{"text": "秒", "color": "white"}]
execute if score #best um.f5 matches 1.. if score #ticks um.f5 < #best um.f5 run tellraw @a[scores={um.fld=5}] {"text": "[埋め立て] フィールド5の新記録！", "color": "gold", "bold": true}
execute unless score #best um.f5 matches 1.. run scoreboard players operation #best um.f5 = #ticks um.f5
execute if score #ticks um.f5 < #best um.f5 run scoreboard players operation #best um.f5 = #ticks um.f5
execute if score #best2 um.st matches 1.. if score #ticks um.f5 < #best2 um.st run tellraw @a [{"text": "[埋め立て] ミニの最速記録更新！ ", "color": "gold", "bold": true},{selector:"@a[scores={um.fld=5},gamemode=adventure]"},{"text": " ", "color": "white"},{score:{name:"#min",objective:"um.f5"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f5"},color:"yellow"},{"text": "秒", "color": "white"}]
execute unless score #best2 um.st matches 1.. run scoreboard players operation #best2 um.st = #ticks um.f5
execute if score #ticks um.f5 < #best2 um.st run scoreboard players operation #best2 um.st = #ticks um.f5
tellraw @a[scores={um.fld=5}] [{"text": "[埋め立て] フィールド5 クリア！ ", "color": "gold", "bold": true},{score:{name:"#min",objective:"um.f5"},color:"yellow"},{"text": "分", "color": "white"},{score:{name:"#s",objective:"um.f5"},color:"yellow"},{"text": "秒", "color": "white"},{"text": "。15秒後に次のラウンドが始まります（待機所へは /trigger leave）。", "color": "white"}]

execute store result storage umetate:time m int 1 run scoreboard players get #min um.f5
execute store result storage umetate:time s int 1 run scoreboard players get #s um.f5
execute store result storage umetate:time t int 1 run scoreboard players get #ticks um.f5
data modify storage umetate:time pad set value ""
execute if score #s um.f5 matches ..9 run data modify storage umetate:time pad set value "0"
data modify storage umetate:time f set value 5

execute as @a[scores={um.fld=5},gamemode=adventure] run function umetate:lb/record2
execute if score #vs um.f5 matches 1.. run function umetate:f5/vs_win
playsound minecraft:ui.toast.challenge_complete master @a 2402.0 115 2.0 2 1
playsound minecraft:entity.player.levelup master @a 2402.0 115 2.0 2 1
