execute unless blocks 2400 119 0 2403 119 3 2400 50 0 all store result score #c um.tmp run clone 2400 119 0 2403 119 3 2400 60 0 masked
execute unless blocks 2400 119 0 2403 119 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 119 0 2403 119 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 119
execute unless blocks 2400 118 0 2403 118 3 2400 50 0 all store result score #c um.tmp run clone 2400 118 0 2403 118 3 2400 60 0 masked
execute unless blocks 2400 118 0 2403 118 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 118 0 2403 118 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 118
execute unless blocks 2400 117 0 2403 117 3 2400 50 0 all store result score #c um.tmp run clone 2400 117 0 2403 117 3 2400 60 0 masked
execute unless blocks 2400 117 0 2403 117 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 117 0 2403 117 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 117
execute unless blocks 2400 116 0 2403 116 3 2400 50 0 all store result score #c um.tmp run clone 2400 116 0 2403 116 3 2400 60 0 masked
execute unless blocks 2400 116 0 2403 116 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 116 0 2403 116 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 116
execute unless blocks 2400 115 0 2403 115 3 2400 50 0 all store result score #c um.tmp run clone 2400 115 0 2403 115 3 2400 60 0 masked
execute unless blocks 2400 115 0 2403 115 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 115 0 2403 115 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 115
execute unless blocks 2400 114 0 2403 114 3 2400 50 0 all store result score #c um.tmp run clone 2400 114 0 2403 114 3 2400 60 0 masked
execute unless blocks 2400 114 0 2403 114 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 114 0 2403 114 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 114
execute unless blocks 2400 113 0 2403 113 3 2400 50 0 all store result score #c um.tmp run clone 2400 113 0 2403 113 3 2400 60 0 masked
execute unless blocks 2400 113 0 2403 113 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 113 0 2403 113 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 113
execute unless blocks 2400 112 0 2403 112 3 2400 50 0 all store result score #c um.tmp run clone 2400 112 0 2403 112 3 2400 60 0 masked
execute unless blocks 2400 112 0 2403 112 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 112 0 2403 112 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 112
execute unless blocks 2400 111 0 2403 111 3 2400 50 0 all store result score #c um.tmp run clone 2400 111 0 2403 111 3 2400 60 0 masked
execute unless blocks 2400 111 0 2403 111 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 111 0 2403 111 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 111
execute unless blocks 2400 110 0 2403 110 3 2400 50 0 all store result score #c um.tmp run clone 2400 110 0 2403 110 3 2400 60 0 masked
execute unless blocks 2400 110 0 2403 110 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 110 0 2403 110 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 110
execute unless blocks 2400 109 0 2403 109 3 2400 50 0 all store result score #c um.tmp run clone 2400 109 0 2403 109 3 2400 60 0 masked
execute unless blocks 2400 109 0 2403 109 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 109 0 2403 109 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 109
execute unless blocks 2400 108 0 2403 108 3 2400 50 0 all store result score #c um.tmp run clone 2400 108 0 2403 108 3 2400 60 0 masked
execute unless blocks 2400 108 0 2403 108 3 2400 50 0 all run fill 2400 60 0 2403 60 3 minecraft:air
execute unless blocks 2400 108 0 2403 108 3 2400 50 0 all if score #c um.tmp matches 9.. run return run scoreboard players set #surf um.tmp 108
scoreboard players set #surf um.tmp 107
execute unless blocks 2400 119 0 2403 119 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 119
execute unless blocks 2400 118 0 2403 118 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 118
execute unless blocks 2400 117 0 2403 117 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 117
execute unless blocks 2400 116 0 2403 116 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 116
execute unless blocks 2400 115 0 2403 115 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 115
execute unless blocks 2400 114 0 2403 114 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 114
execute unless blocks 2400 113 0 2403 113 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 113
execute unless blocks 2400 112 0 2403 112 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 112
execute unless blocks 2400 111 0 2403 111 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 111
execute unless blocks 2400 110 0 2403 110 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 110
execute unless blocks 2400 109 0 2403 109 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 109
execute unless blocks 2400 108 0 2403 108 3 2400 50 0 all run return run scoreboard players set #surf um.tmp 108
