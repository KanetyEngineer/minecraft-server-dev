execute if score @s um.t matches 1 run title @a[scores={um.fld=5}] actionbar {"text": "か…", "color": "aqua", "bold": true}
execute if score @s um.t matches 7 run title @a[scores={um.fld=5}] actionbar {"text": "か…め…", "color": "aqua", "bold": true}
execute if score @s um.t matches 13 run title @a[scores={um.fld=5}] actionbar {"text": "か…め…は…", "color": "aqua", "bold": true}
execute if score @s um.t matches 19 run title @a[scores={um.fld=5}] actionbar {"text": "か…め…は…め…", "color": "aqua", "bold": true}
execute if score @s um.t matches 28 run title @a[scores={um.fld=5}] actionbar {"text": "波ーーーッ！！", "color": "aqua", "bold": true}
execute if score @s um.t matches 1 run playsound minecraft:entity.warden.sonic_charge master @a ~ ~ ~ 2 1.2
execute if score @s um.t matches 10 run playsound minecraft:block.beacon.activate master @a ~ ~ ~ 2 1.5
execute if score @s um.t matches 1..27 run particle minecraft:dust{color:[0.45,0.85,1.0],scale:2.5} ~ ~ ~ 0.25 0.25 0.25 0 6 force
execute if score @s um.t matches 14..27 run particle minecraft:dust{color:[0.8,0.95,1.0],scale:3.5} ~ ~ ~ 0.45 0.45 0.45 0 8 force
execute if score @s um.t matches 1..27 run particle minecraft:end_rod ~ ~ ~ 1.2 1.2 1.2 0.05 3 force
execute if score @s um.t matches 28 run playsound minecraft:entity.warden.sonic_boom master @a ~ ~ ~ 2 0.8
execute if score @s um.t matches 28 run playsound minecraft:entity.warden.sonic_boom master @a 2402.0 112 2.0 2 0.8
execute if score @s um.t matches 28..44 run scoreboard players set #steps um.tmp 52
execute if score @s um.t matches 28..44 run execute facing 2402.0 106 2.0 run function umetate:fx/beam/kame
execute if score @s um.t matches 31 run particle minecraft:explosion_emitter 2402.0 114 2.0 1 1 1 0 2 force
execute if score @s um.t matches 31 run playsound minecraft:entity.generic.explode master @a 2402.0 112 2.0 2 0.8
execute if score @s um.t matches 31 run scoreboard players set #depth um.tmp 3
execute if score @s um.t matches 31 run function umetate:f5/carve/all
execute if score @s um.t matches 46.. run kill @s
