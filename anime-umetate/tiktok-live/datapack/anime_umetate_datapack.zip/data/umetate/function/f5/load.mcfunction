scoreboard objectives add um.f5 dummy
scoreboard objectives add um.rank5 dummy [{"text": "妨害ランキング ", "color": "light_purple", "bold": true},{"text": "フィールド5", "color": "gold", "bold": true}]
scoreboard objectives setdisplay sidebar.team.gold um.rank5
scoreboard players set #total um.f5 192
execute unless score #state um.f5 matches 0.. run scoreboard players set #state um.f5 0
execute unless score #vs um.f5 matches 0.. run scoreboard players set #vs um.f5 0
execute unless score #reserved um.f5 matches 0.. run scoreboard players set #reserved um.f5 0
team add um.f5 {"text": "フィールド5", "color": "gold"}
team modify um.f5 color gold
team modify um.f5 prefix {"text": "[5] ", "color": "gold"}
team modify um.f5 collisionRule never
team modify um.f5 friendlyFire false
bossbar add umetate:f5 {"text": "フィールド5", "color": "gold"}
bossbar set umetate:f5 max 192
bossbar set umetate:f5 color green
bossbar set umetate:f5 style notched_10
forceload add 2384 -16 2431 31
execute unless score #built um.f5 matches 2 run schedule function umetate:f5/build 40t
