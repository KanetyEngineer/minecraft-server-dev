execute if score #id hw.tmp matches 1 run return run function halloween:shop/item1
execute if score #id hw.tmp matches 2 run return run function halloween:shop/item2
execute if score #id hw.tmp matches 3 run return run function halloween:shop/item3
execute if score #id hw.tmp matches 4 run return run function halloween:shop/item4
execute if score #id hw.tmp matches 5 run return run function halloween:shop/item5
