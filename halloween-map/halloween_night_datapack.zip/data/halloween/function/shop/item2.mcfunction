execute unless score @s hw.candy matches 10.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 10
give @s minecraft:bow
give @s minecraft:arrow 16
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "「弓＋矢16本」を買った！（お菓子 -10）", "color": "green"}]
execute at @s run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
