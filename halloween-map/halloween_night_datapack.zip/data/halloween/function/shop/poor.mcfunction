tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "お菓子が足りないよ！", "color": "red"}]
execute at @s run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
