execute unless score @s hw.candy matches 15.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 15
item replace entity @s armor.chest with minecraft:iron_chestplate
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "「鉄のチェストプレート」を買った！（お菓子 -15）", "color": "green"}]
execute at @s run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
