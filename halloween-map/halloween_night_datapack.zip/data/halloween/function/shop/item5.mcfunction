execute unless score @s hw.candy matches 6.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 6
give @s minecraft:splash_potion[potion_contents={potion:"minecraft:healing"}]
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "「治癒のポーション」を買った！（お菓子 -6）", "color": "green"}]
execute at @s run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
