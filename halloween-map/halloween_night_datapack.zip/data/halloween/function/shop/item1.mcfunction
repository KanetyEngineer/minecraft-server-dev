execute unless score @s hw.candy matches 8.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 8
give @s minecraft:iron_sword
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "「鉄の剣」を買った！（お菓子 -8）", "color": "green"}]
execute at @s run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
