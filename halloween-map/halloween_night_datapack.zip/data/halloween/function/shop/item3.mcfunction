execute unless score @s hw.candy matches 12.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 12
give @s minecraft:golden_apple
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "「金のリンゴ」を買った！（お菓子 -12）", "color": "green"}]
execute at @s run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
