tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "まだゲームが始まっていません。広場の「ゲームスタート」台をクリック！", "color": "yellow"}]
execute at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.8
