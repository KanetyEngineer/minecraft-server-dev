scoreboard players operation #id hw.tmp = @e[type=minecraft:interaction,tag=hw.this,limit=1] hw.id
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.costume] run return run function halloween:plaza/costume
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.note] run return run function halloween:mansion/note
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.start] run return run function halloween:game/start_button
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.tower_down] run return run function halloween:tower/down
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.tower_reset] run return run function halloween:tower/reset_cp
execute unless score #state hw.st matches 1 run return run function halloween:click/not_started
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.shop] run return run function halloween:shop/buy
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.house] run return run function halloween:village/knock
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.cauldron] run return run function halloween:village/cauldron
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.pk_start] run return run function halloween:patch/start
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.pt] run return run function halloween:patch/hit
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.gal_start] run return run function halloween:gallery/start
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.tower_chest] run return run function halloween:tower/chest
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.lantern] run return run function halloween:lantern/take
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.c.candy] run return run function halloween:hidden/take
