tag @s add hw.this
execute on target run function halloween:click/route
tag @s remove hw.this
data remove entity @s interaction
