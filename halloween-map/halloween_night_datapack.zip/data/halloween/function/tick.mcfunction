scoreboard players add #t hw.st 1
execute as @a unless score @s hw.init matches 1 run function halloween:player/init
execute as @a[scores={hw.left=1..}] run function halloween:player/rejoin
execute as @e[type=minecraft:interaction,tag=hw.click] if data entity @s interaction run function halloween:click/use
execute as @e[type=minecraft:interaction,tag=hw.click] if data entity @s attack run function halloween:click/hit
execute as @a[scores={hw.kz=1..}] run function halloween:reward/zombie
execute as @a[scores={hw.ks=1..}] run function halloween:reward/skeleton
execute as @a[scores={hw.kv=1..}] run function halloween:reward/vex
execute as @a[scores={hw.kb=1..}] run function halloween:reward/boss
scoreboard players remove @a[scores={hw.ccd=1..}] hw.ccd 1
function halloween:mansion/tick
function halloween:maze/tick
function halloween:tower/tick
execute if score #pk hw.st matches 1.. run function halloween:patch/tick
execute if score #gal hw.st matches 1.. run function halloween:gallery/tick
execute if score #state hw.st matches 1 run function halloween:game/tick
function halloween:fx/tick
