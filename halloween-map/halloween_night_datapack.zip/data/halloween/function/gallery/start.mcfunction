execute if score #gal hw.st matches 1.. run return run tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "ゴースト射的は進行中！", "color": "yellow"}]
scoreboard players set #gal hw.st 900
scoreboard players set @a hw.gk 0
tag @a[x=-48,y=62,z=52,dx=10,dy=6,dz=16,gamemode=!spectator] add hw.gal
tag @s add hw.gal
give @a[tag=hw.gal] minecraft:bow[custom_data={hw:"gal"},enchantments={"minecraft:infinity":1},unbreakable={},custom_name={"text": "射的の弓", "color": "aqua", "italic": false}]
give @a[tag=hw.gal] minecraft:arrow[custom_data={hw:"gal"}] 1
title @a[tag=hw.gal] title {"text": "ゴースト射的！", "color": "aqua", "bold": true}
title @a[tag=hw.gal] subtitle {"text": "45秒間 撃ちまくれ", "color": "white"}
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@a[tag=hw.gal]", "color": "yellow"}, {"text": " がゴースト射的に挑戦中！", "color": "aqua"}]
playsound minecraft:event.raid.horn master @a -60 64 60 3 1.5
