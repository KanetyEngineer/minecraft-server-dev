kill @e[type=minecraft:vex,tag=hw.gv]
kill @e[type=minecraft:arrow,x=-90,y=50,z=40,dx=56,dy=40,dz=40]
clear @a minecraft:bow[minecraft:custom_data={hw:"gal"}]
clear @a minecraft:arrow[minecraft:custom_data={hw:"gal"}]
scoreboard players set #max hw.tmp 0
execute as @a[tag=hw.gal] run scoreboard players operation #max hw.tmp > @s hw.gk
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "ゴースト射的 終了！", "color": "aqua"}]
execute as @a[tag=hw.gal] run tellraw @a [{"text": "  ", "color": "gray"}, {"selector": "@s", "color": "yellow"}, {"text": ": ", "color": "gray"}, {"score": {"name": "@s", "objective": "hw.gk"}, "color": "white"}, {"text": " 体", "color": "gray"}]
execute if score #max hw.tmp matches 1.. as @a[tag=hw.gal] if score @s hw.gk = #max hw.tmp run function halloween:gallery/top
tag @a remove hw.gal
