execute store result storage halloween:tmp x int 1 run random value -78..-56
execute store result storage halloween:tmp y int 1 run random value 65..70
execute store result score #d hw.tmp run random value 0..1
execute if score #d hw.tmp matches 0 store result storage halloween:tmp z int 1 run random value 49..58
execute if score #d hw.tmp matches 1 store result storage halloween:tmp z int 1 run random value 62..71
execute if score #d hw.tmp matches 0 run function halloween:gallery/spawn_s with storage halloween:tmp
execute if score #d hw.tmp matches 1 run function halloween:gallery/spawn_n with storage halloween:tmp
