tellraw @a [{"text": "  トップ賞 ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " お菓子 +5", "color": "gold"}]
scoreboard players set #gain hw.tmp 5
function halloween:candy/add
