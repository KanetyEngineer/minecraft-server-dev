scoreboard players remove #gal hw.st 1
scoreboard players operation #s hw.tmp = #gal hw.st
scoreboard players operation #s hw.tmp %= #10 hw.c
execute if score #s hw.tmp matches 0 store result score #n hw.tmp if entity @e[type=minecraft:vex,tag=hw.gv]
execute if score #s hw.tmp matches 0 if score #n hw.tmp matches ..6 run function halloween:gallery/spawn
execute as @e[type=minecraft:vex,tag=hw.gv] at @s run tp @s ^ ^ ^0.13
scoreboard players add @e[type=minecraft:vex,tag=hw.gv] hw.age 1
execute as @e[type=minecraft:vex,tag=hw.gv,scores={hw.age=100..}] at @s run particle minecraft:poof ~ ~0.5 ~ 0.2 0.2 0.2 0.02 8
kill @e[type=minecraft:vex,tag=hw.gv,scores={hw.age=100..}]
scoreboard players operation #s hw.tmp = #gal hw.st
scoreboard players operation #s hw.tmp %= #20 hw.c
scoreboard players operation #sec hw.tmp = #gal hw.st
scoreboard players operation #sec hw.tmp /= #20 hw.c
execute if score #s hw.tmp matches 0 run title @a[tag=hw.gal] actionbar [{"text": "ゴースト射的 残り ", "color": "aqua"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}, {"text": "秒", "color": "aqua"}]
execute if score #gal hw.st matches 0 run function halloween:gallery/end
