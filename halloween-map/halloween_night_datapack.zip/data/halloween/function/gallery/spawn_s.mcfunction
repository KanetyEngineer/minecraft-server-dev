$summon minecraft:vex $(x) $(y) $(z) {NoAI:1b,PersistenceRequired:1b,Glowing:1b,Rotation:[0.0f,0f],Health:1.0f,attributes:[{id:"minecraft:max_health",base:1.0d}],CustomName:{"text": "ゴースト", "color": "aqua"},Tags:["hw.gv","hw.mob","hw.tmpent"]}
$particle minecraft:soul $(x) $(y) $(z) 0.3 0.3 0.3 0.02 10
