execute unless score #state hw.st matches 1 run return 0
execute if score #double hw.st matches 1 run scoreboard players operation #gain hw.tmp *= #2 hw.c
scoreboard players operation @s hw.candy += #gain hw.tmp
scoreboard players operation @s hw.total += #gain hw.tmp
title @s actionbar [{"text": "+", "color": "gold", "bold": true}, {"score": {"name": "#gain", "objective": "hw.tmp"}, "color": "gold"}, {"text": " お菓子", "color": "gold"}]
execute at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.3
