scoreboard players set #raid hw.st 1
execute if score #boss hw.st matches 1.. run return 0
title @a times 10 50 15
title @a title {"text": "ゴーストの襲来！", "color": "aqua", "bold": true}
title @a subtitle {"text": "倒すとお菓子がもらえるぞ", "color": "white"}
execute as @a at @s run playsound minecraft:entity.vex.ambient master @s ~ ~ ~ 1 0.5
execute at @a[tag=hw.player] run summon minecraft:vex ~2 ~4 ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "さまようゴースト", "color": "aqua"}}
execute at @a[tag=hw.player] run summon minecraft:vex ~-2 ~4 ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "さまようゴースト", "color": "aqua"}}
execute at @a[tag=hw.player] run summon minecraft:bat ~ ~3 ~ {Tags:["hw.mob","hw.tmpent"]}
