scoreboard players set #double hw.st 1
bossbar set halloween:timer color yellow
title @a times 10 50 15
title @a title {"text": "お菓子2倍タイム！", "color": "yellow", "bold": true}
title @a subtitle {"text": "残り5分、もらえるお菓子が2倍！", "color": "gold"}
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.4
