fill -2 64 -93 2 68 -93 minecraft:air
title @a times 10 60 20
title @a title {"text": "城門がひらいた！", "color": "gold", "bold": true}
title @a subtitle {"text": "北のパンプキン城へ向かえ", "color": "red"}
playsound minecraft:block.iron_door.open master @a 0 65 -93 3 0.5
playsound minecraft:entity.wither.ambient master @a ~ ~ ~ 0.6 0.5
summon minecraft:lightning_bolt 0 64 -146
