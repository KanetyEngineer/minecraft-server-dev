kill @e[type=minecraft:interaction,tag=hw.this,limit=1]
execute if score #id hw.tmp matches 1 run function halloween:lantern/got1
execute if score #id hw.tmp matches 2 run function halloween:lantern/got2
execute if score #id hw.tmp matches 3 run function halloween:lantern/got3
execute if score #lanterns hw.st matches 3.. run function halloween:lantern/all
