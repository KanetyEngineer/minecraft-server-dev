setblock -74 65 0 minecraft:air
setblock 4 66 -13 minecraft:soul_lantern
scoreboard players set #l3 hw.st 1
scoreboard players add #lanterns hw.st 1
kill @e[type=minecraft:text_display,tag=hw.ltext3]
scoreboard players set #gain hw.tmp 10
function halloween:candy/add
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " が ", "color": "white"}, {"text": "③ カボチャ畑の魂のランタン", "color": "aqua", "bold": true}, {"text": " を手に入れた！ (", "color": "white"}, {"score": {"name": "#lanterns", "objective": "hw.st"}, "color": "aqua"}, {"text": "/3)", "color": "white"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:soul_fire_flame 4 66.5 -13 0.3 0.5 0.3 0.05 40 force
