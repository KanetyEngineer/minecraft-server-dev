scoreboard players operation #gain hw.tmp = @s hw.kz
scoreboard players set #k hw.tmp 2
scoreboard players operation #gain hw.tmp *= #k hw.tmp
scoreboard players set @s hw.kz 0
function halloween:candy/add
