scoreboard players operation #gain hw.tmp = @s hw.kv
scoreboard players set #k hw.tmp 1
scoreboard players operation #gain hw.tmp *= #k hw.tmp
scoreboard players set @s hw.kv 0
function halloween:candy/add
