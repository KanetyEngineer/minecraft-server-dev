scoreboard players set @s hw.kb 0
scoreboard players set #gain hw.tmp 30
function halloween:candy/add
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " がパンプキン・キングにとどめを刺した！ ボーナス +30", "color": "gold"}]
