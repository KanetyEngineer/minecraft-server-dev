execute if score #id hw.tmp matches 0 run item replace entity @s armor.head with minecraft:air
execute if score #id hw.tmp matches 0 run tellraw @s [{"text": "仮装を脱いだ", "color": "gray"}]
execute if score #id hw.tmp matches 1 run item replace entity @s armor.head with minecraft:carved_pumpkin
execute if score #id hw.tmp matches 1 run tellraw @s [{"text": "「カボチャ頭」に変身した！", "color": "light_purple"}]
execute if score #id hw.tmp matches 2 run item replace entity @s armor.head with minecraft:skeleton_skull
execute if score #id hw.tmp matches 2 run tellraw @s [{"text": "「ガイコツ」に変身した！", "color": "light_purple"}]
execute if score #id hw.tmp matches 3 run item replace entity @s armor.head with minecraft:wither_skeleton_skull
execute if score #id hw.tmp matches 3 run tellraw @s [{"text": "「黒ガイコツ」に変身した！", "color": "light_purple"}]
execute if score #id hw.tmp matches 4 run item replace entity @s armor.head with minecraft:zombie_head
execute if score #id hw.tmp matches 4 run tellraw @s [{"text": "「ゾンビ」に変身した！", "color": "light_purple"}]
execute if score #id hw.tmp matches 5 run item replace entity @s armor.head with minecraft:creeper_head
execute if score #id hw.tmp matches 5 run tellraw @s [{"text": "「クリーパー」に変身した！", "color": "light_purple"}]
execute if score #id hw.tmp matches 6 run item replace entity @s armor.head with minecraft:piglin_head
execute if score #id hw.tmp matches 6 run tellraw @s [{"text": "「ピグリン」に変身した！", "color": "light_purple"}]
execute at @s run playsound minecraft:item.armor.equip_leather master @s ~ ~ ~ 1 1
execute at @s run particle minecraft:witch ~ ~1.2 ~ 0.3 0.6 0.3 0.05 20
