execute if score #state hw.st matches 1 run return run tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "ゲームはもう始まっているよ！", "color": "yellow"}]
execute if score #state hw.st matches 3 run return 0
function halloween:game/start
