title @a title {"text": "1", "color": "gold", "bold": true}
execute as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
schedule function halloween:game/go 20t
