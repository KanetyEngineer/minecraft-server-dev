tag @a remove hw.ranked
tag @a remove hw.r1
tag @a remove hw.r2
tag @a remove hw.r3
tag @a remove hw.r4
tag @a remove hw.r5
tag @a remove hw.r6
tellraw @a [{"text": "\n========== 結果発表 ==========", "color": "gold", "bold": true}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r1
tag @a[tag=hw.r1] add hw.ranked
execute if entity @a[tag=hw.r1] run tellraw @a [{"text": " 第1位  ", "color": "gold", "bold": true}, {"selector": "@a[tag=hw.r1]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r2
tag @a[tag=hw.r2] add hw.ranked
execute if entity @a[tag=hw.r2] run tellraw @a [{"text": " 第2位  ", "color": "white", "bold": true}, {"selector": "@a[tag=hw.r2]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r3
tag @a[tag=hw.r3] add hw.ranked
execute if entity @a[tag=hw.r3] run tellraw @a [{"text": " 第3位  ", "color": "#cd7f32", "bold": true}, {"selector": "@a[tag=hw.r3]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r4
tag @a[tag=hw.r4] add hw.ranked
execute if entity @a[tag=hw.r4] run tellraw @a [{"text": " 第4位  ", "color": "gray", "bold": true}, {"selector": "@a[tag=hw.r4]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r5
tag @a[tag=hw.r5] add hw.ranked
execute if entity @a[tag=hw.r5] run tellraw @a [{"text": " 第5位  ", "color": "gray", "bold": true}, {"selector": "@a[tag=hw.r5]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
scoreboard players set #max hw.tmp -1
execute as @a[tag=hw.player,tag=!hw.ranked] run scoreboard players operation #max hw.tmp > @s hw.candy
execute if score #max hw.tmp matches 0.. as @a[tag=hw.player,tag=!hw.ranked] if score @s hw.candy = #max hw.tmp run tag @s add hw.r6
tag @a[tag=hw.r6] add hw.ranked
execute if entity @a[tag=hw.r6] run tellraw @a [{"text": " 第6位  ", "color": "gray", "bold": true}, {"selector": "@a[tag=hw.r6]", "color": "yellow"}, {"text": "  お菓子 ", "color": "white"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "gold"}, {"text": " 個", "color": "white"}]
tellraw @a [{"text": "\n—— みんなの記録 ——", "color": "gray"}]
execute as @a[tag=hw.player] run tellraw @a [{"text": "  ", "color": "white"}, {"selector": "@s", "color": "yellow"}, {"text": "  稼いだお菓子 ", "color": "gray"}, {"score": {"name": "@s", "objective": "hw.total"}, "color": "white"}, {"text": "  ／ やられた回数 ", "color": "gray"}, {"score": {"name": "@s", "objective": "hw.dead"}, "color": "white"}]
tellraw @a [{"text": "  見つけた隠しお菓子: ", "color": "gray"}, {"score": {"name": "#hidden", "objective": "hw.st"}, "color": "white"}, {"text": "/20", "color": "gray"}]
execute if score #boss hw.st matches 3 run tellraw @a [{"text": "  パンプキン・キング: ", "color": "gray"}, {"text": "討伐成功！", "color": "green", "bold": true}]
execute unless score #boss hw.st matches 3 run tellraw @a [{"text": "  パンプキン・キング: ", "color": "gray"}, {"text": "討伐ならず……", "color": "red"}]
title @a times 10 100 30
title @a title [{"selector": "@a[tag=hw.r1]", "color": "gold", "bold": true}]
title @a subtitle {"text": "優勝！ ハッピーハロウィン！", "color": "yellow", "bold": true}
item replace entity @a[tag=hw.r1] armor.head with minecraft:golden_helmet[custom_name={"text": "パンプキン王の冠", "color": "gold", "bold": true, "italic": false},enchantment_glint_override=true]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
scoreboard players set #fw hw.st 10
function halloween:fx/winner_fw
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "もう一度遊ぶときは広場の「ゲームスタート」台をクリック！", "color": "gray"}]
