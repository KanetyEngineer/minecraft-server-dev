tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "時間切れ！", "color": "red", "bold": true}]
function halloween:game/end
