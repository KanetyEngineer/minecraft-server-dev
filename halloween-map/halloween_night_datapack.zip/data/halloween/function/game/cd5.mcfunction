title @a title {"text": "5", "color": "gold", "bold": true}
execute as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
schedule function halloween:game/cd4 20t
