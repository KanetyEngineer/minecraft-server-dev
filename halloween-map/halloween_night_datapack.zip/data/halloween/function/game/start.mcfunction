function halloween:admin/reset_world
tag @a remove hw.player
tag @a[gamemode=!spectator] add hw.player
scoreboard players reset * hw.candy
scoreboard players set @a[tag=hw.player] hw.candy 0
scoreboard players set @a[tag=hw.player] hw.total 0
scoreboard players set @a hw.dead 0
scoreboard players set @a hw.kz 0
scoreboard players set @a hw.ks 0
scoreboard players set @a hw.kv 0
scoreboard players set @a hw.kb 0
clear @a[tag=hw.player]
effect clear @a[tag=hw.player]
gamemode adventure @a[tag=hw.player]
tp @a[tag=hw.player] 0.5 64 12.5 180 0
execute as @a[tag=hw.player] run function halloween:player/starter
effect give @a[tag=hw.player] minecraft:saturation 5 4 true
effect give @a[tag=hw.player] minecraft:instant_health 1 4 true
scoreboard players operation #time hw.st = #timecfg hw.st
scoreboard players operation #time hw.st *= #1200 hw.c
scoreboard players operation #half hw.st = #time hw.st
scoreboard players operation #half hw.st /= #2 hw.c
execute store result bossbar halloween:timer max run scoreboard players get #time hw.st
execute store result bossbar halloween:timer value run scoreboard players get #time hw.st
bossbar set halloween:timer players @a
bossbar set halloween:timer color purple
bossbar set halloween:timer visible true
scoreboard players set #state hw.st 3
function halloween:game/rules
title @a times 0 25 5
schedule function halloween:game/cd5 40t
