title @a title {"text": "3", "color": "gold", "bold": true}
execute as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
schedule function halloween:game/cd2 20t
