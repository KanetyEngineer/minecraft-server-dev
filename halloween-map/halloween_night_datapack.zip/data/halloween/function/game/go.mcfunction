scoreboard players set #state hw.st 1
title @a times 5 40 15
title @a title {"text": "スタート！", "color": "gold", "bold": true}
title @a subtitle {"text": "お菓子を集めろ！ ハッピーハロウィン！", "color": "yellow"}
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 1.5
execute as @a at @s run playsound minecraft:event.raid.horn master @s ~ ~ ~ 1 1
