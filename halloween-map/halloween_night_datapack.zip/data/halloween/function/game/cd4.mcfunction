title @a title {"text": "4", "color": "gold", "bold": true}
execute as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
schedule function halloween:game/cd3 20t
