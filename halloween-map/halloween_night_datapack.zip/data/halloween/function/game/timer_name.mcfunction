scoreboard players operation #m hw.tmp = #time hw.st
scoreboard players operation #m hw.tmp /= #1200 hw.c
scoreboard players operation #sec hw.tmp = #time hw.st
scoreboard players operation #sec hw.tmp /= #20 hw.c
scoreboard players operation #sec hw.tmp %= #60 hw.c
execute if score #double hw.st matches 0 if score #sec hw.tmp matches 10.. run bossbar set halloween:timer name [{"text": "残り時間 ", "color": "light_purple"}, {"score": {"name": "#m", "objective": "hw.tmp"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}]
execute if score #double hw.st matches 0 if score #sec hw.tmp matches ..9 run bossbar set halloween:timer name [{"text": "残り時間 ", "color": "light_purple"}, {"score": {"name": "#m", "objective": "hw.tmp"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}]
execute if score #double hw.st matches 1 if score #sec hw.tmp matches 10.. run bossbar set halloween:timer name [{"text": "お菓子2倍タイム！ 残り ", "color": "yellow"}, {"score": {"name": "#m", "objective": "hw.tmp"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}]
execute if score #double hw.st matches 1 if score #sec hw.tmp matches ..9 run bossbar set halloween:timer name [{"text": "お菓子2倍タイム！ 残り ", "color": "yellow"}, {"score": {"name": "#m", "objective": "hw.tmp"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}]
