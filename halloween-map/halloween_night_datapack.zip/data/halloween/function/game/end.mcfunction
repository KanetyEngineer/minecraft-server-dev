execute unless score #state hw.st matches 1 run return 0
scoreboard players set #state hw.st 2
schedule clear halloween:game/end
bossbar set halloween:timer visible false
bossbar set halloween:boss visible false
kill @e[tag=hw.mob]
scoreboard players set #pk hw.st 0
scoreboard players set #gal hw.st 0
kill @e[tag=hw.ptall]
clear @a minecraft:bow[minecraft:custom_data={hw:"gal"}]
clear @a minecraft:arrow[minecraft:custom_data={hw:"gal"}]
weather clear
tp @a[tag=hw.player] 0.5 64 12.5 180 0
effect clear @a[tag=hw.player]
effect give @a[tag=hw.player] minecraft:resistance 30 4 true
title @a times 10 50 20
title @a title {"text": "ゲーム終了！", "color": "gold", "bold": true}
title @a subtitle {"text": "結果発表……", "color": "yellow"}
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.8
schedule function halloween:game/results 80t
