scoreboard players remove #time hw.st 1
execute store result bossbar halloween:timer value run scoreboard players get #time hw.st
scoreboard players operation #s hw.tmp = #time hw.st
scoreboard players operation #s hw.tmp %= #20 hw.c
execute if score #s hw.tmp matches 0 run function halloween:game/timer_name
execute if score #s hw.tmp matches 0 if score #time hw.st matches 1..200 as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 2
execute if score #raid hw.st matches 0 if score #time hw.st <= #half hw.st run function halloween:event/raid
execute if score #double hw.st matches 0 if score #time hw.st matches ..6000 run function halloween:event/double
execute if score #boss hw.st matches 0 if score #lanterns hw.st matches 3.. if entity @a[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] run function halloween:boss/intro
execute if score #boss hw.st matches 2 run function halloween:boss/tick
scoreboard players operation #s hw.tmp = #t hw.st
scoreboard players operation #s hw.tmp %= #20 hw.c
execute if score #s hw.tmp matches 0 as @e[type=minecraft:interaction,tag=hw.hc] at @s run particle minecraft:end_rod ~ ~0.5 ~ 0.15 0.15 0.15 0.01 1
execute if score #time hw.st matches ..0 run function halloween:game/timeout
