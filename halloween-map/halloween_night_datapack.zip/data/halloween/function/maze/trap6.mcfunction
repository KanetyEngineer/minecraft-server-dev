scoreboard players set #trap6 hw.st 300
execute positioned 67.5 64 12.5 run function halloween:maze/ambush
