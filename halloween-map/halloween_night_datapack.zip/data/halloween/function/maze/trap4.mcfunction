scoreboard players set #trap4 hw.st 300
execute positioned 64.5 64 15.5 run function halloween:maze/ambush
