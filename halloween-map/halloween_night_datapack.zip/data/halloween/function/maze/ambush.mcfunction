execute unless score #state hw.st matches 1 run return 0
execute store result score #n hw.tmp if entity @e[type=minecraft:zombie,tag=hw.mob]
execute if score #n hw.tmp matches 12.. run return 0
particle minecraft:soul ~ ~0.5 ~ 0.8 0.3 0.8 0.02 40
particle minecraft:block{block_state:{Name:"minecraft:podzol"}} ~ ~0.2 ~ 0.6 0.1 0.6 0.1 30
playsound minecraft:entity.zombie.ambient hostile @a ~ ~ ~ 1.5 0.6
summon minecraft:zombie ~ ~ ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "墓場のゾンビ", "color": "dark_green"},equipment:{head:{id:"minecraft:carved_pumpkin",count:1}},drop_chances:{head:0.0f}}
summon minecraft:zombie ~ ~ ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "墓場のゾンビ", "color": "dark_green"},equipment:{head:{id:"minecraft:jack_o_lantern",count:1}},drop_chances:{head:0.0f}}
tellraw @a[distance=..10] [{"text": "墓の下から何かが……！", "color": "dark_green"}]
