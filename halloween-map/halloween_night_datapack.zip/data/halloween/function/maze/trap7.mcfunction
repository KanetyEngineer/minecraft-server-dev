scoreboard players set #trap7 hw.st 300
execute positioned 48.5 64 -8.5 run function halloween:maze/ambush
