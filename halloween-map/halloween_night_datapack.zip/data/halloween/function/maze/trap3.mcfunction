scoreboard players set #trap3 hw.st 300
execute positioned 48.5 64 6.5 run function halloween:maze/ambush
