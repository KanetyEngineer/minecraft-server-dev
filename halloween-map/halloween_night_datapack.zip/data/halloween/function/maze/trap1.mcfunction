scoreboard players set #trap1 hw.st 300
execute positioned 66.5 64 -11.5 run function halloween:maze/ambush
