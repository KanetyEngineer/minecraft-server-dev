execute if score #trap1 hw.st matches 1.. run scoreboard players remove #trap1 hw.st 1
execute if block 66 64 -12 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap1 hw.st matches 1.. run function halloween:maze/trap1
execute if score #trap2 hw.st matches 1.. run scoreboard players remove #trap2 hw.st 1
execute if block 51 64 -12 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap2 hw.st matches 1.. run function halloween:maze/trap2
execute if score #trap3 hw.st matches 1.. run scoreboard players remove #trap3 hw.st 1
execute if block 48 64 6 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap3 hw.st matches 1.. run function halloween:maze/trap3
execute if score #trap4 hw.st matches 1.. run scoreboard players remove #trap4 hw.st 1
execute if block 64 64 15 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap4 hw.st matches 1.. run function halloween:maze/trap4
execute if score #trap5 hw.st matches 1.. run scoreboard players remove #trap5 hw.st 1
execute if block 54 64 8 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap5 hw.st matches 1.. run function halloween:maze/trap5
execute if score #trap6 hw.st matches 1.. run scoreboard players remove #trap6 hw.st 1
execute if block 67 64 12 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap6 hw.st matches 1.. run function halloween:maze/trap6
execute if score #trap7 hw.st matches 1.. run scoreboard players remove #trap7 hw.st 1
execute if block 48 64 -9 minecraft:polished_blackstone_pressure_plate[powered=true] unless score #trap7 hw.st matches 1.. run function halloween:maze/trap7
