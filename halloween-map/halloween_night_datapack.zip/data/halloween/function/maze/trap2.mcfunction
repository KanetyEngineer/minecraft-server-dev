scoreboard players set #trap2 hw.st 300
execute positioned 51.5 64 -11.5 run function halloween:maze/ambush
