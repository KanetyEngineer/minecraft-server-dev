effect give @s minecraft:darkness 3 0 true
effect give @s minecraft:slowness 2 2 true
execute at @s run playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 1 0.6
execute at @s run playsound minecraft:entity.creaking.activate master @s ~ ~ ~ 1 0.8
execute at @s anchored eyes positioned ^ ^ ^1.6 run summon minecraft:creaking ~ ~-1.5 ~ {NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Tags:["hw.ghost","hw.tmpent"]}
execute at @s as @e[type=minecraft:creaking,tag=hw.ghost,distance=..4,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ facing entity @p eyes
schedule function halloween:fx/ghost_clear 25t append
