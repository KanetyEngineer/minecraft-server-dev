execute at @a[tag=hw.r1] run function halloween:fx/firework_random
scoreboard players remove #fw hw.st 1
execute if score #fw hw.st matches 1.. run schedule function halloween:fx/winner_fw 12t
