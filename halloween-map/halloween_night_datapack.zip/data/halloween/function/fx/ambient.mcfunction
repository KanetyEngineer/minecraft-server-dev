execute store result score #r hw.tmp run random value 1..12
execute if score #r hw.tmp matches 1 run playsound minecraft:ambient.cave ambient @s ~ ~ ~ 0.6 1
execute if score #r hw.tmp matches 2 run playsound minecraft:entity.witch.celebrate ambient @s ~8 ~ ~5 0.5 0.8
execute if score #r hw.tmp matches 3 run playsound minecraft:entity.bat.ambient ambient @s ~ ~2 ~ 0.6 0.9
execute if score #r hw.tmp matches 4 run playsound minecraft:block.bell.resonate ambient @s ~ ~ ~ 0.3 0.6
execute if score #r hw.tmp matches 5 run playsound minecraft:entity.wolf_big.growl ambient @s ~-10 ~ ~10 0.5 0.6
execute if score #r hw.tmp matches 6 run playsound minecraft:entity.ghast.ambient ambient @s ~ ~10 ~ 0.2 0.6
