execute if score #l1 hw.st matches 1 run particle minecraft:soul_fire_flame -3.5 66.6 -12.5 0.15 0.2 0.15 0.01 3
execute if score #l2 hw.st matches 1 run particle minecraft:soul_fire_flame 0.5 66.6 -12.5 0.15 0.2 0.15 0.01 3
execute if score #l3 hw.st matches 1 run particle minecraft:soul_fire_flame 4.5 66.6 -12.5 0.15 0.2 0.15 0.01 3
particle minecraft:soul 66.5 64.3 -11.5 0.4 0.1 0.4 0.01 1
particle minecraft:soul 51.5 64.3 -11.5 0.4 0.1 0.4 0.01 1
particle minecraft:soul 48.5 64.3 6.5 0.4 0.1 0.4 0.01 1
