execute positioned 0 66 -126 run function halloween:fx/firework_random
execute positioned 0 64 12 run function halloween:fx/firework_random
scoreboard players remove #fw hw.st 1
execute if score #fw hw.st matches 1.. run schedule function halloween:fx/finale 10t
