execute as @e[type=minecraft:creaking,tag=hw.ghost] at @s run particle minecraft:large_smoke ~ ~1 ~ 0.3 0.8 0.3 0.02 30
kill @e[type=minecraft:creaking,tag=hw.ghost]
