scoreboard players operation #m hw.tmp = #t hw.st
scoreboard players operation #m hw.tmp %= #100 hw.c
execute if score #m hw.tmp matches 0 as @a at @s run function halloween:fx/ambient
execute if score #m hw.tmp matches 0 run particle minecraft:flame -3 73 7.4 0.5 0.4 0.05 0.01 4
execute if score #m hw.tmp matches 50 run particle minecraft:flame 4 73 7.4 0.5 0.4 0.05 0.01 4
execute if score #m hw.tmp matches 25 run function halloween:fx/altar
