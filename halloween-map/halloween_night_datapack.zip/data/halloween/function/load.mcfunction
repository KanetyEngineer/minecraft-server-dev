scoreboard objectives add hw.candy dummy {"text": "★ お菓子 ★", "color": "gold", "bold": true}
scoreboard objectives add hw.total dummy
scoreboard objectives add hw.id dummy
scoreboard objectives add hw.tmp dummy
scoreboard objectives add hw.st dummy
scoreboard objectives add hw.c dummy
scoreboard objectives add hw.init dummy
scoreboard objectives add hw.age dummy
scoreboard objectives add hw.vy dummy
scoreboard objectives add hw.cp dummy
scoreboard objectives add hw.pk dummy
scoreboard objectives add hw.chest dummy
scoreboard objectives add hw.ccd dummy
scoreboard objectives add hw.left minecraft.custom:minecraft.leave_game
scoreboard objectives add hw.dead deathCount
scoreboard objectives add hw.kz minecraft.killed:minecraft.zombie
scoreboard objectives add hw.ks minecraft.killed:minecraft.skeleton
scoreboard objectives add hw.kv minecraft.killed:minecraft.vex
scoreboard objectives add hw.kb minecraft.killed:minecraft.wither_skeleton
scoreboard objectives add hw.gk minecraft.killed:minecraft.vex
scoreboard objectives add hw.h1 dummy
scoreboard objectives add hw.h2 dummy
scoreboard objectives add hw.h3 dummy
scoreboard objectives add hw.h4 dummy
scoreboard objectives add hw.h5 dummy
scoreboard objectives add hw.h6 dummy
scoreboard objectives add hw.sc1 dummy
scoreboard objectives add hw.sc2 dummy
scoreboard objectives add hw.sc3 dummy
scoreboard objectives add hw.sc4 dummy
scoreboard objectives setdisplay sidebar hw.candy
scoreboard players set #2 hw.c 2
scoreboard players set #3 hw.c 3
scoreboard players set #5 hw.c 5
scoreboard players set #10 hw.c 10
scoreboard players set #20 hw.c 20
scoreboard players set #60 hw.c 60
scoreboard players set #100 hw.c 100
scoreboard players set #1200 hw.c 1200
execute unless score #timecfg hw.st matches 1.. run scoreboard players set #timecfg hw.st 40
execute unless score #state hw.st matches 0.. run scoreboard players set #state hw.st 0
execute unless score #boss hw.st matches 0.. run scoreboard players set #boss hw.st 0
execute unless score #lanterns hw.st matches 0.. run scoreboard players set #lanterns hw.st 0
bossbar add halloween:timer {"text": "残り時間", "color": "light_purple"}
bossbar add halloween:boss {"text": "パンプキン・キング", "color": "gold", "bold": true}
bossbar set halloween:timer color purple
bossbar set halloween:boss color red
bossbar set halloween:boss style notched_10
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "データパックを読み込みました。管理メニュー: ", "color": "gray"}, {"text": "/function halloween:admin/menu", "color": "yellow", "click_event": {"action": "suggest_command", "command": "/function halloween:admin/menu"}}]
