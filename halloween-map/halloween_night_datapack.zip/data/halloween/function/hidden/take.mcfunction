execute as @e[type=minecraft:interaction,tag=hw.this,limit=1] at @s run kill @e[type=minecraft:item_display,tag=hw.hcd,distance=..1]
execute as @e[type=minecraft:interaction,tag=hw.this,limit=1] at @s run particle minecraft:totem_of_undying ~ ~0.5 ~ 0.2 0.3 0.2 0.2 20
kill @e[type=minecraft:interaction,tag=hw.this,limit=1]
scoreboard players add #hidden hw.st 1
scoreboard players set #gain hw.tmp 5
function halloween:candy/add
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " が隠しお菓子を見つけた！ +5 (", "color": "white"}, {"score": {"name": "#hidden", "objective": "hw.st"}, "color": "aqua"}, {"text": "/20)", "color": "white"}]
execute at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.6
