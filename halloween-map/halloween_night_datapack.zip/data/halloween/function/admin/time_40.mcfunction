scoreboard players set #timecfg hw.st 40
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "制限時間を 40 分にしました（次のゲームから）", "color": "gray"}]
