execute if entity @s[tag=hw.nv] run return run function halloween:admin/nv_off
tag @s add hw.nv
effect give @s minecraft:night_vision infinite 0 true
