scoreboard players set #timecfg hw.st 20
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "制限時間を 20 分にしました（次のゲームから）", "color": "gray"}]
