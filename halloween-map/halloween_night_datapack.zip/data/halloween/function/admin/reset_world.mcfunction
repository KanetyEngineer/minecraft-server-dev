kill @e[tag=hw.mob]
kill @e[tag=hw.tmpent]
schedule clear halloween:game/end
schedule clear halloween:boss/spawn
fill -2 64 -93 2 68 -93 minecraft:iron_bars[east=true,west=true]
setblock -4 66 -13 minecraft:air
setblock 0 66 -13 minecraft:air
setblock 4 66 -13 minecraft:air
setblock -12 65 -63 minecraft:lever[face=wall,facing=south,powered=false]
setblock -10 65 -63 minecraft:lever[face=wall,facing=south,powered=false]
setblock -8 65 -63 minecraft:lever[face=wall,facing=south,powered=false]
setblock -6 65 -63 minecraft:lever[face=wall,facing=south,powered=false]
setblock 0 72 -58 minecraft:air
setblock 0 73 -58 minecraft:air
setblock 0 74 -58 minecraft:air
setblock 0 75 -58 minecraft:air
setblock 0 76 -58 minecraft:air
setblock 0 71 -58 minecraft:purple_carpet
setblock 0 76 -58 minecraft:dark_oak_planks
setblock -74 65 0 minecraft:air
kill @e[type=minecraft:text_display,tag=hw.ltext1]
kill @e[type=minecraft:text_display,tag=hw.ltext2]
setblock 0 78 -55 minecraft:soul_lantern
summon minecraft:interaction 0.5 78 -54.5 {width:0.9f,height:1.0f,response:1b,Tags:["hw.click","hw.c.lantern","hw.tmpent","hw.new"]}
scoreboard players set @e[type=minecraft:interaction,tag=hw.new,limit=1] hw.id 1
tag @e[type=minecraft:interaction,tag=hw.new] remove hw.new
setblock 60 65 -1 minecraft:soul_lantern
summon minecraft:interaction 60.5 65 -0.5 {width:0.9f,height:1.0f,response:1b,Tags:["hw.click","hw.c.lantern","hw.tmpent","hw.new"]}
scoreboard players set @e[type=minecraft:interaction,tag=hw.new,limit=1] hw.id 2
tag @e[type=minecraft:interaction,tag=hw.new] remove hw.new
summon minecraft:text_display 0.5 79.6 -54.5 {text:{"text": "① 屋敷の魂のランタン", "color": "aqua", "bold": true},billboard:"center",Tags:["hw.deco","hw.ltext1"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon minecraft:text_display 60.5 66.6 -0.5 {text:{"text": "② 墓地の魂のランタン", "color": "aqua", "bold": true},billboard:"center",Tags:["hw.deco","hw.ltext2"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
function halloween:hidden/spawn
scoreboard players set #state hw.st 0
scoreboard players set #lanterns hw.st 0
scoreboard players set #l1 hw.st 0
scoreboard players set #l2 hw.st 0
scoreboard players set #l3 hw.st 0
scoreboard players set #boss hw.st 0
scoreboard players set #bphase hw.st 0
scoreboard players set #pk hw.st 0
scoreboard players set #pk_done hw.st 0
scoreboard players set #gal hw.st 0
scoreboard players set #mansion hw.st 0
scoreboard players set #double hw.st 0
scoreboard players set #raid hw.st 0
scoreboard players set #hidden hw.st 0
scoreboard players reset * hw.h1
scoreboard players reset * hw.h2
scoreboard players reset * hw.h3
scoreboard players reset * hw.h4
scoreboard players reset * hw.h5
scoreboard players reset * hw.h6
scoreboard players reset * hw.sc1
scoreboard players reset * hw.sc2
scoreboard players reset * hw.sc3
scoreboard players reset * hw.sc4
scoreboard players reset * hw.chest
scoreboard players reset * hw.cp
scoreboard players reset * hw.pk
tag @a remove hw.gal
bossbar set halloween:boss visible false
bossbar set halloween:timer visible false
weather clear
time set 18000
