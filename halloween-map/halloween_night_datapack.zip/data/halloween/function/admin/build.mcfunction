tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "マップの建築を開始します。チャンクを読み込み中……（動かずに待ってね）", "color": "yellow"}]
gamerule max_block_modifications 1000000
gamerule max_command_sequence_length 1000000
forceload add -112 -160 -1 112
forceload add 0 -160 112 112
schedule function halloween:build/wait 40t
