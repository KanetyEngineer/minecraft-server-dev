scoreboard players set #timecfg hw.st 30
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "制限時間を 30 分にしました（次のゲームから）", "color": "gray"}]
