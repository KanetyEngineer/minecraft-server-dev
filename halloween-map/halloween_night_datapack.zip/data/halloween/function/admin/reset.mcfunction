schedule clear halloween:game/cd5
schedule clear halloween:game/cd4
schedule clear halloween:game/cd3
schedule clear halloween:game/cd2
schedule clear halloween:game/cd1
schedule clear halloween:game/go
schedule clear halloween:game/results
function halloween:admin/reset_world
tag @a remove hw.player
tp @a 0.5 64 12.5 180 0
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "マップをリセットしました", "color": "gray"}]
