scoreboard players set #timecfg hw.st 60
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "制限時間を 60 分にしました（次のゲームから）", "color": "gray"}]
