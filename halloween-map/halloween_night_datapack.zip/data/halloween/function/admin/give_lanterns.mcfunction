execute if score #l1 hw.st matches 0 run function halloween:lantern/got1
execute if score #l2 hw.st matches 0 run function halloween:lantern/got2
execute if score #l3 hw.st matches 0 run function halloween:lantern/got3
kill @e[type=minecraft:interaction,tag=hw.c.lantern]
execute if score #lanterns hw.st matches 3.. run function halloween:lantern/all
