tag @s remove hw.nv
effect clear @s minecraft:night_vision
