execute if score #state hw.st matches 1 run function halloween:game/end
execute if score #state hw.st matches 3 run function halloween:admin/reset_world
