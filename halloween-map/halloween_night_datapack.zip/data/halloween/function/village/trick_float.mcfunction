tellraw @s [{"text": "TRICK！ ", "color": "dark_purple", "bold": true}, {"text": "いたずらだ！ ふわふわ〜", "color": "light_purple"}]
effect give @s minecraft:levitation 2 1 true
execute at @s run playsound minecraft:entity.witch.celebrate master @a ~ ~ ~ 1 1
