tellraw @s [{"text": "大当たり！！ ", "color": "gold", "bold": true}, {"text": "袋いっぱいのお菓子をもらった！", "color": "yellow"}]
scoreboard players set #gain hw.tmp 12
function halloween:candy/add
execute at @s run function halloween:fx/firework
execute at @s run playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1.2
