tellraw @s [{"text": "TRICK！ ", "color": "dark_purple", "bold": true}, {"text": "コウモリの大群だ！", "color": "light_purple"}]
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run summon minecraft:bat ~ ~1 ~ {Tags:["hw.mob","hw.tmpent"]}
execute at @s run playsound minecraft:entity.bat.takeoff master @a ~ ~ ~ 1 0.8
