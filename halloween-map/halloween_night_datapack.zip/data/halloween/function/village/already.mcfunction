tellraw @s [{"text": "「もうお菓子はあげたでしょ！ 他の家へどうぞ」", "color": "gray"}]
execute at @s run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
