execute if score #id hw.tmp matches 1 if score @s hw.h1 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 1 run scoreboard players set @s hw.h1 1
execute if score #id hw.tmp matches 1 run tellraw @s [{"text": "[ジャックの家] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute if score #id hw.tmp matches 2 if score @s hw.h2 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 2 run scoreboard players set @s hw.h2 1
execute if score #id hw.tmp matches 2 run tellraw @s [{"text": "[魔女ベラの家] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute if score #id hw.tmp matches 3 if score @s hw.h3 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 3 run scoreboard players set @s hw.h3 1
execute if score #id hw.tmp matches 3 run tellraw @s [{"text": "[ドラキュラ伯爵邸] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute if score #id hw.tmp matches 4 if score @s hw.h4 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 4 run scoreboard players set @s hw.h4 1
execute if score #id hw.tmp matches 4 run tellraw @s [{"text": "[ミイラのマミー] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute if score #id hw.tmp matches 5 if score @s hw.h5 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 5 run scoreboard players set @s hw.h5 1
execute if score #id hw.tmp matches 5 run tellraw @s [{"text": "[ガイコツ・ボーンズ] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute if score #id hw.tmp matches 6 if score @s hw.h6 matches 1 run return run function halloween:village/already
execute if score #id hw.tmp matches 6 run scoreboard players set @s hw.h6 1
execute if score #id hw.tmp matches 6 run tellraw @s [{"text": "[黒猫クロの家] ", "color": "yellow"}, {"text": "「はーい、トリック・オア・トリート？」", "color": "white"}]
execute at @s run playsound minecraft:entity.zombie.attack_wooden_door master @a ~ ~ ~ 0.6 1.4
execute store result score #r hw.tmp run random value 1..10
execute if score #r hw.tmp matches 1..5 run function halloween:village/treat
execute if score #r hw.tmp matches 6 run function halloween:village/trick_float
execute if score #r hw.tmp matches 7 run function halloween:village/trick_dark
execute if score #r hw.tmp matches 8 run function halloween:village/trick_bats
execute if score #r hw.tmp matches 9 run function halloween:village/trick_pumpkin
execute if score #r hw.tmp matches 10 run function halloween:village/jackpot
