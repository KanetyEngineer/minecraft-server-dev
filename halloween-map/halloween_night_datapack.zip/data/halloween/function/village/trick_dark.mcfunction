tellraw @s [{"text": "TRICK！ ", "color": "dark_purple", "bold": true}, {"text": "目の前が真っ暗に……！", "color": "light_purple"}]
effect give @s minecraft:darkness 5 0 true
execute at @s run playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 1 0.7
