execute store result score #gain hw.tmp run random value 2..6
tellraw @s [{"text": "TREAT！ ", "color": "gold", "bold": true}, {"text": "お菓子をもらった！ +", "color": "yellow"}, {"score": {"name": "#gain", "objective": "hw.tmp"}, "color": "yellow"}]
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 20
function halloween:candy/add
