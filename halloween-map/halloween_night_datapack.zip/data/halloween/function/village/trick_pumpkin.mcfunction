tellraw @s [{"text": "TRICK！ ", "color": "dark_purple", "bold": true}, {"text": "カボチャ頭の呪い！（広場のクローゼットで脱げる）", "color": "light_purple"}]
item replace entity @s armor.head with minecraft:carved_pumpkin
execute at @s run playsound minecraft:block.pumpkin.carve master @a ~ ~ ~ 1 0.8
