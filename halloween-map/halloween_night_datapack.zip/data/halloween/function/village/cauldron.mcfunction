execute if score @s hw.ccd matches 1.. run return run tellraw @s [{"text": "大釜がまだぐつぐつしている……", "color": "gray"}]
execute unless score @s hw.candy matches 3.. run return run function halloween:shop/poor
scoreboard players remove @s hw.candy 3
scoreboard players set @s hw.ccd 60
playsound minecraft:block.brewing_stand.brew master @a 0 65 74 1 1
particle minecraft:witch 0.5 65.2 74.5 0.4 0.4 0.4 0.1 40
execute store result score #r hw.tmp run random value 1..8
execute if score #r hw.tmp matches 1 run effect give @s minecraft:speed 60 1
execute if score #r hw.tmp matches 1 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "スピードアップ！", "color": "green"}]
execute if score #r hw.tmp matches 2 run effect give @s minecraft:strength 60 0
execute if score #r hw.tmp matches 2 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "ちからがみなぎる！", "color": "green"}]
execute if score #r hw.tmp matches 3 run effect give @s minecraft:regeneration 30 1
execute if score #r hw.tmp matches 3 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "体力がぐんぐん回復！", "color": "green"}]
execute if score #r hw.tmp matches 4 run effect give @s minecraft:jump_boost 60 1
execute if score #r hw.tmp matches 4 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "ジャンプ力アップ！", "color": "green"}]
execute if score #r hw.tmp matches 5 run effect give @s minecraft:night_vision 180 0
execute if score #r hw.tmp matches 5 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "暗いところがよく見える！", "color": "green"}]
execute if score #r hw.tmp matches 6 run effect give @s minecraft:invisibility 40 0
execute if score #r hw.tmp matches 6 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "透明になった！", "color": "green"}]
execute if score #r hw.tmp matches 7 run effect give @s minecraft:resistance 60 0
execute if score #r hw.tmp matches 7 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "からだが固くなった！", "color": "green"}]
execute if score #r hw.tmp matches 8 run effect give @s minecraft:slowness 10 1
execute if score #r hw.tmp matches 8 run effect give @s minecraft:nausea 6 0
execute if score #r hw.tmp matches 8 run tellraw @s [{"text": "魔女の大釜：", "color": "light_purple"}, {"text": "ハズレ！ ネバネバのスライム汁……", "color": "red"}]
execute if score #r hw.tmp matches 8 at @s run playsound minecraft:entity.slime.squish master @a ~ ~ ~ 1 0.6
