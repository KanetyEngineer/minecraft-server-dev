scoreboard players set @s hw.sc1 1
function halloween:fx/jumpscare
