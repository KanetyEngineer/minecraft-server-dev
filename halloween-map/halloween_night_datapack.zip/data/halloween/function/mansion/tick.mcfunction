execute if score #mansion hw.st matches 0 if block -12 65 -63 minecraft:lever[powered=true] if block -10 65 -63 minecraft:lever[powered=false] if block -8 65 -63 minecraft:lever[powered=true] if block -6 65 -63 minecraft:lever[powered=true] run function halloween:mansion/solve
execute as @a[x=-4,y=64,z=-50,dx=8,dy=3,dz=4,gamemode=!spectator] unless score @s hw.sc1 matches 1 run function halloween:mansion/scare1
execute as @a[x=-4,y=71,z=-63,dx=8,dy=3,dz=4,gamemode=!spectator] unless score @s hw.sc2 matches 1 run function halloween:mansion/scare2
execute as @a[x=-14,y=71,z=-64,dx=8,dy=3,dz=5,gamemode=!spectator] unless score @s hw.sc3 matches 1 run function halloween:mansion/scare3
execute as @a[x=-5,y=77,z=-58,dx=10,dy=4,dz=6,gamemode=!spectator] unless score @s hw.sc4 matches 1 run function halloween:mansion/scare4
