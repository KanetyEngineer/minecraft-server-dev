execute if score #id hw.tmp matches 1 run tellraw @s [{"text": "", "color": "gray"}, {"text": "日記 その1『……燭台の1番目には、いつも火を灯しておくこと。』", "color": "light_purple"}]
execute if score #id hw.tmp matches 2 run tellraw @s [{"text": "", "color": "gray"}, {"text": "日記 その2『2番目の燭台だけは、決して灯してはならない。あの子が目を覚ますから。』", "color": "light_purple"}]
execute if score #id hw.tmp matches 3 run tellraw @s [{"text": "", "color": "gray"}, {"text": "日記 その3『3番目と4番目にも火を。そうすれば天井裏への道がひらく。』", "color": "light_purple"}]
execute at @s run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 1
