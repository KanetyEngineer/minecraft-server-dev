scoreboard players set @s hw.sc3 1
function halloween:fx/jumpscare
