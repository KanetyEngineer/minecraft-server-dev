scoreboard players set @s hw.sc4 1
function halloween:fx/jumpscare
