scoreboard players set @s hw.sc2 1
function halloween:fx/jumpscare
