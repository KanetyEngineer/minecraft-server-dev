scoreboard players set #mansion hw.st 1
setblock 0 71 -58 minecraft:ladder[facing=north]
setblock 0 72 -58 minecraft:ladder[facing=north]
setblock 0 73 -58 minecraft:ladder[facing=north]
setblock 0 74 -58 minecraft:ladder[facing=north]
setblock 0 75 -58 minecraft:ladder[facing=north]
setblock 0 76 -58 minecraft:ladder[facing=north]
setblock 0 76 -58 minecraft:ladder[facing=north]
playsound minecraft:block.wooden_trapdoor.open master @a 0 72 -58 2 0.6
playsound minecraft:entity.ghast.ambient master @a 0 72 -58 2 0.5
tellraw @a[x=-16,y=60,z=-66,dx=32,dy=30,dz=22] [{"text": "ガタン……！ 2階の天井から梯子が下りてきた。", "color": "light_purple"}]
title @a[x=-16,y=60,z=-66,dx=32,dy=30,dz=22] actionbar [{"text": "天井裏への道がひらいた", "color": "light_purple"}]
