execute if score @s hw.chest matches 1 run return run tellraw @s [{"text": "宝箱はもう空っぽだ", "color": "gray"}]
scoreboard players set @s hw.chest 1
scoreboard players set @s hw.cp 0
scoreboard players set #gain hw.tmp 15
function halloween:candy/add
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " が魔女の塔を制覇した！ お菓子 +15", "color": "light_purple"}]
execute at @s run function halloween:fx/firework
execute at @s run playsound minecraft:block.chest.open master @a ~ ~ ~ 1 0.8
