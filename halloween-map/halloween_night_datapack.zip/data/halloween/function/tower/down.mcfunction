scoreboard players set @s hw.cp 0
effect give @s minecraft:slow_falling 3 0 true
tp @s 60.5 64 70.5
execute at @s run playsound minecraft:entity.phantom.flap master @a ~ ~ ~ 1 1
