scoreboard players set @s hw.cp 2
title @s actionbar [{"text": "チェックポイント 2 ！", "color": "green", "bold": true}]
execute at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
