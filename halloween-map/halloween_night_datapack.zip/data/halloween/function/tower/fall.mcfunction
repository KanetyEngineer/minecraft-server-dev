execute store result score @s hw.vy run data get entity @s Motion[1] 100
execute if score @s hw.vy matches ..-65 if score @s hw.cp matches 1 if entity @s[y=0,dy=74] run return run function halloween:tower/back1
execute if score @s hw.vy matches ..-65 if score @s hw.cp matches 2 if entity @s[y=0,dy=86] run return run function halloween:tower/back2
