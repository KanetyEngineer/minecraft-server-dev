scoreboard players set @s hw.cp 0
tellraw @s [{"text": "チェックポイントをリセットした", "color": "gray"}]
