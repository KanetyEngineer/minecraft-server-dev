scoreboard players set @s hw.cp 1
title @s actionbar [{"text": "チェックポイント 1 ！", "color": "green", "bold": true}]
execute at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
