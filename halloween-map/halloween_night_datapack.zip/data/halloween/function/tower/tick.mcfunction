execute as @a[x=66,y=77,z=62,dx=0,dy=0,dz=0,gamemode=!spectator] unless score @s hw.cp matches 1.. run function halloween:tower/cp1
execute as @a[x=64,y=89,z=55,dx=0,dy=0,dz=0,gamemode=!spectator] unless score @s hw.cp matches 2.. run function halloween:tower/cp2
execute as @a[scores={hw.cp=1..},x=46,y=60,z=46,dx=28,dy=50,dz=28] run function halloween:tower/fall
