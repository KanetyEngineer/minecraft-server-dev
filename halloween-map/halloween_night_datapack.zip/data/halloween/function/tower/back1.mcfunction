effect give @s minecraft:slow_falling 1 0 true
tp @s 66.5 77 62.5
title @s actionbar [{"text": "チェックポイントに戻った", "color": "yellow"}]
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
