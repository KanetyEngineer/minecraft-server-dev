execute unless score #pk hw.st matches 1.. run return 0
scoreboard players set #gain hw.tmp 1
execute if entity @e[type=minecraft:interaction,tag=hw.this,limit=1,tag=hw.gold] run scoreboard players set #gain hw.tmp 3
scoreboard players operation @s hw.pk += #gain hw.tmp
scoreboard players operation #pk_total hw.st += #gain hw.tmp
execute as @e[type=minecraft:interaction,tag=hw.this,limit=1] at @s run function halloween:patch/pop
function halloween:candy/add
