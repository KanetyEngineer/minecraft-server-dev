execute if score #pk hw.st matches 1.. run return run tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "カボチャ狩りは進行中！", "color": "yellow"}]
scoreboard players set #pk hw.st 1200
scoreboard players set #pk_total hw.st 0
scoreboard players set @a hw.pk 0
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"selector": "@s", "color": "yellow"}, {"text": " がカボチャ狩りを始めた！ 60秒間、光るカボチャを叩け（金色は3点）", "color": "gold"}]
title @a[x=-84,y=60,z=-24,dx=48,dy=20,dz=48] title {"text": "カボチャ狩り！", "color": "gold", "bold": true}
title @a[x=-84,y=60,z=-24,dx=48,dy=20,dz=48] subtitle {"text": "みんなで20個たたけば ③ ランタン", "color": "yellow"}
playsound minecraft:event.raid.horn master @a -60 64 0 3 1.2
