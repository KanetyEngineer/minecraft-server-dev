particle minecraft:block{block_state:{Name:"minecraft:pumpkin"}} ~ ~0.4 ~ 0.3 0.3 0.3 0.1 25
particle minecraft:flame ~ ~0.4 ~ 0.2 0.2 0.2 0.05 10
playsound minecraft:block.wood.break master @a ~ ~ ~ 1 0.8
playsound minecraft:entity.chicken.egg master @a ~ ~ ~ 1 0.6
kill @e[type=minecraft:block_display,tag=hw.ptd,distance=..1.2]
kill @s
