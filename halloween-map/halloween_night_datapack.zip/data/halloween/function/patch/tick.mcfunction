scoreboard players remove #pk hw.st 1
scoreboard players operation #s hw.tmp = #pk hw.st
scoreboard players operation #s hw.tmp %= #10 hw.c
execute if score #s hw.tmp matches 0 store result score #n hw.tmp if entity @e[type=minecraft:interaction,tag=hw.pt]
execute if score #s hw.tmp matches 0 if score #n hw.tmp matches ..9 run function halloween:patch/spawn
execute if score #s hw.tmp matches 5 if score #n hw.tmp matches ..5 run function halloween:patch/spawn
scoreboard players add @e[tag=hw.ptall] hw.age 1
execute as @e[type=minecraft:interaction,tag=hw.pt,scores={hw.age=110..}] at @s run particle minecraft:smoke ~ ~0.4 ~ 0.2 0.2 0.2 0.01 6
kill @e[tag=hw.ptall,scores={hw.age=110..}]
scoreboard players operation #s hw.tmp = #pk hw.st
scoreboard players operation #s hw.tmp %= #20 hw.c
execute if score #s hw.tmp matches 0 run function halloween:patch/bar
execute if score #pk hw.st matches 0 run function halloween:patch/end
