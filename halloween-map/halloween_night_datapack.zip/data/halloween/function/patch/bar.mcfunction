scoreboard players operation #sec hw.tmp = #pk hw.st
scoreboard players operation #sec hw.tmp /= #20 hw.c
title @a[x=-84,y=60,z=-24,dx=48,dy=20,dz=48] actionbar [{"text": "カボチャ狩り 残り ", "color": "gold"}, {"score": {"name": "#sec", "objective": "hw.tmp"}, "color": "white"}, {"text": "秒 ／ 合計 ", "color": "gold"}, {"score": {"name": "#pk_total", "objective": "hw.st"}, "color": "white"}, {"text": "/20", "color": "gold"}]
