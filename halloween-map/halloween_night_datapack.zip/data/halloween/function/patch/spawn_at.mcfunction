$execute unless block $(x) 64 $(z) minecraft:air run return 0
$execute unless block $(x) 65 $(z) minecraft:air run return 0
execute if score #g hw.tmp matches 1 run return run function halloween:patch/spawn_gold with storage halloween:tmp
$summon minecraft:block_display $(x) 64 $(z) {block_state:{Name:"minecraft:jack_o_lantern",Properties:{facing:"south"}},Tags:["hw.ptall","hw.ptd","hw.tmpent"],brightness:{sky:15,block:15},Glowing:1b,glow_color_override:16744448,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.1f,0.0f,0.1f],scale:[0.8f,0.8f,0.8f]}}
$execute positioned $(x) 64 $(z) align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:interaction ~ ~ ~ {width:0.95f,height:0.95f,response:1b,Tags:["hw.click","hw.c.pt","hw.pt","hw.ptall","hw.tmpent"]}
$particle minecraft:flame $(x) 64.5 $(z) 0.3 0.3 0.3 0.02 8
