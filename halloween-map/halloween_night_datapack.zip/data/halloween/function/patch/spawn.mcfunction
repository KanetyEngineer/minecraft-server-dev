execute store result storage halloween:tmp x int 1 run random value -76..-46
execute store result storage halloween:tmp z int 1 run random value -16..16
execute store result score #g hw.tmp run random value 1..8
function halloween:patch/spawn_at with storage halloween:tmp
