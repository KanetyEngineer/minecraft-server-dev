kill @e[tag=hw.ptall]
scoreboard players set #max hw.tmp 0
execute as @a run scoreboard players operation #max hw.tmp > @s hw.pk
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "カボチャ狩り終了！ みんなの合計: ", "color": "gold"}, {"score": {"name": "#pk_total", "objective": "hw.st"}, "color": "yellow"}, {"text": " 個", "color": "gold"}]
execute if score #max hw.tmp matches 1.. as @a if score @s hw.pk = #max hw.tmp run tellraw @a [{"text": "  いちばん叩いた人: ", "color": "gray"}, {"selector": "@s", "color": "yellow"}, {"text": "（", "color": "gray"}, {"score": {"name": "#max", "objective": "hw.tmp"}, "color": "yellow"}, {"text": "個）", "color": "gray"}]
execute if score #pk_total hw.st matches 20.. if score #pk_done hw.st matches 0 run function halloween:patch/success
execute if score #pk_total hw.st matches ..19 if score #pk_done hw.st matches 0 run tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "あと少し！ 合計20個で ③ ランタンが現れる。もう一度挑戦しよう", "color": "yellow"}]
