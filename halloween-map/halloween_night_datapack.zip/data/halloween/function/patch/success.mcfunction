scoreboard players set #pk_done hw.st 1
setblock -74 65 0 minecraft:soul_lantern
summon minecraft:interaction -73.5 65 0.5 {width:0.9f,height:1.0f,response:1b,Tags:["hw.click","hw.c.lantern","hw.tmpent","hw.new"]}
scoreboard players set @e[type=minecraft:interaction,tag=hw.new,limit=1] hw.id 3
tag @e[type=minecraft:interaction,tag=hw.new] remove hw.new
tellraw @a [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "大収穫！ 畑の西のワラ山のそばに ③ 魂のランタンが現れた！", "color": "aqua", "bold": true}]
playsound minecraft:block.respawn_anchor.charge master @a -74 65 0 3 1
particle minecraft:soul_fire_flame -73.5 65.5 0.5 0.3 0.6 0.3 0.05 60 force
