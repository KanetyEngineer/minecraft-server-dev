execute unless entity @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run return run function halloween:boss/defeat
execute store result bossbar halloween:boss value run data get entity @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] Health
scoreboard players add #bt hw.st 1
execute if score #bt hw.st matches 160.. run function halloween:boss/ability
execute if score #bphase hw.st matches 1 store result score #hp hw.tmp run data get entity @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] Health
execute if score #bphase hw.st matches 1 if score #hp hw.tmp matches ..150 run function halloween:boss/phase2
scoreboard players operation #s hw.tmp = #bt hw.st
scoreboard players operation #s hw.tmp %= #5 hw.c
execute if score #s hw.tmp matches 0 at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:flame ~ ~4.6 ~ 0.4 0.3 0.4 0.02 4
execute as @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] unless entity @s[x=-27,y=40,z=-152,dx=54,dy=60,dz=50] run tp @s 0.5 65 -143.5
