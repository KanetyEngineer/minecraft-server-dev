scoreboard players set #boss hw.st 1
title @a times 10 70 20
title @a title {"text": "パンプキン・キング", "color": "gold", "bold": true}
title @a subtitle {"text": "が目を覚ました……！", "color": "red"}
weather thunder
playsound minecraft:entity.wither.spawn master @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] 0.5 65 -143.5 1 0.7
summon minecraft:lightning_bolt 0 65 -147
schedule function halloween:boss/spawn 60t
