summon minecraft:wither_skeleton 0.5 65 -143.5 {Tags:["hw.boss","hw.mob"],PersistenceRequired:1b,CustomNameVisible:1b,CustomName:{"text": "パンプキン・キング", "color": "gold", "bold": true},Health:300.0f,attributes:[{id:"minecraft:max_health",base:300.0d},{id:"minecraft:scale",base:2.0d},{id:"minecraft:movement_speed",base:0.3d},{id:"minecraft:attack_damage",base:7.0d},{id:"minecraft:knockback_resistance",base:0.7d},{id:"minecraft:follow_range",base:64.0d}],equipment:{head:{id:"minecraft:jack_o_lantern",count:1},mainhand:{id:"minecraft:netherite_hoe",count:1},chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":3029569}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":16744448}}},drop_chances:{head:0.0f,mainhand:0.0f,chest:0.0f,legs:0.0f}}
scoreboard players set #boss hw.st 2
scoreboard players set #bphase hw.st 1
scoreboard players set #bt hw.st 0
bossbar set halloween:boss name {"text": "パンプキン・キング", "color": "gold", "bold": true}
bossbar set halloween:boss color red
bossbar set halloween:boss max 300
bossbar set halloween:boss value 300
bossbar set halloween:boss players @a
bossbar set halloween:boss visible true
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.wither.ambient master @a ~ ~ ~ 2 0.5
tellraw @a [{"text": "パンプキン・キング「わが眠りを妨げるのは誰だ……お菓子はすべて私のものだ！」", "color": "gold"}]
