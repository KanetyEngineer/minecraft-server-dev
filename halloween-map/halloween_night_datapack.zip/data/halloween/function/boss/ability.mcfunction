scoreboard players set #bt hw.st 0
execute if score #bphase hw.st matches 2 run scoreboard players set #bt hw.st 60
execute if score #bphase hw.st matches 1 store result score #r hw.tmp run random value 1..4
execute if score #bphase hw.st matches 2 store result score #r hw.tmp run random value 1..5
execute if score #r hw.tmp matches 1 run function halloween:boss/a_minions
execute if score #r hw.tmp matches 2 run function halloween:boss/a_ghosts
execute if score #r hw.tmp matches 3 run function halloween:boss/a_shockwave
execute if score #r hw.tmp matches 4 run function halloween:boss/a_blink
execute if score #r hw.tmp matches 5 run function halloween:boss/a_bombs
