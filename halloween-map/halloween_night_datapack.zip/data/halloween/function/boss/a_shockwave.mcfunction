title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] actionbar [{"text": "パンプキン・キング「カボチャ・インパクト！」", "color": "gold"}]
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:explosion ~ ~0.5 ~ 4 0.2 4 0 25
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:flame ~ ~0.3 ~ 5 0.1 5 0.05 120
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 2 0.7
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] as @a[tag=hw.player,distance=..7] run damage @s 5 minecraft:magic
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] as @a[tag=hw.player,distance=..7] run effect give @s minecraft:levitation 1 4 true
