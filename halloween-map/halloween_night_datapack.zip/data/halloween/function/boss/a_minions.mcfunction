execute store result score #n hw.tmp if entity @e[type=minecraft:skeleton,tag=hw.mob]
execute if score #n hw.tmp matches 8.. run return run function halloween:boss/a_shockwave
title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] actionbar [{"text": "パンプキン・キング「出でよ、カボチャ兵たち！」", "color": "gold"}]
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run summon minecraft:skeleton ~3 ~ ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "カボチャ兵", "color": "gold"},equipment:{head:{id:"minecraft:carved_pumpkin",count:1},mainhand:{id:"minecraft:bow",count:1}},drop_chances:{head:0.0f,mainhand:0.0f}}
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run summon minecraft:skeleton ~-3 ~ ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "カボチャ兵", "color": "gold"},equipment:{head:{id:"minecraft:carved_pumpkin",count:1},mainhand:{id:"minecraft:bow",count:1}},drop_chances:{head:0.0f,mainhand:0.0f}}
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run summon minecraft:skeleton ~ ~ ~3 {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "カボチャ兵", "color": "gold"},equipment:{head:{id:"minecraft:carved_pumpkin",count:1},mainhand:{id:"minecraft:bow",count:1}},drop_chances:{head:0.0f,mainhand:0.0f}}
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:large_smoke ~ ~1 ~ 3 0.5 3 0.02 60
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.evoker.prepare_summon master @a ~ ~ ~ 2 0.8
