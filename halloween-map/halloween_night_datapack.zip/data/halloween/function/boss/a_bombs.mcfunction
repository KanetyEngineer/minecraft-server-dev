title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] actionbar [{"text": "パンプキン・キング「カボチャ爆弾をくらえ！」", "color": "gold"}]
execute at @r[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] run summon minecraft:creeper ~2 ~ ~ {Tags:["hw.mob"],Fuse:40s,ignited:1b,ExplosionRadius:2b,CustomName:{"text": "かぼちゃボム", "color": "gold"}}
execute at @r[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] run summon minecraft:creeper ~-2 ~ ~1 {Tags:["hw.mob"],Fuse:40s,ignited:1b,ExplosionRadius:2b,CustomName:{"text": "かぼちゃボム", "color": "gold"}}
