scoreboard players set #bphase hw.st 2
effect give @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] minecraft:speed infinite 0 true
effect give @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] minecraft:fire_resistance infinite 0 true
bossbar set halloween:boss color purple
bossbar set halloween:boss name {"text": "パンプキン・キング（怒り）", "color": "red", "bold": true}
title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] title {"text": "怒り状態！", "color": "red", "bold": true}
title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] subtitle {"text": "攻撃が激しくなる……", "color": "gold"}
summon minecraft:lightning_bolt 18 64 -126
summon minecraft:lightning_bolt -18 64 -126
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.ravager.roar master @a ~ ~ ~ 2 0.6
