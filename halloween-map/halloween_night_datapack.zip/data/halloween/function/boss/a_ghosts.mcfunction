title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] actionbar [{"text": "パンプキン・キング「さまよえる魂よ、来たれ！」", "color": "gold"}]
execute at @r[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] run summon minecraft:vex ~ ~4 ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "さまよう魂", "color": "aqua"}}
execute at @r[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] run summon minecraft:vex ~ ~4 ~ {Tags:["hw.mob"],PersistenceRequired:1b,CustomName:{"text": "さまよう魂", "color": "aqua"}}
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.vex.charge master @a ~ ~ ~ 2 0.6
