title @a[x=-30,y=40,z=-152,dx=60,dy=60,dz=50] actionbar [{"text": "パンプキン・キング「どこへ逃げても無駄だ！」", "color": "gold"}]
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:large_smoke ~ ~2 ~ 0.6 1.5 0.6 0.05 60
execute as @r[tag=hw.player,x=-30,y=40,z=-152,dx=60,dy=60,dz=50] at @s rotated ~ 0 run tp @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] ^ ^ ^-2.5
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run particle minecraft:large_smoke ~ ~2 ~ 0.6 1.5 0.6 0.05 60
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 2 0.5
execute at @e[type=minecraft:wither_skeleton,tag=hw.boss,limit=1] run effect give @a[tag=hw.player,distance=..6] minecraft:darkness 3 0 true
