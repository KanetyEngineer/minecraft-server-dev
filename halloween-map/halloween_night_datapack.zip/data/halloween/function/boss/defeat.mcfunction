scoreboard players set #boss hw.st 3
bossbar set halloween:boss visible false
kill @e[tag=hw.mob]
weather clear
title @a times 10 80 20
title @a title {"text": "パンプキン・キングを倒した！", "color": "gold", "bold": true}
title @a subtitle {"text": "村にお菓子が戻ってきた！ 全員 +20", "color": "yellow"}
tellraw @a [{"text": "パンプキン・キング「ぐぬぬ……来年のハロウィンこそは……！」", "color": "gold"}]
scoreboard players set #gain hw.tmp 20
execute as @a[tag=hw.player] run function halloween:candy/add
scoreboard players set #fw hw.st 12
function halloween:fx/finale
schedule function halloween:game/end 200t
