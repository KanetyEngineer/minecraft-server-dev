give @s minecraft:wooden_sword[unbreakable={}]
give @s minecraft:pumpkin_pie 8
function halloween:player/book
