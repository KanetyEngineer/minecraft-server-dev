scoreboard players reset @s hw.left
tellraw @s [{"text": "[ハロウィン] ", "color": "gold"}, {"text": "おかえりなさい！", "color": "yellow"}]
execute unless score #state hw.st matches 1 run tp @s 0.5 64 12.5 180 0
