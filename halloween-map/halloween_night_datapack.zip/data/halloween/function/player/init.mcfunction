scoreboard players set @s hw.init 1
gamemode adventure @s[gamemode=survival]
tp @s 0.5 64 12.5 180 0
function halloween:player/welcome
function halloween:player/book
